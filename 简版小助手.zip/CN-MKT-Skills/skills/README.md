# AI 创意制作 Skills 工具箱

> 把品牌规范、平台知识、创意公式封装成可直接使用的工具，让每个营销人员都能高效产出高质量素材。

---

## 为什么需要这些 Skills？

普通营销人员使用 AI 创意工具（Seedance、Nano Banana 等）时面临三大挑战：

1. **不会写 Prompt** — 不知道怎么用语言描述想要的画面和效果
2. **品牌调性难把控** — AI 输出容易"跑调"，不像光遇
3. **平台规格记不住** — 每个平台的尺寸、时长、语气都不同，反复查资料

这套 Skills 就是解决这些问题的"快捷方式"。

---

## Skills 一览

| # | Skill | 用途 | 适合谁 |
|---|-------|------|--------|
| 01 | [AI 视频 Prompt 生成器](01-video-prompt-generator.md) | 为 Seedance/Nano Banana 等工具生成符合品牌调性的视频/图像 prompt | 所有需要制作视频素材的人 |
| 02 | [全平台内容适配器](02-platform-content-adapter.md) | 一条核心信息 → 自动适配抖音/B站/小红书/微信/微博 | 内容运营、社媒运营 |
| 03 | [创意 Brief 生成器](03-creative-brief-generator.md) | 快速产出标准化的活动/赛季创意简报 | 营销策划、项目经理 |
| 04 | [品牌调性检查器](04-brand-voice-checker.md) | 检查 AI 生成内容是否符合光遇品牌原则 | 所有人（尤其是新人） |

---

## 使用方式

### 方式一：配合 AI 助手使用
将 Skill 文档作为上下文提供给 Claude 或其他 AI 助手，然后按模板填写输入信息，获得即用的输出。

### 方式二：手动参考使用
直接参考文档中的 prompt 模板，复制并修改关键字段后使用。

### 方式三：Prompt 助手工具（推荐）
运行 [素材 Prompt 助手](../tools/prompt-assistant/)，用对话方式自动生成 prompt——内置了所有品牌知识和平台规格。

```bash
cd tools/prompt-assistant
pip install -r requirements.txt
python main.py
```

### 方式四：团队工作流集成
将 Skills 嵌入到团队的日常创意流程中，作为标准化步骤使用。

---

## 典型工作流

```
第一步                第二步                 第三步                第四步
确定需求          →   生成 Prompt         →   AI 工具生成素材    →   品牌检查
(什么内容/什么平台)   (Skill 01/02/03)       (Seedance 等)          (Skill 04)
```

**具体场景示例**：

> 需要为"归来季"制作抖音30秒视频

1. 用 **Skill 03** 生成创意 Brief → 明确视频方向
2. 用 **Skill 01** 生成 Seedance 视频 prompt → 描述画面
3. 在 Seedance 中生成视频素材
4. 用 **Skill 04** 检查品牌调性 → 确认合格
5. 用 **Skill 02** 适配其他平台文案 → 一鱼多吃

---

## 与培训模块的关系

这些 Skills 是以下培训模块的"实战工具化"版本：

- [Module 07: 内容本地化与中文文案](../modules/07-content-localization.md) → Skill 02, 04
- [Module 08: 创意制作与平台规格](../modules/08-creative-production.md) → Skill 01, 03
- [Module 21: AI 在营销中的应用](../modules/21-ai-applications.md) → Skill 01, 04

想深入理解原理，请回到对应的培训模块。

---

[返回主指南](../README.md)
