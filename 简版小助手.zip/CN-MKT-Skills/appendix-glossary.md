# Appendix A: Sky CN Terminology Glossary

> Single source of truth for all Sky-specific and CN marketing terminology. Reference this when creating content, briefing partners, or onboarding new team members.

---

## A.1 Sky Game Terminology

| English | Chinese | Pinyin | Context |
|---------|---------|--------|---------|
| Sky: Children of the Light | 光·遇 (光遇) | Guāng Yù | Official CN game name; use 光·遇 for formal, 光遇 for casual |
| thatgamecompany | thatgamecompany / tgc | — | Keep in English; do not translate |
| Jenova Chen | 陈星汉 | Chén Xīnghàn | Use Chinese name for CN audiences |
| Children of the Light | 光之子 | Guāng zhī Zǐ | Community self-reference for players |
| Child of Light (single player) | 光之子 / sky星 | — | How players refer to themselves |

### Realms & Locations

| English | Chinese | Notes |
|---------|---------|-------|
| Isle of Dawn | 晨岛 | Tutorial realm |
| Daylight Prairie | 云野 | Open exploration realm |
| Hidden Forest | 雨林 | Atmospheric, rainy realm |
| Valley of Triumph | 霞谷 | Grand architecture, ice rink |
| Golden Wasteland | 暮土 | Dark, dangerous realm |
| Vault of Knowledge | 禁阁 | Starlit library realm |
| Eye of Eden | 伊甸 / 暴风眼 | End-game area; 伊甸 is more common; 暴风眼 (Eye of the Storm) is colloquial |
| Orbit / Office | 遇境 | Social hub / home space |
| Seasonal areas | 季节地图 | Unique to each season |

### Game Mechanics & Economy

| English | Chinese | Notes |
|---------|---------|-------|
| Candle | 蜡烛 | Primary in-game currency |
| Heart | 爱心 / 红心 | Social currency; exchanged between friends |
| Seasonal Candle | 季节蜡烛 | Season-specific currency |
| Seasonal Heart | 季节爱心 | Season-specific social currency |
| Winged Light | 光之翼 | Collectible feathers; determine flight height |
| Ascended Candle | 升华蜡烛 | Earned through Eden; premium currency |
| Spirit | 先祖 | Collectible NPCs that teach emotes/cosmetics |
| Traveling Spirit | 复刻先祖 / 旅行先祖 | Returning spirits from past seasons |
| Constellation | 星盘 | Spirit upgrade tree |
| Season | 季节 / 季 | Content season (~10 weeks) |
| Adventure Pass / Season Pass | 季卡 | Paid seasonal pass |
| Candle run | 跑烛 | Daily activity of collecting candles |
| Daily quest | 日常任务 / 日任 | Daily activities for rewards |
| Eden run | 献祭 / 跑图伊甸 | End-game sacrifice and rebirth cycle |
| Meditation shrine | 冥想点 | Collectible scenic spots |
| Shared space | 共享空间 | Multiplayer social areas |

### Cosmetics & Items

| English | Chinese | Notes |
|---------|---------|-------|
| Cape / Cloak | 斗篷 / 披风 | Character back cosmetic |
| Mask | 面具 | Character face cosmetic |
| Hair | 发型 | Character hair cosmetic |
| Outfit / Pants | 裤子 / 服装 | Character body cosmetic |
| Prop | 道具 | Held items (instruments, toys, etc.) |
| Emote / Expression | 表情 / 动作 | Character animations |
| Instrument | 乐器 | Playable musical instruments |
| Spell | 魔法 | Consumable items (resize, fireworks, etc.) |
| Chat table | 聊天桌 | Furniture item enabling text chat |
| Friendship bench | 友谊长椅 | Furniture item for sitting together |

### Social & Multiplayer

| English | Chinese | Notes |
|---------|---------|-------|
| Hold hands | 牵手 | Core social mechanic |
| Light someone's candle | 点亮蜡烛 | First interaction with a stranger |
| Friend invitation | 好友邀请 | Sending a friend request |
| Chat unlock | 解锁聊天 | Requires friendship tree progression |
| Piggyback / Carry | 背人 | Carry another player on your back |
| Group flight | 集体飞行 | Flying together in formation |
| Moth (new player) | 萌新 / 小黑 | Community nicknames for beginners |
| Veteran player | 老玩家 / 大佬 | Experienced players |

---

## A.2 CN Social Media & Marketing Terminology

### Platform Terminology

| Term | Chinese | Meaning |
|------|---------|---------|
| KOL | 关键意见领袖 | Key Opinion Leader; major influencers (100K+ followers) |
| KOC | 关键意见消费者 | Key Opinion Consumer; micro-influencers (1K–100K followers) |
| UGC | 用户生成内容 | User-Generated Content |
| 二创 | 二次创作 | Fan creation / derivative works (fan art, videos, fiction) |
| UP主 | — | Bilibili content creator |
| 达人 | — | Douyin / Xiaohongshu content creator |
| 私域流量 | — | Private traffic (e.g., WeChat groups, owned channels) |
| 公域流量 | — | Public traffic (e.g., algorithm-distributed content) |
| 种草 | — | "Planting grass" — recommending a product to create desire |
| 拔草 | — | "Pulling grass" — trying or buying a recommended product |
| 弹幕 / Danmaku | — | Bullet comments (scrolling text over Bilibili videos) |
| 三连 | — | Bilibili engagement: Like + Coin + Collect |
| 超话 | — | Weibo Super Topic (dedicated community forum) |
| 热搜 | — | Weibo Hot Search (trending topics) |
| 笔记 | — | Xiaohongshu "note" (post) |
| DOU+ | — | Douyin paid content boost feature |
| 公众号 | — | WeChat Official Account |
| 视频号 | — | WeChat Channels (short video feature) |
| 小程序 | — | Mini-program (WeChat/Alipay lightweight apps) |
| 直播 | — | Livestreaming |
| 网感 | — | Internet-native sensibility; fluency in online culture |
| 治愈系 | — | "Healing" genre/aesthetic — cozy, soothing content |

### Business & Publishing Terminology

| Term | Chinese | Meaning |
|------|---------|---------|
| 版号 | — | Game publication number / ISBN; government license required for commercial release |
| ASO | 应用商店优化 | App Store Optimization |
| CPI | 每次安装成本 | Cost Per Install |
| CPM | 千次展示成本 | Cost Per Mille (thousand impressions) |
| CPE | 每次互动成本 | Cost Per Engagement |
| CTR | 点击率 | Click-Through Rate |
| ARPU | 每用户平均收入 | Average Revenue Per User |
| ARPPU | 每付费用户平均收入 | Average Revenue Per Paying User |
| LTV | 用户终身价值 | Lifetime Value |
| DAU / MAU | 日活 / 月活 | Daily / Monthly Active Users |
| ROI | 投资回报率 | Return on Investment |
| GMV | 成交总额 | Gross Merchandise Value |
| 复盘 | — | Post-mortem / retrospective review |
| IAP | 应用内购买 | In-App Purchase |
| F2P | 免费游戏 | Free-to-Play |

---

## A.3 CN Holidays & Cultural Moments

| Holiday | Chinese | Typical Date | Sky Marketing Relevance |
|---------|---------|-------------|------------------------|
| Chinese New Year / Spring Festival | 春节 | Jan/Feb (lunar) | Highest priority; Days of Fortune event; peak engagement |
| Lantern Festival | 元宵节 | 15 days after CNY | Extension of CNY celebrations |
| Qingming Festival | 清明节 | Early April | Reflective; lighter marketing touch |
| Labor Day | 劳动节 | May 1 (+ holiday week) | Travel/leisure period; engagement opportunity |
| Dragon Boat Festival | 端午节 | June (lunar) | Cultural collaboration opportunity |
| Qixi Festival (Chinese Valentine's) | 七夕 | August (lunar) | Couples/romance content; Days of Love tie-in |
| Mid-Autumn Festival | 中秋节 | September (lunar) | Reunion theme; strong brand alignment |
| National Day / Golden Week | 国庆节 | October 1–7 | Extended holiday; high engagement window |
| Singles' Day | 双十一 (11.11) | November 11 | Commerce moment; merch promotion opportunity |
| Winter Solstice | 冬至 | December 21–22 | Warm, cozy content opportunity |

---

## A.4 CN Analytics Tool Directory

| Tool | Chinese | Coverage | Primary Use |
|------|---------|----------|-------------|
| 新榜 (Newrank) | — | Cross-platform | Content performance benchmarking |
| 蝉妈妈 (Chanmama) | — | Douyin, Kuaishou | KOL analytics, trending content |
| 千瓜 (Qiangua) | — | Xiaohongshu | Note analytics, KOL discovery |
| 飞瓜 (Feigua) | — | Douyin, Kuaishou, Bilibili | Video analytics, trending |
| 七麦数据 (Qimai) | — | App stores | ASO, app rankings, download estimates |
| 火烧云 (Huoshaoyun) | — | Bilibili | UP主 analytics, content trends |
| Sensor Tower | — | Global app stores | Competitive intelligence, market sizing |
| 巨量引擎 (Ocean Engine) | — | Douyin ads ecosystem | Ad management and analytics |

---

## Usage Guidelines

- **When creating content**: Reference this glossary to ensure correct terminology
- **When briefing partners/KOLs**: Include relevant terms so they use correct language
- **When onboarding new team members**: Share this glossary on Day 1
- **When translating/localizing**: Use these as the authoritative CN translations
- **Updating this glossary**: Add new terms as they emerge; flag outdated terms for removal quarterly

---

*Last reviewed: [Update quarterly with review date]*

[← Module 27: Cross-Platform Publishing](modules/27-cross-platform.md) | [Main Guide](README.md)
