# Module 01: Game & Brand Understanding

> Know the game deeply before you market it. Every campaign should carry Sky's emotional DNA.

---

## 1.1 What Is Sky: Children of the Light (光·遇)?

Sky is a **social adventure game** developed by thatgamecompany (tgc), the studio behind Journey, Flower, and flOw. Players explore seven thematic realms as "Children of the Light," unlocking the stories of ancestral spirits, forming friendships with other players, and experiencing moments of wonder, loss, and renewal.

### Core Game Loop
1. **Explore** — Traverse beautifully crafted realms (Isle of Dawn, Daylight Prairie, Hidden Forest, Valley of Triumph, Golden Wasteland, Vault of Knowledge, Eye of Eden)
2. **Connect** — Meet other players, offer candles, hold hands, sit together, play music
3. **Collect** — Gather winged light, cosmetics, emotes, and musical instruments
4. **Sacrifice & Rebirth** — The Eye of Eden cycle teaches generosity through loss and renewal
5. **Seasons** — Limited-time narrative content that refreshes the experience every ~2.5 months

### What Makes Sky Different
- **No violence, no competition** — A rare "wholesome" game in the mobile market
- **Nonverbal communication first** — Players initially interact through gestures and emotes before unlocking chat
- **Emotional storytelling** — Music, art, and environmental narrative over text-heavy plots
- **Pro-social design** — Game mechanics reward helping others (e.g., lighting others' candles, carrying newer players)

---

## 1.2 thatgamecompany's Design Philosophy

Founder **Jenova Chen (陈星汉)** has consistently articulated tgc's mission:

> "We want to create games that make people feel something — wonder, connection, compassion."

### Key Principles
| Principle | Description | Marketing Implication |
|-----------|-------------|----------------------|
| **Emotion over mechanics** | Gameplay serves emotional experience | Lead with feeling in all creative, not features |
| **Universal accessibility** | Simple controls, no text dependency | Market to casual and non-gamer audiences |
| **Social connection** | Multiplayer as emotional bonding | Highlight shared moments, friendship stories |
| **Artistic integrity** | Every pixel is intentional | Respect the art — never use off-brand visuals |
| **Generosity** | Free-to-play with cosmetic-only monetization | Messaging should never feel transactional |

### Jenova Chen's Vision for CN Market
- Jenova is Chinese-American — Sky carries cultural resonances with Chinese aesthetics (lanterns, clouds, flowing robes)
- The game's themes of impermanence, sacrifice, and communal harmony resonate with Chinese philosophical traditions
- CN marketing should lean into these cultural connections authentically, not superficially

---

## 1.3 Brand Identity & Visual Language

### Brand Pillars
1. **Wonder** — The awe of discovering something beautiful
2. **Connection** — The warmth of shared human experience
3. **Compassion** — The choice to give without expecting return
4. **Light** — Both literal (game mechanic) and metaphorical (hope, guidance)

### Visual Guidelines
- **Color palette**: Warm golds, soft purples, sky blues, sunset oranges — avoid harsh neons or dark/grungy tones
- **Imagery**: Silhouettes of characters against vast skies, hand-holding, flying together, candlelight
- **Typography**: Clean, elegant, airy — Chinese typography should use elegant serif or semi-serif fonts (思源宋体 or similar)
- **Photography/Video**: Dreamy, soft-focus, golden hour lighting
- **Never use**: Aggressive CTAs, clickbait imagery, dark patterns, competitive framing

### Brand Voice (CN)
| Do | Don't |
|----|-------|
| Warm, inviting, poetic | Cold, corporate, salesy |
| "和我们一起飞翔" (Fly with us) | "立即下载！限时优惠！" (Download now! Limited offer!) |
| Speak as a friend sharing a beautiful place | Speak as a brand pushing a product |
| Use gentle humor and whimsy | Use sarcasm or edgy humor |
| Reference shared emotions | Reference metrics or rankings |

---

## 1.4 Seasonal Content & Live Ops

Sky operates on a **seasonal model** that drives content marketing cadence:

### Season Structure
- **Duration**: ~2.5 months per season
- **Content**: New area/map, 4–6 new spirits with cosmetics and emotes, a narrative arc
- **Economy**: Seasonal candles → seasonal hearts → spirit cosmetics
- **Adventure Pass**: Optional paid pass for extra cosmetics (IAP driver)

### Key Recurring Events
| Event | Timing | Marketing Significance |
|-------|--------|----------------------|
| **Days of Fortune (新春)** | Chinese New Year | Highest CN engagement period — culturally resonant |
| **Days of Love** | Valentine's Day | Friendship & romance content |
| **Days of Nature** | Earth Day | Environmental storytelling |
| **Days of Feast** | Year-end | Cozy, communal gathering vibe |
| **Days of Summer / Bloom** | Seasonal | Lighthearted, celebratory |
| **Aurora Concert Series** | Periodic | Music & community events |

### CN-Specific Content Considerations
- CN version may have different release schedules (coordinated with NetEase)
- Some global content requires localization review (cultural sensitivity)
- CN holidays (Mid-Autumn Festival, Dragon Boat Festival, National Day) may warrant unique activations
- Beta/test content leaks are common in CN community — have rapid-response plans

---

## 1.5 The Sky Community

### Community Character
- **Overwhelmingly positive** — One of the most wholesome gaming communities
- **Creative** — Massive amount of fan art, music covers, cosplay, and short films
- **Emotionally invested** — Players form real friendships; departures and season endings can cause genuine grief
- **Protective** — Community pushes back on anything perceived as "cash grab" or off-brand

### CN Community Specifics
- Primary gathering places: Bilibili, Xiaohongshu, WeChat groups, QQ groups, Weibo, Douyin
- Fan-created content (二创) is prolific and high quality — treat creators as partners
- Community sentiment shifts quickly — monitor daily
- "光遇" (Guang Yu) is the recognized CN brand name — always use this in CN-facing content
- Players self-identify as "光之子" (Children of Light) or "sky星" — know and use community language

### Key Takeaway for Marketers

> Every piece of marketing content should pass the "Sky test": Does it make someone feel wonder, warmth, or connection? If it only informs or sells, rethink it.

---

## Related Modules

- [Module 02: Target Audience](02-target-audience.md) — Who plays Sky and why
- [Module 14: Content Localization & CN Copywriting](14-content-localization.md) — Translating Sky's brand voice into CN copy
- [Module 15: Community Building](15-community-building.md) — Nurturing the community described here
- [Appendix A: Terminology Glossary](../appendix-glossary.md) — Complete CN terminology reference

---

## Knowledge Check

1. Name the seven realms in Sky. For each one, suggest what type of marketing content (beauty shot, emotional story, guide, etc.) it would be best suited for, and why.
2. Explain tgc's design philosophy in your own words. Then write a sample Xiaohongshu caption (2–3 sentences) that embodies this philosophy.
3. What is the Eye of Eden, and why is its mechanic of sacrifice and rebirth significant to Sky's brand message? How would you reference this in a campaign without spoiling the experience?
4. Describe three things that make Sky's CN community unique versus other game communities. For each, explain how marketing can leverage this uniqueness.
5. You're briefing a KOL who has never played Sky. In 60 seconds, how would you explain what the game *feels* like — not what it *is*?

---

[Next: Module 02 — Target Audience & Player Lifecycle →](02-target-audience-lifecycle.md) | [Main Guide](../README.md)
