# Module 12: Budget Management & ROI Analysis

> Every yuan you spend is an investment in Sky's future. Spend wisely, track rigorously, and always be able to answer: "What did we get for this?"

---

## 20.1 Why Budget Skills Matter for Marketers

You may not be a finance professional, but as a marketer you need to:
- **Plan budgets** that align spending with strategic priorities
- **Track spending** in real-time to avoid overruns
- **Justify investments** with data-driven ROI analysis
- **Optimize allocation** by shifting budget to what works mid-campaign
- **Report to leadership** on financial performance clearly

### The Marketer's Financial Mindset
> Every marketing dollar (yuan) should either **make money** (ROI) or **build brand value** (long-term investment). If it does neither, question why you're spending it.

---

## 20.2 Budget Planning Framework

### Annual Marketing Budget Structure

| Category | Description | Typical % |
|----------|-------------|-----------|
| **Content production** | Video, design, copywriting, photography | 20–25% |
| **Paid media** | Platform advertising, DOU+, search ads | 25–35% |
| **KOL/KOC partnerships** | Creator partnerships and seeding | 15–25% |
| **Community & events** | Online events, meetups, exhibitions | 10–15% |
| **Merchandising** | Product development, production, fulfillment | 5–10% |
| **Tools & platforms** | Analytics tools, management software, subscriptions | 3–5% |
| **Contingency** | Unexpected opportunities or crises | 5–10% |

### Budget Allocation by Objective

Different strategic objectives require different spending profiles:

| Objective | Content | Paid Media | KOL | Community | Events |
|-----------|---------|-----------|-----|-----------|--------|
| **Brand awareness** | 20% | 35% | 30% | 10% | 5% |
| **User acquisition** | 15% | 40% | 25% | 10% | 10% |
| **Community engagement** | 30% | 10% | 20% | 25% | 15% |
| **Revenue growth** | 20% | 30% | 20% | 15% | 15% |

### Quarterly Budget Planning Process

```
Step 1: Review previous quarter's performance and spending
    │
Step 2: Identify next quarter's strategic priorities
    │
Step 3: Map campaigns and activities to priorities
    │
Step 4: Estimate costs for each activity
    │
Step 5: Allocate budget across categories
    │
Step 6: Build contingency buffer (5–10%)
    │
Step 7: Get approval from leadership
    │
Step 8: Set up tracking system
```

---

## 20.3 Campaign Budgeting

### Campaign Budget Template

```
═══════════════════════════════════════════
  CAMPAIGN BUDGET — [Campaign Name]
  Period: [Start Date] — [End Date]
═══════════════════════════════════════════

BUDGET SUMMARY
Total Budget: ¥[Amount]
Budget Owner: [Name]
Approval Date: [Date]

──────────────────────────────────────────
LINE ITEMS
──────────────────────────────────────────
Category              │ Planned  │ Actual  │ Variance
──────────────────────┼──────────┼─────────┼─────────
Content Production    │          │         │
  Video production    │          │         │
  Design/graphics     │          │         │
  Copywriting         │          │         │
──────────────────────┼──────────┼─────────┼─────────
Paid Media            │          │         │
  Douyin (巨量引擎)    │          │         │
  Bilibili Ads        │          │         │
  Xiaohongshu Ads     │          │         │
  Other platforms     │          │         │
──────────────────────┼──────────┼─────────┼─────────
KOL/KOC               │          │         │
  Tier 1 KOLs         │          │         │
  Tier 2 KOLs         │          │         │
  KOC seeding          │          │         │
──────────────────────┼──────────┼─────────┼─────────
Community Activation   │          │         │
  Events/contests     │          │         │
  Prizes/rewards      │          │         │
──────────────────────┼──────────┼─────────┼─────────
Other                  │          │         │
  Contingency          │          │         │
──────────────────────┼──────────┼─────────┼─────────
TOTAL                  │          │         │
═══════════════════════════════════════════
```

### Estimating Costs

| Item | How to Estimate | Common Range (¥) |
|------|----------------|-------------------|
| **Short video production (in-house)** | Internal time cost; minimal external spend | 500–2,000 per video |
| **Professional video production** | Quote from production house | 5,000–50,000+ per video |
| **Graphic design (in-house)** | Internal time cost | 200–800 per piece |
| **KOL partnership (Tier 1, 100K+)** | Quote from KOL/agency; negotiation | 10,000–100,000+ per post |
| **KOL partnership (Tier 2, 10K–100K)** | Quote or standard rates | 2,000–15,000 per post |
| **KOC seeding** | Product gifting + small fee or barter | 200–2,000 per person |
| **Douyin DOU+ boost** | Cost per 1000 impressions varies | 0.5–3 per view (varies greatly) |
| **Bilibili advertising** | CPM-based | Varies by placement and targeting |
| **Offline event (meetup)** | Venue + F&B + materials + merch | 5,000–20,000 per event |
| **Online event (creation contest)** | Prizes + promotion | 3,000–15,000 per event |

---

## 20.4 ROI Analysis Framework

### Understanding Marketing ROI

```
         Revenue Generated by Marketing Activity
ROI = ──────────────────────────────────────────── × 100
              Cost of Marketing Activity
```

For Sky, "revenue generated" can include:
- Installs that convert to season pass purchases
- Direct revenue from merch sales
- Attributed in-app purchases

### The Challenge: Not Everything Is Directly Measurable

Many marketing activities don't have direct, trackable revenue attribution. Use a tiered measurement approach:

| Tier | Measurability | Metrics | Example Activities |
|------|-------------|---------|-------------------|
| **Tier 1: Direct ROI** | High | Revenue / cost ratio | Paid UA campaigns, merch sales, direct-response ads |
| **Tier 2: Proxy ROI** | Medium | Cost per acquisition, cost per engagement | KOL partnerships, content campaigns, events |
| **Tier 3: Brand Investment** | Low (short-term) | Sentiment, awareness, share of voice | Community building, PR, brand partnerships |

### Tier 1: Direct ROI Calculation

**Example: Paid UA Campaign**
```
Campaign spend:          ¥50,000
Installs generated:      5,000
CPI:                     ¥10
Day 30 retention:        12% = 600 retained users
Season pass conversion:  8% of retained = 48 purchases
Revenue per pass:        ¥68
Attributed revenue:      ¥3,264
Direct ROI:              3,264 / 50,000 = 6.5%
```

This looks low, but consider:
- Lifetime value of a player extends beyond one season
- Some players spend on additional IAPs
- Each player generates word-of-mouth value

### Tier 2: Proxy ROI Metrics

| Activity | Primary Proxy | How to Measure | Benchmark |
|----------|-------------|---------------|-----------|
| **KOL campaign** | Cost per install (CPI) | Track link / promo code | Compare to paid media CPI |
| **Content creation** | Cost per engagement (CPE) | Total engagement / content cost | Platform benchmarks |
| **Community event** | Cost per participant | Event cost / active participants | Compare to similar events |
| **Social media management** | Cost per follower growth | Monthly cost / net new followers | Industry benchmarks |

### Tier 3: Brand Investment Measurement

Brand marketing is harder to measure in short-term ROI but critical for long-term health:

| Metric | How to Track | Why It Matters |
|--------|-------------|---------------|
| **Brand awareness** | Periodic surveys; search volume trends | Grows the total addressable audience |
| **Brand sentiment** | Social listening scores | Positive sentiment drives organic growth |
| **Share of voice** | Sky mentions vs. competitor mentions | Market mindshare |
| **NPS / player satisfaction** | Surveys | Predicts retention and word-of-mouth |
| **Organic install ratio** | % installs not attributed to paid | Healthy brands generate organic demand |
| **Media coverage quality** | Coverage volume and sentiment | Reputation building |

---

## 20.5 Budget Tracking & Management

### Weekly Budget Check-In

Every week, review:
| Check | Action |
|-------|--------|
| **Spend vs. plan** | Are we on track? Over or under budget? |
| **Pace of spend** | Are we spending evenly or front-loaded? |
| **Performance by channel** | Which channels are delivering best CPI/CPE? |
| **Reallocation needs** | Should we shift budget from underperformers to winners? |
| **Upcoming commitments** | What's already committed but not yet spent? |

### Budget Reallocation Rules

| Signal | Action |
|--------|--------|
| Channel performing 2x better than target | Consider increasing allocation by 20–30% |
| Channel performing 50% below target for 3+ days | Pause, diagnose, and either fix or reallocate |
| Unexpected opportunity arises | Use contingency budget; document the decision |
| Campaign cancelled or delayed | Return budget to pool; reallocate to next priority |

### Budget Tracking Spreadsheet Structure
```
Date │ Category │ Vendor/Platform │ Description │ Planned ¥ │ Actual ¥ │ Variance │ Notes
─────┼──────────┼─────────────────┼─────────────┼───────────┼──────────┼──────────┼──────
     │          │                 │             │           │          │          │
```

---

## 20.6 Financial Reporting to Leadership

### Monthly Finance Report Structure

```
═══════════════════════════════════════════
  SKY CN MARKETING — MONTHLY FINANCE REPORT
  Month: [Month Year]
═══════════════════════════════════════════

1. BUDGET OVERVIEW
   Total annual budget:     ¥[Amount]
   YTD spend:               ¥[Amount] ([X]% of annual)
   This month's spend:      ¥[Amount]
   Remaining budget:        ¥[Amount]

2. SPEND BY CATEGORY (This Month)
   Category        │ Budget  │ Actual  │ Variance │ YTD %
   ────────────────┼─────────┼─────────┼──────────┼──────
   Content         │         │         │          │
   Paid Media      │         │         │          │
   KOL/KOC         │         │         │          │
   Community       │         │         │          │
   Events          │         │         │          │
   Other           │         │         │          │

3. KEY EFFICIENCY METRICS
   • CPI (blended):         ¥[Amount] (vs. ¥[target])
   • CPE (blended):         ¥[Amount]
   • KOL cost per install:  ¥[Amount]
   • Organic install ratio: [X]%

4. TOP ROI ACTIVITIES
   • [Activity 1]: [ROI metric]
   • [Activity 2]: [ROI metric]

5. BUDGET CONCERNS / REQUESTS
   • [Any overspend areas or reallocation requests]

6. NEXT MONTH OUTLOOK
   • Planned spend: ¥[Amount]
   • Key activities: [Campaign 1], [Campaign 2]
═══════════════════════════════════════════
```

### Tips for Financial Communication with Leadership
1. **Lead with outcomes, not expenses** — "We invested ¥X and generated Y installs" beats "We spent ¥X"
2. **Use efficiency metrics** — CPI, CPE, ROI ratios show smart spending
3. **Explain variances** — If you over- or under-spent, explain why and whether the outcome was good
4. **Be honest about unknowns** — Brand investment is hard to measure; say so and explain your proxy metrics
5. **Connect spending to strategy** — Every line item should tie back to a strategic objective

---

## 20.7 Cost Optimization Strategies

### Maximizing Budget Impact

| Strategy | Description | Potential Savings |
|----------|-------------|------------------|
| **Negotiate KOL rates** | Build relationships; offer long-term partnerships for better rates | 10–30% |
| **Barter/trade arrangements** | Exchange game assets or promotion for KOL content | Variable |
| **Content repurposing** | One production → multiple platform-specific outputs | 30–50% content savings |
| **Community leverage** | Fan-created content supplements official content | Significant |
| **Performance optimization** | Continuously optimize paid media to lower CPI | 15–40% over time |
| **Pre-planning** | Book venues, KOLs, and production early for better rates | 10–20% |
| **In-house capability** | Build internal skills to reduce outsourcing | 20–40% production savings |
| **Platform credits/subsidies** | Some platforms offer advertising credits for gaming partners | Free media value |

### The 70/20/10 Rule
| Allocation | Spending Approach | Risk Level |
|-----------|-------------------|------------|
| **70%** | Proven channels and tactics that reliably deliver | Low |
| **20%** | Scaling what's showing promise from recent tests | Medium |
| **10%** | Experimental — new channels, formats, or ideas | High |

---

## 20.8 Vendor & Partner Financial Management

### Working with External Vendors

| Best Practice | Details |
|--------------|---------|
| **Always get multiple quotes** | Compare 3+ vendors for major production work |
| **Define scope clearly** | Ambiguous scope = cost overruns |
| **Payment terms** | Standard: 30–50% upfront, balance on delivery |
| **Include revision limits** | "2 rounds of revisions included" in contracts |
| **Track invoices** | Maintain a log of all invoices, payment dates, and status |
| **Build vendor relationships** | Reliable vendors at fair prices are assets — treat them well |

### KOL Payment Management

| KOL Tier | Payment Model | Notes |
|----------|-------------|-------|
| **Tier 1 (100K+)** | Fixed fee, typically paid 50/50 pre and post | Negotiate usage rights and exclusivity |
| **Tier 2 (10K–100K)** | Fixed fee or performance-based hybrid | Consider performance bonuses |
| **KOC (1K–10K)** | Product gifting + small fee or pure barter | Lower cost but high authenticity |
| **Fan creators** | Product gifting + community recognition | Never exploit; always be generous |

---

## 20.9 Financial Planning Calendar

| Month | Financial Activity |
|-------|-------------------|
| **January** | Annual budget allocation finalized; Q1 campaign budgets confirmed |
| **February** | CNY campaign spend (typically highest month); Q1 check-in |
| **March** | Q1 close; begin Q2 planning |
| **April** | Q2 campaign budgets confirmed; Q1 report to leadership |
| **May-June** | Mid-year review; adjust H2 budget based on H1 performance |
| **July** | Q3 campaign budgets confirmed; Q2 report |
| **August-September** | Major event season (Mid-Autumn); adjust spending |
| **October** | Q4 planning; holiday season budget allocation |
| **November-December** | Year-end campaigns; begin next year's annual budget planning |

---

## Knowledge Check

1. You have ¥100,000 for a season launch campaign. Allocate it across content, paid media, KOL, and community with a rationale for your split.
2. A Douyin paid campaign has a CPI of ¥15 vs. a target of ¥10. What do you do?
3. Your manager asks: "What's the ROI of our community building efforts?" How do you answer, given that community doesn't have direct revenue attribution?
4. Mid-quarter, an unexpected partnership opportunity arises that costs ¥30,000. You have ¥20,000 in contingency. What's your decision process?
5. Prepare a one-paragraph budget justification for increasing next quarter's KOL budget by 30%.

---

[← Module 11: Marketing SOPs & Workflows](11-marketing-sops.md) | [Next: Module 13 — Game Publishing Fundamentals →](13-game-publishing.md) | [Main Guide](../README.md)
