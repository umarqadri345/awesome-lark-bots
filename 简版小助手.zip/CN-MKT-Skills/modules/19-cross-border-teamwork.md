# Module 19: Cross-Border Teamwork & Professional Growth

> You are the bridge between two worlds. Your ability to translate meaning, manage time across oceans, and build trust at a distance is your superpower.

---

## 19.1 The Cross-Cultural Context

### Understanding the Two Cultures

| Dimension | tgc HQ Style | CN Business Norms |
|-----------|-------------|------------------|
| **Communication** | Direct but warm; open discussion | Often indirect; context matters as much as words |
| **Decision-making** | Collaborative; creative input from all | More hierarchical; consensus-seeking but leader-driven |
| **Hierarchy** | Flat; first-name basis | Respected; titles and seniority matter |
| **Feedback** | Frequent, candid, constructive | Can be indirect; "face" (面子) is important |
| **Values** | Creativity, emotional authenticity | Harmony, relationships (关系), trust, diligence |
| **Conflict** | Addressed openly; disagreement is normal | Often managed privately; direct confrontation avoided |

### Navigating Between Both
Be **bilingual in culture**, not just language:
- With HQ: Be more direct; proactively share opinions
- With CN partners/media: Apply appropriate CN business etiquette and relationship-building
- With the community: Speak as a fellow player, authentic and warm

---

## 19.2 Communication Frameworks

### The "Bridge Translation" Technique

Don't just translate words — translate *meaning and context*:

| Situation | Literal Translation | Bridge Translation |
|-----------|--------------------|--------------------|
| CN community upset about pricing | "Players are complaining" | "There's significant concern about perceived value. In CN gaming culture, pricing fairness is especially sensitive because..." |
| HQ asks "is this working?" | Answer with data only | "Here's the data, and here's what it means in CN context: Bilibili engagement at this level indicates strong core fan response..." |
| Propose a Qixi Festival event | "We want a Valentine's event" | "Qixi (七夕) carries unique cultural weight around the legend of the Cowherd and Weaver Girl. For Sky, this connects beautifully to reunion themes..." |

### The "Context-Intent-Impact" Model

```
CONTEXT: What cultural background shapes how this will be received?
    ▼
INTENT: What does the sender actually mean?
    ▼
IMPACT: How will the receiver actually interpret this?
```

### Managing "Face" (面子)

| Situation | Face-Aware Approach |
|-----------|-------------------|
| Giving feedback to CN partners | Start with positives; frame improvements as suggestions; use "we" language |
| Receiving critical feedback from HQ | Don't take it personally; US directness is not disrespect |
| Disagreeing with a senior HQ colleague | Frame as "building on their idea" rather than opposing it |

---

## 19.3 Upward Communication (to HQ / Leadership)

### The "Pyramid" Structure
```
         ┌─────────┐
         │ KEY      │  ← Lead with this (1 sentence)
         │ MESSAGE  │
         ├─────────┤
         │ SUPPORT  │  ← 2–3 supporting points
         │ POINTS   │
         ├─────────┤
         │ DETAILS  │  ← Data, examples, context
         │ & DATA   │
         └─────────┘
```

### Status Updates: The "4P" Format

| Component | What to Include |
|-----------|----------------|
| **Progress** | What was accomplished since last update |
| **Plans** | What's coming next |
| **Problems** | Blockers, risks, concerns (with proposed solutions) |
| **Praise** | Wins, standout work, positive community moments |

### Presenting CN Insights: "What → So What → Now What"

| Step | Purpose | Example |
|------|---------|---------|
| **What** | Facts | "Douyin campaign reached 5M views, 2% CTR" |
| **So What** | CN context | "For Douyin, 2% CTR is above benchmark — positive brand signal" |
| **Now What** | Recommendation | "Double down on this format; add a CTA variant to test conversion" |

### HQ Status Template
```
Subject: [Sky CN] Weekly Update — [Date]

TL;DR: [One sentence summary]

Key Updates:
• [Update 1 — most important first]
• [Update 2]
• [Update 3]

Needs from HQ:
• [Request 1] — needed by [date]
• [Request 2] — needed by [date]
```

---

## 19.4 Internal Team Communication

### Channel Guide

| Channel | Best For | Not For |
|---------|---------|---------|
| **Slack** | Quick HQ questions, status updates | Long discussions, formal requests |
| **Email** | Formal requests, external partners, documentation | Urgent matters, casual check-ins |
| **WeChat** | CN team daily ops, partner communication | Formal documentation, HQ communication |
| **Lark/飞书** | Team workspace, document collaboration | External partner communication |
| **Video call** | Complex discussions, relationship building | Simple updates |

### TGC 沟通渠道全景图

我们（TGC CN MKT）的主要沟通软件是 **Slack** 和**飞书**。但因为合作方各有各的主阵地，信息分散在多个平台。以下是沟通渠道全景：

#### 我们的日常沟通

| 平台 | 我们怎么用 |
|------|----------|
| **Slack** | 我们的核心工作平台之一，与 Global 团队、US 团队沟通的主阵地 |
| **飞书** | 我们的核心工作平台之一，与 TM 及内部协作的主阵地 |

#### 按沟通对象

| 沟通对象 | 在哪找他们 | 补充说明 |
|---------|----------|---------|
| **TGC Global 团队** | **Slack** | 主要沟通渠道；US 团队在 Slack 有 `ext-thatskyshop-mkt` channel |
| **JP / SEA 团队** | **Slack**，偶尔**飞书** | 主要在 Slack，但他们有时也会出现在飞书上 |
| **TM** | **飞书**，偶尔 **Slack** | 主阵地在飞书，偶尔也会在 Slack 上出现 |
| **网易（NetEase）** | **Popo**（网易自有平台）/ **微信** | 网易自己用 Popo；偶尔在 Slack 上找我们（主要是有需求的时候）；网易 + TM + TGC CN 三方沟通在微信群 |
| **其他合作伙伴** | **飞书** / **微信** | 外部合作伙伴多通过飞书或微信联系 |

> **实用建议**：刚入职时，让 lead 帮你拉进所有相关的飞书群、Slack channel 和微信群，避免遗漏关键信息。

### Building CN Team Culture

| Practice | Description |
|----------|-------------|
| **Daily standup** | 15-min morning sync — working on what? Blockers? |
| **Transparent priorities** | Everyone knows the team's top 3 priorities |
| **Celebrate wins** | Call out great work publicly |
| **Psychological safety** | OK to admit mistakes, ask questions, disagree |
| **Clear ownership** | Every task and platform has a named owner |

### Giving Feedback (SBI Model)
| Step | Example |
|------|---------|
| **S — Situation** | "In yesterday's Douyin post..." |
| **B — Behavior** | "...the caption used aggressive sales language" |
| **I — Impact** | "...which doesn't match Sky's brand voice" |
| + **Suggestion** | "For next time, aim for a softer, inviting tone" |

### Working with NetEase
| Dimension | Approach |
|-----------|----------|
| **Tone** | Professional, respectful, relationship-oriented |
| **Format** | Formal docs for decisions; WeChat for daily ops |
| **Timing** | Respect review timelines; build buffer |
| **Escalation** | Proper channels; don't skip hierarchy |
| **Disagreements** | Seek compromise; escalate only after good-faith attempts |

---

## 19.5 Time Zone Management

### The Reality
- **HQ** (Los Angeles, PT): UTC-8 (UTC-7 DST)
- **CN Team** (CST): UTC+8
- **Gap**: 15–16 hours
- **Overlap**: ~1–2 hours (9–10 AM CST = 5–6 PM PT previous day)

### Async-First Principles

| Principle | Application |
|-----------|-------------|
| **Front-load context** | Full picture in every message |
| **State the ask** | "I need approval on X by [date]" |
| **Propose, don't just ask** | "I recommend A. If no response by [time], I'll proceed." |
| **Batch communications** | One comprehensive update, not 10 fragments |

### The "Decision Package"
```
DECISION NEEDED: [Brief title]
DEADLINE: [Date/time]
CONTEXT: [2–3 sentences]
OPTIONS:
  A. [Option] — Pros: / Cons:
  B. [Option] — Pros: / Cons:
RECOMMENDATION: Option [X] because [reason]
DEFAULT: If no response by [deadline], proceeding with [option]
```

---

## 19.6 Daily Productivity

### Recommended Daily Structure

| Time Block | Activity |
|-----------|----------|
| **8:30–9:00** | Plan: review calendar, prioritize top 3 |
| **9:00–10:00** | HQ overlap: sync calls, urgent messages |
| **10:00–12:00** | Deep work: creative tasks, strategy, writing |
| **12:00–1:00** | Lunch (protect this!) |
| **1:00–3:00** | Deep work: production, reviews, platform work |
| **3:00–4:00** | Communication: emails, Slack, partner calls |
| **4:00–5:30** | Operations: scheduling, monitoring, admin |
| **5:30–6:00** | Wrap: tomorrow prep, handoff notes to HQ |

### Priority Matrix

```
                    URGENT                    NOT URGENT
              ┌──────────────────────┬──────────────────────┐
   IMPORTANT  │   DO FIRST           │   SCHEDULE           │
              │ • Crisis response    │ • Campaign strategy  │
              │ • Launch day tasks   │ • Process improvement│
              │ • Content deadlines  │ • Skill development  │
              ├──────────────────────┼──────────────────────┤
   NOT        │   DELEGATE           │   ELIMINATE          │
   IMPORTANT  │ • Routine reports    │ • Unnecessary meetings│
              │ • Standard replies   │ • Over-polishing     │
              └──────────────────────┴──────────────────────┘
```

### Campaign vs. Always-On Balance

| Mode | Campaign : Always-On |
|------|---------------------|
| **Pre-launch** | 70 : 30 |
| **Launch week** | 90 : 10 |
| **Post-launch** | 60 : 40 |
| **Between campaigns** | 30 : 70 |

---

## 19.7 Meeting Effectiveness

### The "PODA" Check
- **P — Purpose**: Why are we meeting?
- **O — Outcome**: What should be decided?
- **D — Duration**: How long? (Default 25 min)
- **A — Attendees**: Who actually needs to be there?

### Meeting Cadence

| Meeting | Duration | Frequency |
|---------|----------|-----------|
| HQ weekly sync | 30 min | Weekly |
| CN team standup | 15 min | Daily or 3x/week |
| Campaign kickoff | 45 min | Per campaign |
| Campaign 复盘 | 60 min | Post-campaign |
| NetEase alignment | 30 min | Weekly/bi-weekly |

### Post-Meeting Notes (within 1 hour)
```
DECISIONS: [What was decided]
ACTION ITEMS:
  [Task] → [Owner] → [Deadline]
NEXT: [Date or "async"]
```

---

## 19.8 Documentation & Knowledge Management

### TGC 信息汇聚平台

不同团队使用不同的知识管理平台。掌握以下地图，搜索关键词即可快速找到所需信息。

| 团队 / 部门 | 平台 | 访问方式 | 主要用途 |
|------------|------|---------|---------|
| **Dev Group** | **Confluence** | TGC 账号登录，搜索关键词 | 技术文档、产品规格、开发进度等一切 dev 相关信息 |
| **Dev Group — Design & Art** | **Figma** | TGC 账号 | 设计稿、视觉规范、UI 资源 |
| **Dev Group — Engineering** | **Jira** | TGC 账号 | 开发任务追踪、bug 管理、sprint 规划 |
| **MKT — Global + JP** | **Notion** | 搜索关键词即可 | 营销策略、campaign 文档、会议纪要 |
| **MKT — SEA** | **飞书** | 飞书文档 | SEA 团队习惯使用飞书管理文档 |
| **Creative Team** | **Google Drive** | 公司账号直接打开 Google Drive 搜索 | 创意素材、视频、设计资料存储 |

> **Tips**：关注 **Sky Master Timeline**（产品进展）和 Confluence 上的 **Release Hub**（版本发布进度）来保持对产品节奏的了解。

### 如何查找会议纪要

作为跨国 remote work 公司，大量知识沉淀在会议纪要中。以下是按场景分类的查找方法：

| 场景 | 查找方式 |
|------|---------|
| **你受邀参与的 Zoom 会议** | 登录 Zoom → 查找历史日期的会议 → 点开对应会议 → 查看是否有录制文件 |
| **Global MKT 相关会议** | 登录 **Notion** → 搜索项目关键词 → 按图索骥找到对应纪要 |
| **产品 / 专项方向会议** | 搜索关键词 → 找到对应的 **Slack channel** → 进入频道 → 一般会有 producer 写的最新会议纪要 |
| **其他日常会议** | 结合**飞书会议**录制功能 + **飞书妙记**自动生成纪要 |

### What to Document

| Category | Examples |
|----------|---------|
| **Processes** | SOPs, workflows, checklists |
| **Decisions** | Meeting notes, strategy rationale |
| **Knowledge** | Platform best practices, brand guidelines |
| **Templates** | Briefs, reports, content formats |
| **History** | 复盘 reports, performance data |

### Documentation Principles
1. Write for someone with no context — assume they're new
2. Keep it updated — outdated docs are worse than no docs
3. Use consistent structure across similar documents
4. Make it findable — organized folders, clear naming
5. Assign owners — someone is responsible for keeping each doc current

### 如何找人提问

当你需要获取某个信息时，建议按以下顺序行动：

```
1. 先自助搜索
   在上述各平台（Confluence / Notion / Google Drive / Slack）中搜索关键词
       ▼
2. 搜索无果 → 找 Producer
   每个项目都有对应的 producer，他们是信息汇聚的关键节点
       ▼
3. 关注常态信息源
   • 产品进展 → Sky Master Timeline + Confluence Release Hub
   • 市场进展 → Slack 的 publishing / community channel
       ▼
4. 直接发问
   当拿不准时，直接在 Slack 的 publishing 或 community channel 发问即可
```

> **未来愿景**：我们计划使用集成化的方式构建一个**自动化项目管理中心**，将目前分散在各平台的信息聚合起来，减少信息碎片化带来的效率损失。

---

## 19.9 Conflict Resolution: The "CLEAR" Framework

| Step | Action |
|------|--------|
| **C — Clarify** | "Help me understand your concern." |
| **L — Listen** | Listen fully; repeat back what you heard |
| **E — Explore** | Find shared interests: "We both want this to succeed" |
| **A — Agree** | Find specific, actionable agreement |
| **R — Record** | Document in writing for shared understanding |

### When to Escalate
- Direct conversation hasn't resolved after two attempts
- Conflict is blocking time-sensitive work
- Disagreement involves policy, budget, or strategic direction beyond your authority

---

## 19.10 Avoiding Burnout

### Warning Signs
- Consistently working past 7 PM or on weekends
- Resentment about off-hours HQ messages
- Content quality dropping
- Feeling like you can never "finish"

### Boundaries

| Boundary | How |
|----------|-----|
| **End-of-day cutoff** | Firm time (e.g., 6:30 PM); stick to it |
| **Notifications** | Off after hours for non-critical channels |
| **Weekend protection** | True days off; emergency-only protocol |
| **"Good enough"** | 80% quality at 50% time is often right |

> tgc's mission is about human connection and compassion. That includes how the company treats its own people. Taking care of yourself is a prerequisite for great creative work.

### Weekly Review (30 min, Friday afternoon)
1. Review this week's outcomes
2. Preview next week's calendar
3. Set next week's top 3 priorities
4. Clear inbox/task list
5. Celebrate one win

---

## Knowledge Check

1. HQ sends a campaign brief with humor that won't translate to CN. How do you handle this using bridge translation?
2. Monday morning in Shanghai: 15 Slack messages from HQ, a Douyin video due at noon, a KOL call at 2 PM. Prioritize your morning.
3. Design an async "decision package" for HQ to approve a campaign concept.
4. You and the NetEase team disagree on content timing. Walk through the CLEAR framework.
5. You've been working until 9 PM for two weeks. What changes do you make?

---

## Related Modules
- [Module 10: Campaign Planning & PM](10-campaign-planning-pm.md) — Cross-timezone project workflows
- [Module 17: Agency & Partner Collaboration](17-agency-partner-collab.md) — External communication
- [Module 20: Pitch & Presentation Skills](20-pitch-and-presentation.md) — Presenting to HQ

---

[← Module 18: Events, Merch & IP](18-events-merch-ip.md) | [Next: Module 20 — Pitch & Presentation →](20-pitch-and-presentation.md) | [Main Guide](../README.md)
