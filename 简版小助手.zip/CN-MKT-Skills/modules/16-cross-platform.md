# Module 16: Cross-Platform Publishing

> Sky exists on phones, tablets, consoles, and PCs. Each platform is a different world with different players, different expectations, and different marketing strategies. Master them all.

---

## 27.1 Sky's Cross-Platform Landscape

### Platform Overview

| Platform | Status in CN | Primary Audience | Marketing Priority |
|----------|-------------|-----------------|-------------------|
| **iOS (iPhone/iPad)** | Primary platform; established | Young, female-skewing, premium device | ★★★★★ |
| **Android** | Primary platform; multi-store | Broadest audience; price-sensitive | ★★★★★ |
| **Nintendo Switch** | Available (limited CN presence) | Core gamers; family-oriented | ★★★☆☆ |
| **PlayStation** | Available (CN via PS Store) | Core gamers; quality-focused | ★★★☆☆ |
| **PC (Steam)** | Available globally; CN Steam access | Diverse; cross-over from console/mobile | ★★★★☆ |
| **PC (WeGame)** | Tencent's CN PC platform (if applicable) | CN PC gamers | ★★★☆☆ |

### Why Cross-Platform Matters

```
                    ┌──── Mobile Players ────┐
                    │  (Largest audience)     │
                    │                        │
     ┌──────────────┤                        ├──────────────┐
     │              │    SHARED SKY WORLD    │              │
     │  Console     │    Cross-save          │  PC          │
     │  Players     │    Cross-play          │  Players     │
     │  (Core       │    Shared community    │  (Growing    │
     │   gamers)    │                        │   audience)  │
     └──────────────┤                        ├──────────────┘
                    │                        │
                    └────────────────────────┘
```

**Cross-platform benefits**:
- **Expanded audience**: Each platform reaches different demographics
- **Increased engagement**: Players can continue on their preferred device
- **Cross-save loyalty**: Once invested across platforms, players are more committed
- **Marketing reach**: More platforms = more store features, more discovery surfaces
- **Content opportunities**: Platform-specific moments create marketing content

---

## 27.2 Mobile-First Strategy (iOS & Android)

### Why Mobile Remains Primary

| Factor | Mobile Advantage |
|--------|-----------------|
| **Audience size** | 99% of CN gaming is mobile-first |
| **Accessibility** | Everyone has a phone; lowest barrier to play |
| **Session flexibility** | Can play anywhere, anytime, for any duration |
| **Social integration** | WeChat, QQ sharing built into mobile ecosystem |
| **Revenue driver** | Mobile IAP is the primary revenue channel |

### Mobile-Specific Marketing

| Tactic | Details |
|--------|---------|
| **Screenshot culture** | Sky's visual beauty makes mobile screenshots shareable social currency |
| **Quick-session content** | Promote Sky as "5 minutes of peace" for busy mobile users |
| **Social sharing** | Deep links, WeChat Mini-Program integration, social invite mechanics |
| **Mobile-native video** | Vertical video (9:16) for Douyin, XHS; capture directly from mobile gameplay |
| **Touch-friendly content** | Interactive H5 pages, mini-games, swipeable galleries |

### iOS vs. Android Marketing Differences

| Dimension | iOS | Android (CN) |
|-----------|-----|-------------|
| **Distribution** | Single App Store | 10+ stores (see Module 22) |
| **ASO** | One listing to optimize | Multiple listings to maintain |
| **Featuring** | Apple editorial team | Per-store editorial teams |
| **Ad attribution** | SKAdNetwork (limited post-iOS 14.5) | OAID + store attribution |
| **User profile** | Slightly higher income; design-conscious | Broader; device diversity |
| **Payment** | Apple Pay / via App Store | Alipay, WeChat Pay, carrier billing |
| **Update speed** | Apple review (1–3 days) | Per-store review (varies) |

---

## 27.3 Console Publishing (PlayStation & Nintendo Switch)

### PlayStation in CN

| Aspect | Details |
|--------|---------|
| **PS Store CN** | Available but smaller than global; requires CN PSN account |
| **Audience** | Core gamers; quality-focused; willing to pay for premium experiences |
| **Sky positioning** | "A console-quality experience" — validates Sky as more than a mobile game |
| **Marketing channels** | PlayStation official channels; gaming media; Bilibili gaming community |
| **Pricing** | Sky is free-to-play on PS; IAP matches mobile pricing |

### Nintendo Switch in CN

| Aspect | Details |
|--------|---------|
| **Tencent-distributed** | Nintendo Switch sold in China through Tencent partnership |
| **CN eShop** | Limited game library; unique market dynamics |
| **Audience** | Family-oriented; core Nintendo fans; collectors |
| **Sky positioning** | "Play Sky on the big screen with friends on the couch" |
| **Marketing channels** | Tencent Switch channels; gaming media; Switch community on Weibo/Bilibili |

### Console Marketing Strategy

| Tactic | Purpose |
|--------|---------|
| **Platform-exclusive launch campaign** | When Sky launches on a new console, run a dedicated campaign |
| **"Best of both worlds" messaging** | "Your phone Sky journey continues on the big screen" |
| **Controller/couch experience content** | Show Sky played comfortably on TV; highlight enhanced visuals |
| **Cross-save promotion** | "Start on mobile, continue on console — your progress follows you" |
| **Console community engagement** | Dedicated content for console-specific communities |
| **Platform partnership** | Work with PlayStation/Nintendo for featuring and co-marketing |

### Console Content Creation Tips

| Element | Mobile Content | Console Content |
|---------|---------------|----------------|
| **Aspect ratio** | 9:16 (vertical) | 16:9 (horizontal/widescreen) |
| **Visual focus** | Close-ups work on small screens | Wide shots showcase big-screen beauty |
| **Controller prompts** | Touch gestures | Button prompts (X, O, etc.) |
| **Screenshot quality** | Mobile resolution | 1080p/4K screenshots available |
| **Sharing** | Direct to social apps | Capture gallery → transfer → share |

---

## 27.4 PC Publishing (Steam & Beyond)

### Steam in CN

| Aspect | Details |
|--------|---------|
| **Steam CN** | Massive CN user base (~30M+ concurrent peak); accessed via standard Steam client |
| **Discovery** | Steam's algorithm + wishlist + curator system |
| **Community** | Steam Community forums, reviews, guides, workshop |
| **Pricing** | Regional pricing for China is critical (usually 60–70% of US price) |
| **Payment** | Alipay, WeChat Pay supported on Steam |

### PC Marketing Strategy

| Tactic | Details |
|--------|---------|
| **Steam page optimization** | Compelling trailer, screenshots, description, tags |
| **Wishlist campaigns** | Drive wishlists before launch/major updates — wishlists trigger notification emails |
| **Steam community engagement** | Post announcements, respond to forums, curate guides |
| **PC gaming media** | GameLook, 游研社, 机核 (Gcores) — PC gaming focused outlets |
| **Bilibili PC gaming community** | Many Bilibili creators focus on PC gaming |
| **Steam events** | Participate in Steam sales events, festivals, seasonal events |
| **Content creator programs** | Steam curator outreach; PC gaming KOLs |

### PC-Specific Marketing Advantages

| Advantage | Marketing Opportunity |
|-----------|---------------------|
| **Higher graphical fidelity** | Showcase Sky at maximum visual quality for marketing assets |
| **Steam screenshot feature** | Players can easily capture and share high-quality screenshots |
| **Streaming-friendly** | PC is the primary streaming platform — encourage streamers |
| **Modding community** | If Sky supports mods, this creates content ecosystem |
| **Ultra-wide / high-res** | Create stunning wallpapers and visual content from PC version |

### Steam-Specific Metrics

| Metric | Where to Track | What It Tells You |
|--------|---------------|------------------|
| **Wishlists** | Steamworks dashboard | Pre-launch demand; future download potential |
| **Wishlist conversion** | Steamworks | What % of wishlists convert to installs |
| **Concurrent players** | SteamDB / Steamworks | Active engagement; peak timing |
| **Reviews** | Steam store page | Player sentiment; affects visibility |
| **Positive review %** | Steam store page | "Mostly Positive" → "Very Positive" → "Overwhelmingly Positive" |
| **Revenue** | Steamworks | PC revenue contribution |

---

## 27.5 Cross-Platform Features & Marketing

### Cross-Save

**What it is**: Players can transfer their progress between platforms — play on phone during commute, continue on PS5 at home.

**Marketing this feature**:
| Message | Platform |
|---------|----------|
| "你的旅程，不受屏幕限制" (Your journey, unlimited by screen size) | All |
| "手机上的记忆，大屏幕上继续" (Memories from your phone, continued on the big screen) | Console launch campaigns |
| Step-by-step guide: "How to set up cross-save" | Bilibili tutorial, XHS guide |
| "One account, every platform" | App store descriptions |

### Cross-Play

**What it is**: Players on different platforms can play together in the same world.

**Marketing this feature**:
| Message | Context |
|---------|---------|
| "无论你在手机还是电脑，同一片云海等你" | Cross-platform launch |
| Show friends playing together — one on phone, one on console | Video content |
| "Bring your Switch-playing friend to meet your mobile friends" | Platform expansion campaigns |

### Platform-Exclusive Content

If Sky offers any platform-exclusive items:

| Approach | Details |
|----------|---------|
| **Celebrate, don't exclude** | "PS players get a special cape!" not "Only PS players get this" |
| **Time-limited exclusivity** | Consider making exclusives time-limited, then available everywhere |
| **Platform identity** | Exclusives should reflect the platform's identity |

---

## 27.6 Cross-Platform Launch Playbook

When Sky launches on a new platform:

### Phase 1: Announcement (T-8 to T-4 weeks)

| Activity | Details |
|----------|---------|
| **Platform announcement trailer** | Showcase Sky on the new platform; highlight enhanced features |
| **Press release** | Distributed to gaming media and platform-specific media |
| **Community communication** | Inform existing players; explain cross-save |
| **Platform partnership** | Coordinate with platform holder for co-marketing |
| **Pre-registration/wishlist** | Drive pre-launch commitment on the new platform's store |

### Phase 2: Build-Up (T-4 to T-1 week)

| Activity | Details |
|----------|---------|
| **KOL seeding** | Platform-specific KOLs get early access |
| **Tutorial content** | "How to play Sky on [platform]"; cross-save setup guides |
| **Community Q&A** | Address player questions about the new platform version |
| **Store page optimization** | App store/Steam page fully optimized with platform-specific screenshots |
| **Cross-promotion** | In-game messaging to existing players about the new platform |

### Phase 3: Launch (T-Day to T+2 weeks)

| Activity | Details |
|----------|---------|
| **Launch day campaign** | Coordinated across all social platforms |
| **Platform-specific content** | Content showing Sky's best on the new platform |
| **Existing player bridge** | Encourage mobile players to try the new platform |
| **New player welcome** | Content for players discovering Sky through the new platform |
| **Feature request** | Push for platform store featuring on launch day |
| **Performance monitoring** | Track installs, retention, and revenue on new platform |

### Phase 4: Sustain (T+2 weeks onwards)

| Activity | Details |
|----------|---------|
| **Regular cross-platform content** | Include new platform footage in ongoing content |
| **Platform community building** | Establish presence in platform-specific communities |
| **Cross-platform events** | Events that encourage playing across platforms |
| **Ongoing store optimization** | Continue optimizing store presence; pursue featuring opportunities |

---

## 27.7 Platform-Specific Community Management

### Where Each Platform's Community Lives

| Platform | Primary Community Spaces |
|----------|------------------------|
| **iOS/Android** | Bilibili, XHS, Douyin, WeChat, Weibo, TapTap |
| **PlayStation** | PSN community, Bilibili PS gaming section, A9VG forum, PlayStation official Weibo |
| **Nintendo Switch** | Switch community on Bilibili, Weibo, dedicated Switch forums |
| **PC/Steam** | Steam Community forums, Steam reviews, Bilibili PC gaming section, 机核 (Gcores) |

### Cross-Platform Community Dynamics

| Dynamic | How to Handle |
|---------|---------------|
| **Mobile players feeling "superior"** | Celebrate all platforms equally; focus on shared experience |
| **Console players wanting exclusive treatment** | Offer platform acknowledgment; avoid hierarchy |
| **PC players expecting more features** | Be transparent about platform parity goals; manage expectations |
| **Cross-save confusion** | Create clear, visual guides; FAQ for common issues |
| **Performance comparisons** | Acknowledge differences; focus on the universal emotional experience |

---

## 27.8 Cross-Platform Analytics

### Unified Dashboard View

Track these metrics per platform AND in aggregate:

| Metric | Per Platform | Aggregate | Why |
|--------|-------------|-----------|-----|
| **DAU/MAU** | Yes | Yes | Understand platform contribution and total reach |
| **New installs** | Yes | Yes | Which platforms are growing? |
| **Retention** | Yes | Yes | Which platforms retain best? |
| **Revenue** | Yes | Yes | Which platforms monetize best? |
| **Session duration** | Yes | Yes | Engagement depth per platform |
| **Cross-save usage** | — | Yes | How many players use multiple platforms? |
| **Platform overlap** | — | Yes | Avoid double-counting users |

### Platform Health Matrix

```
                   HIGH REVENUE
                       ▲
                       │
      Console          │         Mobile (iOS)
      (high value,     │         (high volume,
       lower volume)   │          high value)
                       │
  LOW ─────────────────┼──────────────────► HIGH
  VOLUME               │                    VOLUME
                       │
      New platforms    │         Mobile (Android)
      (growing)        │         (highest volume,
                       │          developing value)
                       │
                       ▼
                   LOW REVENUE
```

---

## Knowledge Check

1. Sky is launching on a new platform (e.g., PC/Steam) in China in 8 weeks. Design a comprehensive marketing plan covering announcement through post-launch.
2. A mobile player asks "Why should I also play on PlayStation?" Create 5 compelling reasons.
3. The Steam version's reviews are "Mixed" (65% positive) while mobile is 4.7 stars. The complaints are about controls. What's your marketing and communication plan?
4. Design a cross-platform event that encourages mobile players to try the PC version and vice versa.
5. How would you allocate a ¥200,000 marketing budget across mobile, console, and PC for a cross-platform campaign? Justify your split.

---

[← Module 15: Beta Testing & New Game Launch](15-beta-testing-launch.md) | [Next: Module 17 — Agency, Partner & KOL Collaboration →](17-agency-partner-collab.md) | [Main Guide](../README.md)
