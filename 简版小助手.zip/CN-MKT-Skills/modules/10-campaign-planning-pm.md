# Module 10: Campaign Planning & Project Management

> Great campaigns don't happen by accident. They're built on clear objectives, tight timelines, owned tasks, and relentless follow-through — across platforms and time zones.

---

## 10.1 Campaign Types for Sky CN

| Campaign Type | Trigger | Duration | Scale |
|--------------|---------|----------|-------|
| **Season Launch** | New season release | 2–4 weeks | Large |
| **In-Game Event** | Days of Fortune, Days of Love, etc. | 1–2 weeks | Medium-Large |
| **Partnership/Collab** | Brand or cultural collaboration | 2–6 weeks | Medium-Large |
| **Always-On** | Ongoing content cadence | Continuous | Small |
| **UA Burst** | Growth push, re-engagement | 1–4 weeks | Medium |
| **Community Event** | Fan art contest, music challenge | 1–3 weeks | Small-Medium |
| **Crisis/Reactive** | Backlash, trending opportunity | 1–3 days | Variable |

---

## 10.2 The Campaign Planning Framework

### 7-Step Process

#### Step 1: Define the Objective (目标)
Every campaign answers: **What is the ONE thing this must achieve?**

| Objective Type | Example | Primary KPI |
|----------------|---------|-------------|
| **Awareness** | Introduce Sky to new audiences | Impressions, reach |
| **Engagement** | Deepen connection with current players | Engagement rate, UGC volume |
| **Acquisition** | Drive new downloads | Installs, CPI, Day 1 retention |
| **Retention** | Bring back lapsed players | Reactivation rate, DAU lift |
| **Revenue** | Drive season pass or IAP sales | Revenue, conversion rate |
| **Brand** | Elevate cultural positioning | Sentiment score, press coverage |

#### Step 2: Identify the Audience
Reference Module 02 personas. Specify:
- **Primary**: Who MUST this reach?
- **Secondary**: Who would benefit?
- **Exclusions**: Who is this NOT for?

#### Step 3: Craft the Core Message (核心信息)

| Component | Description | Example (Season Launch) |
|-----------|-------------|------------------------|
| **Insight** | Truth about the audience | "Players crave new stories and reasons to reunite" |
| **Message** | Single most important takeaway | "A new chapter of wonder awaits — explore together" |
| **Proof point** | What supports this? | New realm, new spirits, new cosmetics |
| **Emotional takeaway** | How should people FEEL? | Excited, curious, nostalgic |

#### Step 4: Choose Channels & Tactics
Per Module 04, select:
- **Lead platform(s)**: Primary content home
- **Support platforms**: Amplification
- **Paid media**: Channels and formats
- **KOL/KOC**: Creators and scale

#### Step 5: Create the Content Plan

| Deliverable | Platform | Format | Owner | Due Date |
|------------|----------|--------|-------|----------|
| Season trailer (60s) | Bilibili, Douyin | Video | Creative | T-14 |
| Teaser poster set (3x) | All | Image | Design | T-10 |
| KOL brief | — | Document | Marketing | T-21 |
| XHS notes (5x) | Xiaohongshu | Image+text | Content | T-7 to T+7 |
| WeChat article | WeChat | Long-form | Content | T-day |

#### Step 6: Build the Timeline

```
T-28  ───── T-21  ───── T-14  ───── T-7  ───── T-Day ───── T+7  ───── T+14
  │           │           │          │         │          │           │
Strategy    KOL brief   Creative   Teaser    LAUNCH    Sustain    Wrap-up
& brief     & outreach  review     phase     day       phase      & 复盘
```

#### Step 7: Measure & 复盘
Every campaign ends with a post-mortem (see section 10.9).

---

## 10.3 Team Roles & Responsibilities

### Typical CN Marketing Team Structure

```
                    ┌──────────────────┐
                    │  CN Marketing    │
                    │  Lead            │
                    └────────┬─────────┘
          ┌──────────────────┼──────────────────┐
  ┌───────┴───────┐  ┌──────┴──────┐  ┌───────┴───────┐
  │ Content &     │  │ Community   │  │ UA & Growth   │
  │ Creative      │  │ Manager     │  │ Manager       │
  └───────────────┘  └─────────────┘  └───────────────┘
          └──────────── External Partners ──────┘
```

### RACI Matrix

| Activity | Marketing Lead | Content/Creative | Community | UA/Growth | NetEase | HQ |
|----------|:---:|:---:|:---:|:---:|:---:|:---:|
| **Campaign strategy** | A | C | C | C | I | C |
| **Content calendar** | A | R | C | I | I | I |
| **Daily social posts** | I | R | C | I | — | — |
| **Community response** | I | I | R | — | I | — |
| **KOL campaigns** | A | R | C | C | I | I |
| **Paid media** | A | C | — | R | C | I |
| **ASO optimization** | I | C | — | R | R | — |
| **Budget tracking** | R | I | I | I | — | I |
| **Crisis response** | A | R | R | I | C | C |
| **Season launch plan** | A | R | C | R | C | C |

> **R** = Responsible | **A** = Accountable | **C** = Consulted | **I** = Informed

---

## 10.4 Campaign Checklist

```
═══════════════════════════════════════
  CAMPAIGN CHECKLIST
  Campaign: [Name]  Lead: [Name]
═══════════════════════════════════════

□ PLANNING
  □ ONE primary objective defined
  □ KPIs and targets set
  □ Budget allocated and approved
  □ Target audience defined
  □ Key messages finalized
  □ Platform strategy decided
  □ RACI assigned
  □ Timeline with milestones
  □ Dependencies identified
  □ HQ alignment confirmed

□ PREPARATION
  □ Creative brief written
  □ Agency/partner briefed
  □ Content calendar built
  □ KOLs identified and briefed
  □ Paid media plan ready
  □ Tracking/attribution set up
  □ Legal/compliance reviewed

□ PRODUCTION
  □ All assets produced and reviewed
  □ Platform-specific adaptations done
  □ All exports in correct specs
  □ Copy finalized per platform
  □ Scheduling tools set up

□ LAUNCH
  □ Content published on schedule
  □ Paid media activated
  □ Community team ready
  □ Monitoring dashboard active

□ POST-CAMPAIGN
  □ Data collected
  □ 复盘 meeting held
  □ Learnings documented
  □ Report shared
  □ Assets archived
═══════════════════════════════════════
```

---

## 10.5 Creative Brief Template

```
═══════════════════════════════════════
         CREATIVE BRIEF — SKY CN
═══════════════════════════════════════
Project:    [Name]
Owner:      [Name]
Due:        [Date]
───────────────────────────────────────
1. OBJECTIVE: [What must this achieve?]
2. AUDIENCE: [Who is this for?]
3. KEY MESSAGE: [ONE takeaway]
4. DELIVERABLES: [Exact specs]
5. MANDATORY ELEMENTS: [Logo, hashtags, legal]
6. TONE & STYLE: [How should it feel?]
7. TIMELINE: [Draft → Feedback → Final → Live]
8. APPROVALS: [CN Lead → HQ → NetEase → Legal]
═══════════════════════════════════════
```

### Content Approval Flow

```
Creator → CN Marketing Lead → [HQ Brand Review] → [NetEase Review] → Publish
  │              │                    │                   │
Draft 1      Feedback             Feedback           Final OK
(T-14)       (T-12)              (T-10)              (T-7)
```

---

## 10.6 Content Calendar Management

### Weekly Content Calendar

```
         │ Bilibili │ Douyin  │ XHS     │ WeChat  │ Weibo
─────────┼──────────┼────────┼─────────┼─────────┼──────
Monday   │          │ Short  │         │         │
Tuesday  │          │        │ Guide   │         │ Topic
Wednesday│ Video    │ Short  │         │         │
Thursday │          │        │ Feature │ Article │
Friday   │          │ Short  │         │         │ Fan
Weekend  │          │ Special│ Lifestyle│        │
```

### Best Practices
| Practice | Details |
|----------|---------|
| **Plan 2 weeks ahead** | 1 week approved and staged |
| **Leave flex slots** | 20–30% for reactive/trending content |
| **Link to assets** | Each entry links to actual content files |
| **Note dependencies** | Flag what depends on HQ, agencies, game updates |
| **Weekly review** | Team reviews next week's calendar every Friday |

---

## 10.7 Annual Campaign Calendar

| Month | Key Moment | Type | Priority |
|-------|-----------|------|----------|
| **Jan** | Pre-CNY buildup | Teaser + warmup | High |
| **Feb** | Chinese New Year (Days of Fortune) | Major event | Highest |
| **Mar** | New season launch (typical) | Season launch | High |
| **May** | Anniversary | Celebration | High |
| **Jun** | Summer / graduation | Youth-oriented | Medium |
| **Jul** | Summer vacation peak | UA burst | High |
| **Sep** | Mid-Autumn Festival | Seasonal event | High |
| **Oct** | National Day holiday | Engagement push | Medium |
| **Dec** | Year-end / Days of Feast | Community, retrospective | High |

### Campaign Lead Times
| Scale | Planning Start | Creative Start | Go-Live |
|-------|---------------|----------------|---------|
| **Major** | T-8 weeks | T-6 weeks | T-Day |
| **Medium** | T-6 weeks | T-4 weeks | T-Day |
| **Small** | T-3 weeks | T-2 weeks | T-Day |
| **Reactive** | T-1 day | T-1 day | ASAP |

---

## 10.8 Sprint-Based Marketing Operations

### 2-Week Sprint Structure

```
WEEK 1
Monday    │ Sprint planning (30 min): goals, assign tasks
Tue–Thu   │ Execution
Friday    │ Prepare next week's content

WEEK 2
Mon–Wed   │ Execution
Thursday  │ Sprint wrap-up: finalize deliverables
Friday    │ Sprint review + retrospective (30 min)
```

### Async Daily Standup (WeChat)
Each team member by 10 AM:
```
【Today — [Name]】
✅ Yesterday: [Done]
📌 Today: [Working on]
🚧 Blockers: [Issues or "None"]
```

---

## 10.9 The 复盘 (Post-Mortem) Process

### 复盘 Meeting (60 minutes)

```
1. CONTEXT RESET (5 min)
   What was the campaign? Original objectives?

2. RESULTS REVIEW (15 min)
   Actual results vs. targets — show data

3. WHAT WENT WELL (10 min)
   Specifics: "Douyin video hit 500K because
   we published at 7 PM Friday" ✓
   Not: "The video did well" ✗

4. WHAT DIDN'T GO WELL (10 min)
   Focus on process, not blame:
   "Approval took 5 days because we didn't
   flag to HQ early enough" ✓

5. ROOT CAUSE ANALYSIS (10 min)
   Ask "Why?" 3 times for each major issue

6. ACTION ITEMS (10 min)
   Max 5 items, each with OWNER and DEADLINE
```

### 复盘 Report Template
```
═══════════════════════════════════════
  CAMPAIGN 复盘 REPORT
  Campaign: [Name]  Period: [Dates]
═══════════════════════════════════════
SUMMARY: [1 paragraph]

OBJECTIVES vs. RESULTS:
  [Target] → [Actual] (✓/✗)

BUDGET: Planned ¥[X] → Actual ¥[X]

TOP 3 WINS: [With data evidence]
TOP 3 LEARNINGS: [With what to change]

ACTION ITEMS:
  □ [Action] — [Owner] — [Due]
═══════════════════════════════════════
```

---

## 10.10 Dependency & Risk Management

### Common Dependencies

| Dependency | Risk | Mitigation |
|-----------|------|-----------|
| **HQ approves creative** | High delay risk | Submit 5+ business days early |
| **Agency delivers assets** | Medium | Firm dates with buffer |
| **Game update ships** | Critical | Coordinate with dev; have backup content |
| **KOL creates content** | Medium | Brief early; have backup KOL list |
| **Platform reviews content** | Medium | Submit early; know review timelines |

### Season Launch Dependency Chain
```
Game update confirmed (Dev/HQ)
  ├── Trailer received → CN localization → Platform exports → Schedule
  ├── Key art received → Social posts designed → Copy written → Schedule
  ├── Season briefed to KOLs → Content created → Reviewed → Published
  └── Paid media set up → Creative loaded → Campaigns activated on launch
```

### Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|-----------|
| Game update delayed | Medium | High | Backup content; flexible calendar |
| Agency delivers late | Medium | Medium | Buffer in timelines; backup vendors |
| HQ approval delayed | High | Medium | Submit early; provide full context |
| KOL cancels | Low | Medium | Backup KOL list; diversify |
| Negative PR / crisis | Low | Very High | Crisis plan ready (Module 09) |
| Budget cut mid-campaign | Low | High | Prioritize must-have from start |

---

## 10.11 Budget Planning

### Allocation Model

| Category | Season Launch | Event | Always-On |
|----------|-------------|-------|-----------|
| **Content production** | 25% | 30% | 40% |
| **Paid media** | 35% | 25% | 30% |
| **KOL/KOC** | 25% | 30% | 20% |
| **Community activation** | 10% | 10% | 5% |
| **Contingency** | 5% | 5% | 5% |

Track weekly: committed vs. actual spend, CPM/CPI trends, reallocation decisions.

---

## 10.12 Tools & File Management

### Recommended Tools

| Function | Options |
|----------|---------|
| **Project management** | 飞书, Notion, Teambition, Asana |
| **Communication** | WeChat (daily), 飞书 (formal), Email (external) |
| **Content calendar** | 飞书 Docs, Notion, Google Sheets |
| **Creative review** | 蓝湖, Figma, WeChat markup |
| **Reporting** | 飞书 Sheets, Google Sheets |

### File Naming Convention
```
[Date]_[Campaign]_[Type]_[Platform]_[Version]
20260215_CNY_Video-30s_Douyin_v2.mp4
```

---

## Knowledge Check

1. Walk through the 7-step process for a Mid-Autumn Festival event campaign.
2. It's Friday — three of five next-week posts are missing final assets (one awaits HQ, one awaits agency, one awaits KOL). Action plan?
3. Build a 4-week season launch project plan with phases, milestones, owners, and dependencies.
4. A campaign exceeded engagement targets by 40% but went 20% over budget. Write the 复盘 summary and three action items.
5. Your team uses WeChat for everything — briefs, feedback, approvals, files. What problems does this create, and how would you introduce better tools?

---

## Related Modules
- [Module 08: Creative Production](08-creative-production.md) — Creative specs and formats
- [Module 12: Budget Management](12-budget-management.md) — Detailed ROI frameworks
- [Module 17: Agency & Partner Collaboration](17-agency-partner-collab.md) — Working with external partners
- [Module 19: Cross-Border Teamwork](19-cross-border-teamwork.md) — Cross-timezone workflows

---

[← Module 09: Community Building](09-community-building.md) | [Next: Module 11 — Marketing SOPs →](11-marketing-sops.md) | [Main Guide](../README.md)
