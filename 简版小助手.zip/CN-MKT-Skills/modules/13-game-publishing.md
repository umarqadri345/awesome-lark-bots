# Module 13: Game Publishing Fundamentals for CN Market

> Publishing a game in China is not just distribution — it's navigating a unique ecosystem of regulations, partnerships, platforms, and player expectations that exists nowhere else in the world.

---

## 21.1 What Is Game Publishing?

### Publishing vs. Development vs. Marketing

| Function | Responsibility | Sky Context |
|----------|---------------|-------------|
| **Development** | Build the game — design, code, art, audio | thatgamecompany (HQ in LA) |
| **Publishing** | Bring the game to market — licensing, distribution, localization, monetization, live ops | NetEase (CN publisher) + tgc |
| **Marketing** | Build awareness, acquire users, engage community, drive revenue | CN Marketing Team (you) |

Marketing sits at the intersection of development and publishing. You need to understand publishing mechanics to do your job well.

### Why CN Publishing Knowledge Matters for Marketers
- **Launch timing and content availability** are determined by publishing decisions — you market what's available
- **Monetization and pricing** directly affect your messaging and campaign strategy
- **Platform relationships** (app stores, distribution channels) impact your UA strategy
- **Regulatory approvals** determine what content can be marketed and when
- **NetEase coordination** requires understanding their publishing processes and priorities

---

## 21.2 The CN Game Publishing Ecosystem

### How Games Reach CN Players

```
Developer        Publisher         Regulatory        Distribution       Player
(tgc)       →    (NetEase)    →    Approval     →    Channels      →   Downloads
                                   (NPPA 版号)       (App stores,        & plays
                                                     Android stores)
```

### Key Players in CN Game Publishing

| Player | Role | Sky Relationship |
|--------|------|-----------------|
| **Developer (tgc)** | Creates the game; owns the IP | Core team; brand owner |
| **Publisher (NetEase)** | Holds CN publishing rights; manages operations, servers, payments | Primary partner |
| **NPPA** | Government regulator; issues 版号 (game license) | Must have approval to operate |
| **Apple App Store** | iOS distribution | Primary iOS channel |
| **Android stores** | Multiple CN Android stores | Multiple distribution channels |
| **Payment providers** | Alipay, WeChat Pay, etc. | Enable in-app purchases |
| **Cloud/server providers** | Hosting infrastructure | Ensure smooth gameplay |

### The Publisher-Developer Relationship

In Sky's case, tgc (developer) and NetEase (publisher) have a partnership that defines:

| Area | Typically Developer-Led | Typically Publisher-Led | Shared |
|------|------------------------|----------------------|--------|
| **Game design** | ✓ | | |
| **Content creation** | ✓ | | |
| **Brand identity** | ✓ | | |
| **CN localization** | | ✓ | ✓ |
| **Server operations** | | ✓ | |
| **Payment processing** | | ✓ | |
| **Regulatory compliance** | | ✓ | ✓ |
| **Marketing strategy** | | | ✓ |
| **User acquisition** | | | ✓ |
| **Customer support** | | ✓ | |
| **Revenue sharing** | | | ✓ (per contract) |

### Navigating the Publisher Relationship as a Marketer

| Principle | Details |
|-----------|---------|
| **Respect their expertise** | NetEase understands CN operations deeply — leverage their knowledge |
| **Communicate proactively** | Share campaign plans early; avoid surprising your partner |
| **Align incentives** | Both sides want Sky to succeed — frame requests in terms of shared goals |
| **Understand their constraints** | NetEase publishes many games — Sky competes for internal resources |
| **Build personal relationships** | Key individuals at NetEase are your allies — invest in those relationships |
| **Document agreements** | Written alignment on plans, responsibilities, and timelines prevents misunderstandings |

---

## 21.3 The CN Game Approval Process

### 版号 (ISBN / Publication Number)

Every game commercially released in China requires a 版号 from the NPPA.

**What Marketers Need to Know**:

| Topic | Details |
|-------|---------|
| **What it is** | A government-issued license to operate a game commercially in China |
| **Who handles it** | NetEase (as publisher) manages the application process |
| **How long it takes** | Historically 3–18+ months; varies by regulatory climate |
| **What it covers** | The specific game version reviewed; significant updates may need re-review |
| **Marketing impact** | Cannot do commercial marketing for unapproved content; cannot sell unapproved IAP items |
| **版号 freezes** | Periodically, NPPA pauses new approvals — this can delay launches and updates |

### Content Review Requirements

Games must pass content review covering:

| Area | Requirement | Sky Relevance |
|------|------------|---------------|
| **Cultural values** | Must promote positive social values | Sky's prosocial themes are a natural fit |
| **Political content** | No content threatening national unity or sovereignty | Review global content for sensitivity |
| **Religious content** | No proselytizing or inappropriate religious depictions | Sky's spiritual themes need careful positioning |
| **Violence** | Must be age-appropriate; no excessive gore | Sky is inherently non-violent — low risk |
| **Gambling mechanics** | Gacha/random rewards need probability disclosure | If Sky adds random mechanics, must comply |
| **Historical accuracy** | Historical references must be accurate and respectful | Any historical season themes need review |
| **Map/territorial** | Maps must show China's territory correctly | Any in-game maps need compliance review |
| **Language** | No inappropriate language or slang | Localization must be clean |

### Marketing Implications of Approval Process

| Scenario | Marketing Impact | Action |
|----------|-----------------|--------|
| **New season content awaiting approval** | Cannot promote unapproved features/items | Tease with approved-only content; coordinate timing with NetEase |
| **Content differs between global and CN versions** | CN players see differences; may cause frustration | Address proactively; explain CN-specific adaptations |
| **Approval delay for new update** | Launch date uncertainty | Build flexible campaign timelines; prepare backup content |
| **Content modification required for CN** | Some elements changed or removed for CN compliance | Frame positively; emphasize what CN players DO get |

---

## 21.4 CN Distribution Channels

### iOS Distribution

| Channel | Details |
|---------|---------|
| **Apple App Store (CN)** | Single iOS distribution channel; standard 30% Apple commission (reduced rates for smaller developers) |
| **ASO priority** | Apple Search Ads available; optimize listing for CN App Store (see Module 05) |
| **Payment** | Apple Pay / credit card / Alipay (via Apple) |
| **Update process** | App Store review for each update (typically 1–3 days) |

### Android Distribution — The Fragmented Landscape

Unlike most markets where Google Play dominates, China has **no Google Play**. Instead, there are dozens of Android app stores:

| Store | Parent Company | Market Share (approx.) | Priority |
|-------|---------------|----------------------|----------|
| **华为应用市场 (Huawei AppGallery)** | Huawei | ~30–40% of Android | ★★★★★ |
| **OPPO 软件商店** | OPPO | ~15–20% | ★★★★☆ |
| **vivo 应用商店** | vivo | ~15–20% | ★★★★☆ |
| **小米应用商店 (Xiaomi)** | Xiaomi | ~10–15% | ★★★★☆ |
| **应用宝 (Myapp)** | Tencent | ~10% | ★★★☆☆ |
| **TapTap** | XD Inc. | ~5% (high-value gamers) | ★★★★☆ |
| **360手机助手** | 360 | ~3% | ★★☆☆☆ |
| **百度手机助手** | Baidu | ~2% | ★★☆☆☆ |
| **Others** | Various | ~5–10% | ★☆☆☆☆ |

**Why This Matters for Marketing**:
- **Each store is a separate relationship** — NetEase manages these, but marketing can leverage store partnerships
- **Featured placements** drive massive downloads — coordinate with NetEase for featuring requests
- **Different commission rates** — stores take 30–50% of IAP revenue; this affects overall economics
- **Store-specific promotions** — some stores offer promotional slots, push notifications, or special placements
- **UA campaigns** must account for multi-store distribution — attribution is more complex

### TapTap — The Gamer's Store

TapTap deserves special attention:
- **Zero commission** model (takes no revenue share) — attracts engaged gamers
- **Community-driven** — reviews and ratings heavily influence downloads
- **Pre-registration** feature builds anticipation for new content
- **Forum/community** section is active — monitor and engage
- **High-quality audience** — TapTap users are more engaged and valuable on average

---

## 21.5 The Publishing Calendar

### Understanding the Publishing Rhythm

Game publishing follows predictable cycles that marketing must sync with:

```
Content     →  Localization  →  QA/Testing  →  Regulatory   →  Submission   →  Launch
Development    & Adaptation     & Bug Fix      Review (if      to Stores       Day
(tgc HQ)       (NetEase/tgc)   (NetEase)     required)       (NetEase)
```

### Key Publishing Milestones That Affect Marketing

| Milestone | What It Means | Marketing Action |
|-----------|--------------|------------------|
| **Content lock** | Game content is finalized | Begin creating marketing assets |
| **Localization complete** | CN text, voice, and cultural adaptation done | Review for marketing messaging alignment |
| **Build submitted to stores** | Game update sent for app store review | Prepare launch-day content |
| **Store approval received** | App stores approve the update | Confirm launch date; finalize all campaigns |
| **Launch / go-live** | Content available to players | Execute launch campaigns |
| **Hotfix / patch** | Bug fixes deployed post-launch | Communicate to community if needed |

### Coordinating with Global Launch Calendar

| Scenario | Challenge | Solution |
|----------|----------|----------|
| **Global and CN launch simultaneously** | Tight timeline; CN-specific approvals needed | Start CN prep earlier; have CN marketing assets ready before global announcement |
| **CN launch delayed vs. global** | CN players see global spoilers/content online | Acknowledge the delay; provide CN-specific timeline; manage expectations |
| **CN-exclusive content** | Additional content for CN market | Promote as special; creates positive CN-specific narrative |
| **Content removed for CN version** | Players notice missing features | Be transparent about what's different; emphasize what CN players uniquely get |

---

## 21.6 Pre-Launch & Soft Launch Strategy

### Pre-Registration Campaigns

Pre-registration builds anticipation and creates a launch-day install base:

| Platform | Pre-Reg Feature | Marketing Tactics |
|----------|----------------|-------------------|
| **Apple App Store** | Pre-order / notify me | Drive to App Store listing |
| **TapTap** | Pre-registration with milestone rewards | Community building + reward milestones |
| **Android stores** | Pre-registration (varies by store) | Store-specific campaigns |
| **WeChat/social** | Interest sign-up via mini-program | Private traffic building |

### Pre-Reg Campaign Elements
1. **Milestone rewards** — "When we reach 500K pre-regs, everyone gets [reward]"
2. **Countdown content** — Daily reveals, teasers, character previews
3. **KOL seeding** — Early access to select creators for preview content
4. **Community building** — Start building community groups before launch

### Soft Launch / Beta Testing

| Phase | Purpose | Scale | Marketing Role |
|-------|---------|-------|---------------|
| **Closed beta (封测)** | Core gameplay testing with small audience | 1,000–10,000 players | Recruit testers from community; NDA management |
| **Open beta (公测)** | Broader testing; stress test servers | 10,000–100,000 players | Broader promotion; feedback collection |
| **Soft launch** | Test monetization and retention in limited market | Select regions or limited release | Monitor metrics; refine launch messaging |

---

## 21.7 Launch Day Operations

### Launch Day Checklist (Marketing Team)

```
T-24 hours:
  □ All content staged and scheduled across platforms
  □ KOL content confirmed and scheduled
  □ Paid media campaigns set to activate
  □ Community announcement drafted and approved
  □ Customer support FAQ prepared
  □ Monitoring dashboards set up
  □ War room / rapid response team confirmed

T-0 (Launch):
  □ Publish launch announcements across all platforms simultaneously
  □ Activate paid media campaigns
  □ Monitor community reaction in real-time
  □ Track download numbers hourly
  □ Respond to early player feedback and questions
  □ Coordinate with NetEase on any technical issues

T+1 to T+3:
  □ Continue monitoring and engagement
  □ Amplify positive community reactions
  □ Address any negative feedback promptly
  □ Optimize paid media based on early performance
  □ Send daily performance updates to HQ

T+7:
  □ First week performance report
  □ KOL content performance review
  □ Community sentiment analysis
  □ Paid media optimization decisions
```

### Common Launch Day Issues & Responses

| Issue | Response |
|-------|----------|
| **Server overload** | Communicate transparently; "We're overwhelmed by the love — working on it!" |
| **App store listing error** | Coordinate with NetEase immediately; post correction on social |
| **Download links not working** | Verify all links across platforms; update immediately |
| **Negative reviews flooding in** | Distinguish bugs (escalate to dev) from complaints (respond empathetically) |
| **KOL content doesn't go live as planned** | Have backup content ready; contact KOL directly |
| **Competitor counter-launch** | Stay focused on Sky; don't react to competition on launch day |

---

## 21.8 Post-Launch Publishing Cycles

### Ongoing Publishing Rhythm

| Cadence | Publishing Activity | Marketing Activity |
|---------|--------------------|--------------------|
| **Daily** | Server maintenance, hotfixes | Community engagement, daily content |
| **Weekly** | Minor updates, bug fixes | Weekly performance review, content calendar |
| **Bi-weekly** | Event rotations, small content updates | Event promotion, community activities |
| **Per season (~10 weeks)** | Major content update (new season) | Full campaign cycle (see Module 06) |
| **Quarterly** | Business review, strategy adjustment | Quarterly reporting, strategy refinement |
| **Annually** | Anniversary, year-end review, next year planning | Anniversary campaign, annual retrospective |

### Version Management

| Version Type | Description | Marketing Awareness |
|-------------|-------------|-------------------|
| **Major update** | New season, significant new features | Full marketing campaign |
| **Minor update** | Bug fixes, balance adjustments, small additions | Community communication |
| **Hotfix** | Emergency fixes for critical bugs | Rapid response if player-facing |
| **Maintenance** | Server maintenance, infrastructure updates | Advance notice to community |

---

## 21.9 Cross-Version Management (Global vs. CN)

### Understanding Version Differences

Sky may have differences between the global and CN versions:

| Area | Potential Differences | Why |
|------|----------------------|-----|
| **Content** | Some content modified or removed for CN compliance | Regulatory requirements |
| **Timing** | CN version may launch content on different dates | Approval timelines, CN holidays |
| **Pricing** | IAP pricing may differ | Market-specific pricing strategy |
| **Features** | Anti-addiction system, real-name registration (CN only) | CN minor protection laws |
| **Server** | Separate CN servers | Data localization requirements |
| **Payment** | Alipay, WeChat Pay instead of Google Pay | Platform availability |

### Managing Player Awareness of Version Differences

| Approach | Details |
|----------|---------|
| **Acknowledge differences honestly** | Don't pretend they don't exist — players compare notes online |
| **Emphasize CN-exclusive benefits** | Days of Fortune content, CN-specific events |
| **Explain without over-explaining** | "Some content has been adapted for the CN version" is sufficient |
| **Avoid direct global comparisons** | Don't publish global-vs-CN content; let community discuss naturally |
| **Highlight shared experience** | Sky's core emotional experience is universal across versions |

---

## 21.10 Publishing Economics

### Revenue Model for Sky CN

```
Player spends ¥68 on Season Pass
         │
         ├── App Store commission (30%): ¥20.40
         │
         └── Net revenue: ¥47.60
              │
              ├── Publisher share (NetEase): [Per contract]
              │
              └── Developer share (tgc): [Per contract]
```

### What Marketers Should Understand About Economics

| Concept | Why It Matters |
|---------|---------------|
| **Revenue share** | Understand that not all player spending reaches tgc; this affects budget justification |
| **LTV (Lifetime Value)** | A player's total spending over their entire relationship with Sky — used to set UA budgets |
| **CPI vs. LTV** | If CPI > LTV, you're losing money on each acquired player — track this ratio |
| **Paying conversion rate** | % of players who ever make a purchase — Sky's rate affects revenue projections |
| **ARPU / ARPPU** | Average revenue per user / per paying user — key health metrics |
| **Seasonal revenue patterns** | Revenue spikes during season launches and events; plan marketing spend accordingly |

---

## Knowledge Check

1. Explain the role difference between developer (tgc), publisher (NetEase), and your marketing team in Sky's CN operation.
2. A new season's content is approved globally but still awaiting CN regulatory review. How do you handle marketing during this gap?
3. Why is Android distribution in China more complex than in other markets? How does this affect your UA strategy?
4. It's launch day for a major update and the servers are struggling. Draft a community message for Weibo.
5. A player asks on Bilibili why CN Sky is "missing" a feature available in the global version. How do you respond?

---

[← Module 12: Budget Management & ROI Analysis](12-budget-management.md) | [Next: Module 14 — Live Ops, Seasons & Monetization →](14-live-ops-monetization.md) | [Main Guide](../README.md)
