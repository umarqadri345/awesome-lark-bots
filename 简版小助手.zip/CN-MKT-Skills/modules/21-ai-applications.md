# Module 21: AI Applications in Marketing

> AI is a force multiplier. Use it to work faster and smarter — but always with human judgment and Sky's brand heart.

---

## 8.1 AI Philosophy for Sky Marketing

### Guiding Principles
1. **AI accelerates, humans decide** — Use AI for speed and scale; use human judgment for brand, tone, and emotional nuance
2. **Quality over quantity** — AI should help create *better* content, not just *more* content
3. **Brand guardrails always apply** — AI output must pass the same brand review as human-created content
4. **Transparency when required** — Follow CN regulations on AI-generated content disclosure
5. **Data privacy first** — Never input player PII into AI tools

### Where AI Adds Most Value

| High Value | Medium Value | Use With Caution |
|-----------|-------------|------------------|
| Content ideation and brainstorming | Social post drafting | Final brand-voice copy |
| Data analysis and reporting | Video script outlines | Emotional storytelling |
| Trend monitoring and social listening | Image concept generation | Community crisis response |
| Translation and localization assist | Hashtag research | Strategic decision-making |
| Competitive intelligence gathering | A/B test variant creation | Player relationship management |

---

## 8.2 AI Tools for Content Creation

### 8.2.1 Copywriting & Content Drafting

**Use Cases**:
- Draft social media post copy in multiple variants
- Generate content calendar ideas for a given theme
- Adapt copy across platforms (long-form to short-form)
- Translate and localize content between EN and CN
- Write KOL briefs and campaign documents

**Workflow: AI-Assisted Copy Creation**
```
Human defines         AI generates          Human reviews         Human refines        Publish
brief/objective  →    3–5 draft options  →  selects best fit  →  for brand voice  →  after approval
```

**Prompt Engineering Tips for Sky Content**:
- Always include brand context: *"You are writing for Sky: Children of the Light (光·遇), a warm, emotional, non-competitive social adventure game. The tone should be gentle, poetic, and inviting."*
- Specify the platform and format: *"Write a Xiaohongshu post (300–500 characters) showcasing a new cosmetic outfit."*
- Provide examples of approved content as reference
- Ask for multiple options: *"Generate 5 variations, ranging from poetic to conversational."*
- Include what to avoid: *"Do NOT use aggressive sales language, competitive comparisons, or excessive exclamation marks."*

**Example Prompt**:
```
You are a content writer for Sky: Children of the Light (光·遇), a beautiful social
adventure game by thatgamecompany. The brand voice is warm, poetic, and inviting —
like a friend sharing a beautiful place.

Write 3 Xiaohongshu post captions (300–400 characters each, in Chinese) for a post
showcasing the new "Cloud Dancer" (云舞者) cosmetic outfit from the Season of Revival.

Include:
- An emotional hook in the first line
- Description of the outfit's visual beauty
- Connection to the season's theme of renewal
- Relevant hashtags

Avoid:
- Sales pressure or urgency language
- Feature lists
- Comparison to other games
```

### 8.2.2 Visual Content & Design

**Use Cases**:
- Generate mood boards and visual concepts for campaigns
- Create social media post templates
- Generate background imagery for presentations
- Prototype campaign visual directions before commissioning final art

**Important Limitations for Sky**:
- AI-generated images should **NOT** be used as final published content representing Sky characters or game scenes — Sky's visual identity is hand-crafted and highly specific
- Use AI images for **internal ideation only** (mood boards, concept exploration)
- Always commission final art from approved artists or use official game assets
- CN regulations increasingly require disclosure of AI-generated visual content

### 8.2.3 Video Content Assistance

**Use Cases**:
- Auto-generate subtitles/captions for videos (then human-review)
- Script outlines for video content
- Video brief creation from reference materials
- Thumbnail concept ideation

**Helpful Tools**:
- AI subtitle generation (剪映/CapCut AI features)
- Script-to-storyboard workflows
- AI video analysis for competitor research

---

## 8.3 AI for Data Analysis & Insights

### 8.3.1 Social Listening & Sentiment Analysis

**Workflow**:
```
Data collection        AI processing         Human analysis        Action
(platform APIs,   →    (sentiment scoring,  →  (context, nuance,  → (respond, adjust,
social listening       trend identification)    strategic meaning)    report)
tools)
```

**Key CN Analytics Platforms**:
- **新榜 (Newrank)** — Cross-platform content analytics
- **蝉妈妈 (Chanmama)** — Douyin analytics
- **千瓜 (Qiangua)** — Xiaohongshu analytics
- **飞瓜 (Feigua)** — Douyin & Kuaishou analytics
- **火烧云 (Huoshaoyun)** — Bilibili analytics

### 8.3.2 Performance Reporting

**AI-Assisted Reporting Workflow**:
1. Export raw data from platform analytics
2. Feed into analysis tool with structured prompts
3. AI generates initial insights and visualizations
4. Human reviews for accuracy and strategic relevance
5. Human adds context, recommendations, and narrative
6. Final report distributed to stakeholders

### 8.3.3 Trend Detection

**Use Cases**:
- Identify trending topics relevant to Sky's audience
- Monitor seasonal trends in gaming content consumption
- Track emerging platform features and algorithm changes
- Spot cultural moments for real-time marketing opportunities

---

## 8.4 AI for Workflow Optimization

### 8.4.1 Translation & Localization

**AI-Assisted Localization Workflow**:
```
Original content     AI translation      Human localization     Cultural review      Final
(EN or CN)       →   (first pass)    →   (tone, nuance,     →  (sensitivity,    →  output
                                          brand voice)          appropriateness)
```

**Best Practices**:
- AI translation is a **starting point**, never the final output
- Cultural nuance requires human expertise (wordplay, idioms, emotional register)
- Maintain a **terminology glossary** for consistency — see the full [Appendix A: Terminology Glossary](../appendix-glossary.md) for the complete reference. Key terms include 光之子 (Children of the Light), 蜡烛 (Candle), 爱心 (Heart), 季卡 (Adventure Pass), 先祖 (Spirit), 光之翼 (Winged Light), and 伊甸 (Eye of Eden).

### 8.4.2 Meeting & Communication Efficiency

- Summarize meeting notes from HQ syncs
- Draft follow-up emails from meeting action items
- Translate and format HQ communications for CN team
- Prepare briefing documents for cross-team meetings

### 8.4.3 Research & Competitive Intelligence

- Summarize competitor campaign activity
- Research platform algorithm changes and best practices
- Compile industry trend reports
- Analyze KOL profile data and audience demographics

---

## 8.5 AI Content Review Checklist

Before publishing any AI-assisted content, verify:

- [ ] **Brand voice**: Does it sound like Sky, not like a generic AI output?
- [ ] **Accuracy**: Are all facts, dates, and game details correct?
- [ ] **Cultural appropriateness**: No unintended meanings or insensitivity?
- [ ] **Originality**: Is the content sufficiently unique, not generic filler?
- [ ] **Emotional resonance**: Does it make you feel something, or is it flat?
- [ ] **Regulatory compliance**: Disclosure required for AI-generated content in CN?
- [ ] **Data privacy**: No personal data was used in generating this content?
- [ ] **Human touch added**: Has a human reviewer refined and approved this?

---

## 8.6 CN AI Regulatory Considerations

China has specific regulations regarding AI-generated content:

### Key Requirements
- **Labeling**: AI-generated content may need to be labeled as such on certain platforms
- **Deepfake restrictions**: AI-generated human likenesses have specific rules
- **Content review**: AI-generated content is subject to the same content regulations as human-created content
- **Data security**: AI tools used must comply with CN data protection laws
- **Platform-specific rules**: Douyin, Xiaohongshu, etc. have their own AI content policies

### Recommendations
- Stay updated on regulations through legal team
- Default to transparency — label AI-assisted content when in doubt
- Use CN-approved AI tools when possible for regulatory compliance
- Maintain human oversight for all AI-generated content
- Document AI tool usage for compliance records

---

## 8.7 Building an AI-Augmented Workflow

### Getting Started: Week 1–2
1. Identify your three most time-consuming repetitive tasks
2. Test AI tools on these tasks (start with content drafting)
3. Compare AI output quality to current output
4. Document time savings and quality assessment

### Scaling Up: Month 1–3
1. Establish AI-assisted workflows for content creation
2. Set up social listening dashboards with AI analysis
3. Create prompt templates for recurring content types
4. Train team on effective prompt engineering
5. Build quality review processes for AI-assisted content

### Optimizing: Ongoing
1. Regularly evaluate new AI tools and features
2. Share best practices and prompt libraries within team
3. Track time savings and quality improvements
4. Adjust workflows as AI capabilities evolve
5. Maintain brand quality standards regardless of tool used

---

## Knowledge Check

1. You need to create 10 Xiaohongshu posts for a new season. Design an AI-assisted workflow that maintains brand quality.
2. An AI-generated social post sounds "too perfect" and generic. How do you add the human touch?
3. What are the risks of using AI for community crisis response, and what should never be automated?
4. Write a prompt template for generating Bilibili video title options for Sky content.
5. A teammate wants to use an AI image generator for a campaign poster. What's your advice?

---

[← Module 20: Pitch & Presentation Skills](20-pitch-and-presentation.md) | [Next: Module 22 — CN Gaming Regulatory & Compliance →](22-regulatory-compliance.md) | [Main Guide](../README.md)
