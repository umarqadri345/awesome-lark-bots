# Module 11: Marketing SOPs & Workflows

> SOPs turn chaos into consistency. When the process is clear, the team can focus on creativity.

---

## 7.1 Why SOPs Matter for a Cross-Border Team

The tgc CN marketing team operates across:
- **Two time zones** (US Pacific / China Standard — 15–16 hour difference)
- **Two organizations** (tgc HQ + NetEase partnership)
- **Multiple platforms** (6+ social media accounts to manage)
- **Rapid content cycles** (seasons every ~10 weeks + live events)

Without clear SOPs, work falls through the cracks. With them, everyone knows what to do, when, and how.

---

## 7.2 Daily Operations SOP

### Morning Routine (9:00–10:00 AM CST)

| Task | Owner | Tool | Time |
|------|-------|------|------|
| 1. Check all platform notifications and messages | Platform owner | Native apps | 15 min |
| 2. Review overnight community sentiment | Community manager | Social listening tool | 15 min |
| 3. Check for any urgent HQ messages (sent during US evening) | Team lead | Slack/Lark | 10 min |
| 4. Review today's content calendar — confirm posts are ready | Content lead | Shared calendar | 10 min |
| 5. Flag any issues or blockers to team lead | All | Team chat | 10 min |

### Content Posting Rhythm

| Time (CST) | Platform | Content Type |
|------------|----------|-------------|
| 10:00–11:00 AM | Weibo | Morning announcement or interactive post |
| 12:00–1:00 PM | Douyin | Short video (lunch break consumption) |
| 2:00–3:00 PM | Xiaohongshu | Image note (afternoon browse) |
| 5:00–6:00 PM | Bilibili | Video upload (pre-evening prime time) |
| 7:00–8:00 PM | WeChat | 公众号 article (evening reading) |
| 8:00–10:00 PM | All | Community engagement, comment replies |

### End-of-Day Checklist (6:00 PM CST)

- [ ] All scheduled posts published and verified
- [ ] Top comments responded to across platforms
- [ ] Any community issues flagged and documented
- [ ] Next day's content confirmed and staged
- [ ] Key metrics logged (if daily tracking)
- [ ] Handoff note to HQ (if time-sensitive items pending)

---

## 7.3 Weekly Operations SOP

### Monday: Planning & Alignment

| Activity | Time | Participants | Output |
|----------|------|-------------|--------|
| Weekly content calendar review | 10:00 AM | Full CN team | Confirmed weekly plan |
| Cross-check with NetEase schedule | 10:30 AM | Team lead + NetEase liaison | Alignment document |
| Review previous week's metrics | 11:00 AM | Content lead + analytics | Weekly metrics snapshot |

### Wednesday: HQ Sync

| Activity | Time | Participants | Output |
|----------|------|-------------|--------|
| Weekly sync with HQ | 9:00–10:00 AM CST (Mon 5–6 PM PT) | CN lead + HQ counterpart | Meeting notes, action items |
| Topics: campaign updates, content approvals, upcoming plans | — | — | — |

### Friday: Review & Prep

| Activity | Time | Participants | Output |
|----------|------|-------------|--------|
| Weekly performance review | 2:00 PM | Full CN team | Insights doc |
| Content prep for next week | 3:00 PM | Content team | Staged content |
| Community pulse check | 4:00 PM | Community manager | Sentiment summary |

### Weekly Reporting Template

```
══════════════════════════════════════
  SKY CN — WEEKLY REPORT
  Week of: [Date Range]
══════════════════════════════════════

1. KEY METRICS
   Platform       │ This Week │ Last Week │ % Change
   ────────────────┼───────────┼───────────┼─────────
   Bilibili       │           │           │
   Douyin         │           │           │
   Xiaohongshu    │           │           │
   WeChat         │           │           │
   Weibo          │           │           │

2. TOP PERFORMING CONTENT
   - [Link] — [Platform] — [Metric highlight]
   - [Link] — [Platform] — [Metric highlight]

3. COMMUNITY HIGHLIGHTS
   - Positive: [Notable fan content, sentiment]
   - Concerns: [Any emerging issues]

4. CAMPAIGN UPDATE
   - [Campaign name]: [Status and key metrics]

5. NEXT WEEK PRIORITIES
   - [Priority 1]
   - [Priority 2]
   - [Priority 3]

6. HQ ACTION ITEMS
   - [Items needing HQ input/approval]
══════════════════════════════════════
```

---

## 7.4 Season Launch SOP

A season launch is the most complex recurring campaign. This SOP ensures nothing is missed.

### Phase 1: Pre-Production (T-8 to T-4 weeks)

| Task | Owner | Deadline | Dependencies |
|------|-------|----------|-------------|
| Receive season brief from HQ/dev team | Team lead | T-8w | HQ readiness |
| Draft campaign strategy | Team lead | T-7w | Season brief |
| Identify KOL targets and begin outreach | KOL manager | T-7w | Strategy approval |
| Create content plan and deliverable list | Content lead | T-6w | Strategy approval |
| Begin creative production | Creative team | T-6w | Assets from HQ |
| Submit creative briefs for all deliverables | Content lead | T-6w | Content plan |

### Phase 2: Production (T-4 to T-1 week)

| Task | Owner | Deadline | Dependencies |
|------|-------|----------|-------------|
| Creative review round 1 | Team lead | T-4w | First drafts ready |
| Send to HQ for brand review | Team lead | T-3.5w | CN approval |
| Finalize KOL contracts and send briefs | KOL manager | T-3w | KOL confirmed |
| Set up paid media campaigns (draft) | UA manager | T-3w | Creative assets |
| Creative review round 2 / final | Team lead | T-2w | HQ feedback |
| Stage all content on platforms | Content team | T-1w | Final approval |
| QA all links, assets, copy | All | T-3d | Everything staged |

### Phase 3: Launch (T-Day to T+3 days)

| Task | Owner | Deadline | Dependencies |
|------|-------|----------|-------------|
| Publish launch content across all platforms | Content team | T-Day | Pre-staged |
| Activate paid media | UA manager | T-Day | Campaigns approved |
| Monitor KOL content going live | KOL manager | T-Day to T+3d | KOL schedule |
| Real-time community monitoring | Community manager | T-Day to T+3d | — |
| Daily performance check-in | Team lead | T-Day to T+3d | — |

### Phase 4: Sustain & Wrap-Up (T+3 days to T+3 weeks)

| Task | Owner | Deadline | Dependencies |
|------|-------|----------|-------------|
| Continue content cadence | Content team | T+1 to T+3w | Ongoing |
| Optimize paid media based on performance | UA manager | T+1 to T+2w | Data |
| Mid-season check-in with HQ | Team lead | T+2w | — |
| Compile campaign 复盘 report | Team lead | T+3w | All data collected |
| Archive assets and learnings | Content lead | T+3w | — |

---

## 7.5 Content Production SOP

### Content Creation Workflow

```
Ideation → Brief → Draft → Internal Review → HQ Review (if needed) → Final → Schedule → Publish → Monitor
```

### Standard Review Turnaround Times
| Content Type | Internal Review | HQ Review | Total Lead Time |
|-------------|----------------|-----------|----------------|
| Social post (text + image) | 1 day | Not required | 2 days |
| Short video (Douyin/XHS) | 2 days | 2 days | 5 days |
| Long video (Bilibili) | 3 days | 3 days | 7–10 days |
| WeChat article | 2 days | 2 days | 5 days |
| KOL brief | 1 day | 2 days | 4 days |
| Press release | 2 days | 3 days | 7 days |

### Content Quality Checklist (Before Publishing)

- [ ] Aligns with Sky brand voice and visual guidelines
- [ ] No typos, grammatical errors, or incorrect information
- [ ] All links work and direct to correct destinations
- [ ] Images/videos are correct aspect ratio and resolution for the platform
- [ ] Hashtags are correct and current
- [ ] Any required disclaimers or legal text included
- [ ] Tagged/mentioned accounts are correct
- [ ] Scheduled for optimal posting time
- [ ] Approved by required reviewers

---

## 7.6 Community Management SOP

### Engagement Response Matrix

| Scenario | Response Time | Response Type | Escalation |
|----------|-------------|---------------|------------|
| **Positive comment** | Within 4 hours | Like + friendly reply | None |
| **Player question** | Within 2 hours | Helpful answer or direct to resource | None |
| **Bug report** | Within 1 hour | Acknowledge + direct to support | Flag to NetEase |
| **Mild complaint** | Within 2 hours | Empathetic acknowledgment | Note in daily log |
| **Heated criticism** | Within 1 hour | Calm acknowledgment, do NOT argue | Escalate to team lead |
| **Viral negative post** | Within 30 min | Draft response, get approval before posting | Escalate to lead + HQ |
| **Misinformation** | Within 1 hour | Correct gently with facts | Team lead review |
| **Fan creation/UGC** | Within 4 hours | Like, comment, consider for repost | Note for spotlight |

### Crisis Response Protocol

**Level 1 — Minor Issue** (isolated complaints, small-scale)
1. Community manager acknowledges and responds
2. Log in daily report
3. Monitor for escalation

**Level 2 — Growing Concern** (multiple complaints, beginning to trend)
1. Community manager flags to team lead immediately
2. Team lead drafts response strategy
3. Coordinate with NetEase if game-related
4. Issue official response within 4 hours

**Level 3 — Full Crisis** (trending on Weibo/Bilibili, media coverage)
1. All hands on deck — pause scheduled content
2. Team lead coordinates with HQ (urgent, regardless of time zone)
3. Draft official statement — requires HQ and legal approval
4. Designate single spokesperson/account for responses
5. Monitor 24/7 until resolved
6. Post-crisis 复盘 within 48 hours

### Community Tone Guide

| Do | Don't |
|----|-------|
| Be warm and human — speak like a fellow player | Use corporate language or template responses |
| Acknowledge frustration sincerely | Dismiss or minimize player feelings |
| Thank players for feedback, even negative | Get defensive or argue |
| Use community language (光之子, etc.) | Use overly formal address |
| Direct technical issues to proper support channels | Try to troubleshoot in comments |
| Celebrate fan creativity enthusiastically | Ignore fan contributions |

---

## 7.7 KOL Management SOP

### KOL Partnership Workflow

```
Identify → Evaluate → Outreach → Negotiate → Brief → Review Content → Go Live → Report
```

| Step | Owner | Timeline | Output |
|------|-------|----------|--------|
| 1. Identify potential KOLs | KOL manager | Ongoing | KOL longlist |
| 2. Evaluate fit | KOL manager | 2–3 days | Shortlist with rationale |
| 3. Internal approval of shortlist | Team lead | 1 day | Approved shortlist |
| 4. Outreach and negotiation | KOL manager | 3–5 days | Terms discussion |
| 5. Contract and payment terms | KOL manager + finance | 3–5 days | Signed contract |
| 6. Send creative brief | KOL manager | 1 day | Brief delivered |
| 7. Review draft content | KOL manager + content lead | 2–3 days | Feedback provided |
| 8. Final approval | Team lead | 1 day | Go/no-go |
| 9. Content goes live | KOL | Per schedule | Published |
| 10. Performance tracking | KOL manager | T+7 days | Performance report |
| 11. Payment processing | Finance | Per contract | Payment completed |

---

## 7.8 Asset Management SOP

### Folder Structure
```
Sky_CN_Marketing/
├── 01_Brand_Assets/
│   ├── Logos/
│   ├── Brand_Guidelines/
│   └── Templates/
├── 02_Campaign_Assets/
│   ├── [Campaign_Name_Date]/
│   │   ├── Brief/
│   │   ├── Creative/
│   │   ├── Copy/
│   │   └── Reports/
├── 03_Social_Content/
│   ├── Bilibili/
│   ├── Douyin/
│   ├── Xiaohongshu/
│   ├── WeChat/
│   └── Weibo/
├── 04_KOL/
│   ├── Contracts/
│   ├── Briefs/
│   └── Reports/
├── 05_Analytics/
│   ├── Weekly_Reports/
│   ├── Monthly_Reports/
│   └── Campaign_Reports/
└── 06_Archive/
    └── [Year]/
```

### File Naming Convention
```
[Date]_[Platform]_[Type]_[Description]_[Version]
Example: 20260215_Bilibili_Video_SeasonLaunchTrailer_v2
Example: 20260210_XHS_Image_CosmeticsShowcase_Final
```

---

## 7.9 Reporting Cadence

| Report | Frequency | Audience | Owner |
|--------|-----------|----------|-------|
| Daily metrics snapshot | Daily | CN team | Content lead |
| Weekly report | Weekly (Friday) | CN team + HQ | Team lead |
| Monthly performance review | Monthly | HQ leadership | Team lead |
| Campaign 复盘 | Post-campaign | CN team + HQ | Campaign owner |
| Quarterly business review | Quarterly | HQ leadership + NetEase | Team lead |

---

## Knowledge Check

1. Walk through a typical day for the CN marketing team using the daily SOP.
2. A new season launches in 6 weeks. Using the Season Launch SOP, what should you be doing THIS week?
3. A player posts a viral complaint on Weibo about a pricing change. Walk through the crisis response protocol.
4. You need to onboard a new KOL for a partnership. What are the steps and what's the critical checkpoint?
5. A team member asks "where should I save the Douyin video for the Spring campaign?" How do you answer using the asset management SOP?

---

[← Module 10: Campaign Planning & Project Management](10-campaign-planning-pm.md) | [Next: Module 12 — Budget Management & ROI Analysis →](12-budget-management.md) | [Main Guide](../README.md)
