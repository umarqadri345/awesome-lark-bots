# Module 17: Agency, Partner & KOL Collaboration

> Great marketing rarely happens alone. Knowing how to brief, manage, and collaborate with agencies and partners is the multiplier that turns a small team into a full-scale marketing operation.

---

## 29.1 Why Agency & Partner Skills Matter

### The Reality of a Lean Marketing Team

Sky's CN marketing team is small but ambitious. To execute at scale, you'll work with:

| Partner Type | What They Provide | When You Need Them |
|-------------|-------------------|-------------------|
| **Creative agencies** | Design, video production, campaign concepts | Major campaigns, seasonal launches, brand films |
| **Media buying agencies** | Paid media planning, buying, and optimization | Paid UA campaigns, brand awareness pushes |
| **KOL/MCN agencies** | Influencer sourcing, negotiation, management | KOL campaigns, ongoing creator partnerships |
| **PR agencies** | Media relations, press releases, crisis management | Game launches, major announcements, crisis response |
| **Production houses** | Video shooting, editing, post-production | High-quality brand films, live-action content |
| **Localization vendors** | Translation, cultural adaptation, QA | Game localization, marketing content adaptation |
| **Event companies** | Offline event planning and execution | Community meetups, exhibition booths, launch events |
| **Merch partners** | Product design, manufacturing, fulfillment | Merchandise lines, collaboration products |

### Internal vs. External: When to Outsource

| Do In-House | Outsource |
|-------------|-----------|
| Daily social media management | Major campaign creative concepts |
| Community engagement | High-production-value video |
| Content strategy and planning | Paid media buying at scale |
| Brand voice and messaging | Offline event logistics |
| Quick-turnaround content (memes, updates) | Specialized design (3D, motion graphics) |
| KOL relationship management | Legal/regulatory review |
| Data analysis and reporting | Market research studies |

**Rule of thumb**: Keep strategy and voice in-house; outsource execution that requires specialized skills or scale.

---

## 29.2 The Creative Brief

### Why the Brief Is Everything

> A bad brief produces bad work. A vague brief produces vague work. A great brief inspires great work.

The creative brief is the single most important document in agency collaboration. Time spent on the brief saves multiples in revision cycles.

### Creative Brief Template

```
═══════════════════════════════════════════
  CREATIVE BRIEF — [Project Name]
  Date: [Date]
  Brief Owner: [Your Name]
  Agency/Partner: [Agency Name]
═══════════════════════════════════════════

1. BACKGROUND
   What context does the agency need?
   • Game overview (if new partner)
   • Campaign context
   • What's happened before that's relevant

2. OBJECTIVE
   What must this project achieve?
   • Primary goal (ONE clear objective)
   • Secondary goals (if any)
   • KPIs / success metrics

3. TARGET AUDIENCE
   Who are we talking to?
   • Demographics
   • Psychographics
   • Where they spend time online
   • What motivates them

4. KEY MESSAGE
   What's the single most important thing
   we want the audience to take away?
   • One sentence maximum
   • Supporting messages (2–3 max)

5. TONE & STYLE
   How should this feel?
   • Brand voice guidelines
   • Reference examples (mood board, past work)
   • What to AVOID

6. DELIVERABLES
   What exactly do we need?
   • Format and specifications (see Module 28)
   • Quantity
   • Platform(s)
   • Versions / variants needed

7. MANDATORY ELEMENTS
   What MUST be included?
   • Logo placement and usage rules
   • Legal disclaimers
   • Hashtags or handles
   • tgc brand guidelines compliance

8. TIMELINE
   When is everything due?
   • Brief date: [Date]
   • First draft due: [Date]
   • Feedback round 1: [Date]
   • Revised draft due: [Date]
   • Final delivery: [Date]
   • Launch date: [Date]

9. BUDGET
   What's the budget for this project?
   • Total budget: ¥[Amount]
   • Payment terms: [e.g., 50/50]

10. APPROVAL CHAIN
    Who needs to approve?
    • CN team approval: [Name]
    • HQ approval needed? [Yes/No]
    • Legal review needed? [Yes/No]
═══════════════════════════════════════════
```

### Common Brief Mistakes

| Mistake | Problem It Creates | Better Approach |
|---------|-------------------|-----------------|
| "Make it cool" | Subjective; impossible to evaluate | "Should feel serene and magical, like the game's flight experience" |
| No reference examples | Agency guesses your taste | Provide 3–5 visual references with notes on what you like about each |
| Too many objectives | Work tries to do everything, achieves nothing | ONE primary objective; everything else is secondary |
| Vague audience | Generic creative that resonates with no one | Specific persona: "22-year-old female college student who loves cozy games" |
| No mandatory elements | Rework when legal/brand requirements surface late | List every non-negotiable upfront |
| Unrealistic timeline | Rushed work; quality suffers | Build in buffer; discuss timeline before confirming |

---

## 29.3 Agency Selection & Onboarding

### Finding the Right Agency

| Criteria | What to Evaluate | How to Assess |
|----------|-----------------|---------------|
| **Category expertise** | Do they understand gaming/entertainment marketing? | Portfolio review; case studies |
| **Platform knowledge** | Do they know CN social platforms deeply? | Ask platform-specific questions; review CN work |
| **Creative quality** | Does their work match our aesthetic standards? | Portfolio review; chemistry meeting |
| **Cultural fit** | Do they understand Sky's values and tone? | Brief them on Sky; evaluate their response |
| **Team stability** | Will the same people work on our account? | Ask about team structure; request named team |
| **Communication style** | Are they responsive, proactive, and clear? | Trial project; reference checks |
| **Pricing** | Is their pricing fair and transparent? | Compare 3+ agencies; understand what's included |
| **References** | What do other clients say? | Request and check 2–3 client references |

### Agency Onboarding Checklist

When starting with a new agency:

| Step | Details | Owner |
|------|---------|-------|
| **Brand immersion** | Share brand guidelines, game access, key content examples | CN Marketing Lead |
| **Game experience** | Agency team plays Sky for at least 2 hours | Agency |
| **Community tour** | Walk through Sky's CN community channels and sentiment | CN Marketing Lead |
| **Past work review** | Share previous campaigns, what worked, what didn't | CN Marketing Lead |
| **Process alignment** | Agree on communication channels, meeting cadence, approval flow | Both |
| **Tool access** | Grant access to shared drives, asset libraries, project tools | CN Marketing Lead |
| **Key contacts** | Exchange contact lists: who to reach for what | Both |
| **Trial project** | Start with a small project before committing to larger scope | Both |

### The Immersion Session

Before any creative work begins, run a 2-hour immersion session:

```
AGENCY IMMERSION SESSION AGENDA (2 hours)
──────────────────────────────────────────
Part 1: Sky the Game (30 min)
  • Play Sky together (or watch gameplay)
  • Explain the emotional core
  • Show community reactions and fan content

Part 2: Sky in China (30 min)
  • CN player demographics and behavior
  • Social platform presence
  • Competitive landscape
  • Cultural context and sensitivities

Part 3: Brand & Creative Standards (30 min)
  • Visual identity guidelines
  • Tone of voice examples
  • What we love (reference work)
  • What we avoid (anti-references)

Part 4: Working Together (30 min)
  • Communication preferences
  • Approval process
  • Timeline expectations
  • Q&A
```

---

## 29.4 Managing the Creative Process

### The Brief-to-Delivery Workflow

```
BRIEF → KICKOFF → CONCEPTS → FEEDBACK → REVISION → APPROVAL → DELIVERY
  │        │          │          │           │          │          │
  Day 0   Day 1     Day 5     Day 6       Day 8     Day 9      Day 10
         Meeting    Agency     You give    Agency     Final      Assets
         to align   presents   structured  refines    sign-off   delivered
                    2–3        feedback              & handoff
                    directions
```

### Giving Effective Feedback

**The STAR Framework for Creative Feedback**:

| Element | Description | Example |
|---------|-------------|---------|
| **S**pecific | Point to exactly what you're commenting on | "The third frame of the video where the character flies over the clouds" |
| **T**ied to brief | Reference the brief objective or requirement | "The brief asked for a serene tone, but this frame feels too energetic" |
| **A**ctionable | Tell them what to change, not just what's wrong | "Slow the camera movement by 50% and add a softer transition" |
| **R**espectful | Acknowledge good work; be a partner, not a critic | "The color palette is beautiful. If we adjust the pacing, this will be perfect" |

### Feedback Anti-Patterns

| Don't Say | Why It's Bad | Say Instead |
|-----------|-------------|-------------|
| "I don't like it" | Subjective; no direction | "This doesn't align with the brief because..." |
| "Make it pop" | Meaningless; frustrating | "Increase contrast on the title text; add a subtle glow effect" |
| "Can we try something completely different?" | Wastes the concept round; demoralizing | "Can we keep [X element] but explore a different approach to [Y]?" |
| "My manager doesn't like it" | Passes blame; unclear feedback | "We need to adjust [specific element] because [specific reason]" |
| Contradicting previous feedback | Destroys trust and process | Keep a feedback log; review previous notes before new round |
| Feedback via voice message only | Hard to reference; easy to miss details | Always follow up verbal feedback with written summary |

### Revision Management

| Rule | Details |
|------|---------|
| **Cap revision rounds** | Agree upfront: typically 2 rounds included in scope |
| **Consolidate feedback** | Collect all internal feedback before sending ONE consolidated response |
| **Use visual annotation** | Mark up designs directly (use tools like Figma comments, 蓝湖, or even WeChat screenshot markup) |
| **Number your feedback** | "1. Adjust color... 2. Move logo... 3. Change copy..." — makes tracking easy |
| **Distinguish must-fix vs. nice-to-have** | Label feedback: "MUST" for non-negotiable, "SUGGESTION" for optional improvements |
| **Sign off clearly** | When approved, confirm in writing: "This version is approved for production" |

---

## 29.5 Working with KOL/MCN Agencies

### MCN vs. Direct KOL Relationships

| Approach | Pros | Cons |
|----------|------|------|
| **Through MCN** | Access to roster; negotiation handled; contracts standardized | Higher cost (MCN commission); less direct relationship |
| **Direct with KOL** | Stronger relationship; potentially lower cost; more creative control | More time-intensive; contract management on you; harder to scale |
| **Hybrid** | Use MCN for discovery and initial contact; build direct relationships over time | Requires managing both channels |

### KOL Campaign Management Workflow

```
IDENTIFY → EVALUATE → BRIEF → NEGOTIATE → CONTRACT → CREATE → REVIEW → PUBLISH → REPORT
    │          │         │         │           │         │        │         │         │
  Research   Check     Share     Agree on    Sign      KOL     You       Go        Track
  & shortlist metrics   creative  fee, scope, agreement creates  review   live      performance
             & fit     direction deliverables          content  & approve
```

### KOL Brief Template

```
═══════════════════════════════════════════
  KOL COLLABORATION BRIEF
═══════════════════════════════════════════

ABOUT SKY
  [2-paragraph game intro for KOLs unfamiliar with Sky]

CAMPAIGN OVERVIEW
  Campaign name: [Name]
  Campaign period: [Dates]
  Your role: [What we'd like them to do]

CONTENT REQUIREMENTS
  • Platform: [Bilibili / Douyin / XHS / etc.]
  • Format: [Video / note / livestream]
  • Duration: [Minimum length if video]
  • Publish date: [Specific date or window]
  • Hashtags: [Required hashtags]
  • Mentions: [@Official accounts to tag]

KEY MESSAGES (choose 1–2 to weave in naturally)
  1. [Message 1]
  2. [Message 2]
  3. [Message 3]

CREATIVE DIRECTION
  • We want this to feel authentic to YOUR style
  • [Specific angle or hook we suggest]
  • Reference videos we love: [Links]

DO's AND DON'Ts
  DO:
  • Show genuine gameplay moments
  • Share your honest emotional reaction
  • [Other do's]

  DON'T:
  • Read a script word-for-word
  • Show competitor games in the same video
  • Make claims about features that don't exist
  • [Other don'ts]

DELIVERABLES & TIMELINE
  Draft content for review: [Date]
  Feedback returned by: [Date]
  Final publish: [Date]

COMPENSATION
  Fee: ¥[Amount]
  Payment terms: [e.g., 50% on signing, 50% after publish]
  Bonus: [Performance bonus structure, if any]
═══════════════════════════════════════════
```

### KOL Content Review Principles

| Principle | Details |
|-----------|---------|
| **Respect their voice** | Don't rewrite their content; suggest adjustments |
| **Focus on accuracy** | Correct factual errors about the game; let style be theirs |
| **Limit changes** | 3–5 specific feedback points maximum per review |
| **Fast turnaround** | Review within 24 hours; KOLs have schedules too |
| **Trust their audience knowledge** | They know what their followers respond to better than you do |

---

## 29.6 Working with Production Partners

### Video Production Collaboration

| Phase | Your Role | Production Partner's Role |
|-------|-----------|--------------------------|
| **Pre-production** | Brief, references, script approval, talent booking direction | Shot list, storyboard, scheduling, equipment planning |
| **Production (shoot day)** | On-set brand guardian; approve takes; manage game integration | Direct the shoot; manage crew; capture footage |
| **Post-production** | Review cuts; provide feedback on edit, music, color | Edit, color grade, sound design, VFX, motion graphics |
| **Delivery** | Final approval; distribute to platforms | Export in all required formats and specifications |

### On-Set Essentials

When you're the brand representative on a shoot:

| Responsibility | Details |
|---------------|---------|
| **Game device ready** | Have Sky running on a device for reference and live capture |
| **Brand guidelines** | Physical or digital copy accessible on set |
| **Shot list review** | Pre-approve the shot list; know what's essential vs. nice-to-have |
| **Real-time approval** | Be ready to approve takes quickly so the crew can move on |
| **Flexibility** | Be open to creative suggestions from the director — they see opportunities you might miss |
| **Documentation** | Take behind-the-scenes photos/video for social content |

### Managing Photography & Design Partners

| Best Practice | Details |
|--------------|---------|
| **Provide a style guide** | Colors, fonts, logo usage, image treatment examples |
| **Share an asset library** | High-res game assets, screenshots, logos, brand elements |
| **Use mood boards** | Curate visual references that capture the desired aesthetic |
| **Review on-screen** | Always review design work at actual display size, not zoomed in |
| **Platform-check** | Verify deliverables look correct on actual platform previews before finalizing |

---

## 29.7 Contract & Legal Essentials

### Key Contract Terms to Understand

| Term | What It Means | Why It Matters |
|------|-------------|---------------|
| **Scope of work (SOW)** | Exact deliverables, quantities, specifications | Prevents scope creep; defines "done" |
| **Usage rights** | Where and how long you can use the content | Determines if you can reuse on other platforms or campaigns |
| **Exclusivity** | Whether the partner can work with competitors during/after | Prevents KOL from promoting a competing game next week |
| **Revision rounds** | How many rounds of changes are included | Extra revisions = extra cost if not specified |
| **Kill fee** | Payment if you cancel the project | Protects partner; protects you from full payment on cancellation |
| **Confidentiality / NDA** | What information must remain private | Critical for unreleased content; season previews |
| **Payment terms** | When and how payment is made | Cash flow planning; partner relationship management |
| **IP ownership** | Who owns the final creative work | Ensure tgc/Sky owns all deliverables |
| **Liability** | Who's responsible if something goes wrong | Compliance with ad laws, content issues, etc. |

### Contract Red Flags

| Red Flag | Risk | What to Do |
|----------|------|------------|
| No clear scope of work | Endless revisions or underdelivery | Insist on detailed SOW before signing |
| "Unlimited revisions" promise | They'll cut corners knowing changes are coming | Agree on specific revision count; it's fairer for both sides |
| All rights transfer with no extra fee | May mean creative quality is undervalued | Fair pricing should include usage rights |
| No cancellation terms | You're locked in even if quality is poor | Include cancellation clause with reasonable kill fee |
| Verbal agreements only | "I never agreed to that" | Everything in writing, even if it's just a WeChat message confirmed by both parties |

### Working with NetEase (Publisher Partner)

Sky's CN publishing through NetEase means additional collaboration layers:

| Area | Coordination Needed |
|------|-------------------|
| **Content approval** | Major campaigns may need NetEase review for regulatory compliance |
| **App store management** | NetEase handles multi-store distribution; coordinate ASO and featuring |
| **Paid media** | Align on paid campaigns to avoid overlap or conflict |
| **PR & media** | Coordinate press releases and media outreach |
| **Events** | Joint planning for offline events and exhibitions |
| **Data sharing** | Agree on what data is shared and reporting cadence |
| **Escalation path** | Know who to contact at NetEase for urgent issues |

---

## 29.8 Partner Performance Evaluation

### Agency Scorecard

Evaluate agency partners quarterly:

| Dimension | Weight | Scoring (1–5) | Criteria |
|-----------|--------|---------------|----------|
| **Creative quality** | 30% | | Does the work meet brief requirements and brand standards? |
| **Timeliness** | 20% | | Are deliverables on time? Are milestones met? |
| **Communication** | 15% | | Are they responsive, proactive, and clear? |
| **Strategic thinking** | 15% | | Do they contribute ideas beyond the brief? |
| **Budget management** | 10% | | Do they stay within budget? Are costs transparent? |
| **Flexibility** | 10% | | Can they adapt to changes, urgent requests, or shifting priorities? |

**Scoring guide**:
- 5 = Exceptional — exceeds expectations consistently
- 4 = Strong — meets expectations with occasional upside
- 3 = Adequate — meets basic requirements
- 2 = Below expectations — frequent issues
- 1 = Unacceptable — requires immediate action

### KOL Performance Evaluation

| Metric | How to Measure | What's Good |
|--------|---------------|-------------|
| **Views / impressions** | Platform analytics or KOL-provided data | Meets or exceeds KOL's average |
| **Engagement rate** | (Likes + comments + shares) / views | Above KOL's average; above platform benchmark |
| **Click-through** | Tracked link clicks / views | >1% for gaming content |
| **Install attribution** | Tracking link installs | Compare CPI to paid media CPI |
| **Content quality** | Subjective assessment | Authentic, accurate, on-brand |
| **Audience sentiment** | Comment analysis | Positive reactions; genuine interest |
| **Professionalism** | Process experience | On time, communicative, easy to work with |

### Building Long-Term Partnerships

| Strategy | Details |
|----------|---------|
| **Preferred partner list** | Maintain a curated list of 3–5 agencies/vendors per category |
| **Annual retainer consideration** | For frequently used partners, a retainer can reduce per-project costs |
| **Relationship investment** | Share game updates, invite to events, treat them as part of the team |
| **Honest performance conversations** | Quarterly check-ins on what's working and what isn't |
| **Growth together** | As Sky grows, help partners grow with you — loyalty is valuable |
| **Knowledge transfer** | The longer a partner works with you, the less onboarding they need — that's worth paying for |

---

## 29.9 Communication Best Practices

### Communication Channel Selection

| Channel | Best For | Not For |
|---------|----------|---------|
| **WeChat group** | Quick updates, daily coordination, file sharing | Formal approvals, complex feedback |
| **Email** | Formal briefs, contracts, detailed feedback, approvals | Urgent requests, quick questions |
| **Video call (腾讯会议/Zoom)** | Kickoffs, creative reviews, complex discussions | Simple status updates |
| **Project management tool** | Task tracking, timeline management, asset organization | Informal discussion |
| **Phone call** | Urgent issues, sensitive conversations | Detailed feedback requiring reference |

### Meeting Management with Partners

| Meeting Type | Frequency | Duration | Attendees |
|-------------|-----------|----------|-----------|
| **Project kickoff** | Once per project | 60–90 min | Full team both sides |
| **Creative review** | Per milestone | 30–60 min | Creative leads + account manager |
| **Weekly check-in** | Weekly during active projects | 15–30 min | Project lead + account manager |
| **Quarterly review** | Quarterly | 60 min | Senior leads both sides |

### Cross-Cultural Communication (with HQ)

When your agency work needs HQ approval:

| Challenge | Solution |
|-----------|----------|
| **Time zone gap** | Set clear windows for async feedback; use shared documents |
| **Cultural context** | Explain CN cultural nuances to HQ when getting approval — "This works in CN because..." |
| **Translation** | Provide English summaries of CN-language creative for HQ review |
| **Approval speed** | Set HQ review deadlines in briefs; flag urgency clearly |
| **Feedback loops** | Minimize round trips — consolidate CN and HQ feedback before returning to agency |

---

## 29.10 Vendor & Partner Directory Template

Maintain a living directory of all partners:

```
═══════════════════════════════════════════
  PARTNER DIRECTORY — Sky CN Marketing
═══════════════════════════════════════════

CREATIVE AGENCIES
  Company: [Name]
  Specialty: [Design / Video / Full-service]
  Key contact: [Name, WeChat, email]
  Rate card: [Link or summary]
  Past projects: [List]
  Rating: [Score from quarterly review]
  Notes: [Strengths, weaknesses, preferences]

KOL / MCN PARTNERS
  Agency/MCN: [Name]
  Platform focus: [Bilibili / Douyin / XHS]
  Key contact: [Name, WeChat]
  KOL roster access: [Link]
  Commission structure: [X%]
  Past campaigns: [List]

PRODUCTION HOUSES
  Company: [Name]
  Specialty: [Live action / Animation / Motion]
  Key contact: [Name, WeChat, email]
  Rate range: ¥[Range] per project
  Portfolio: [Link]
  Equipment: [What they own vs. rent]

FREELANCERS
  Name: [Name]
  Skill: [Illustration / Photography / Copywriting]
  Contact: [WeChat, email]
  Rate: ¥[Amount] per [unit]
  Availability: [Full-time available / Weekends only]
  Portfolio: [Link]
═══════════════════════════════════════════
```

---

## Knowledge Check

1. You need to brief a creative agency for Sky's Mid-Autumn Festival campaign. Write a complete creative brief using the template in this module.
2. A KOL submits their draft video and it's factually inaccurate about a game feature, but the creative concept and personal style are excellent. How do you give feedback?
3. Your agency consistently delivers good creative but is always 2–3 days late. What do you do at the quarterly review? What process changes do you suggest?
4. You're selecting between three agencies for a major season launch campaign. Design your evaluation criteria and scoring framework.
5. A KOL's MCN is demanding a 40% higher fee than last campaign, claiming the KOL's audience has grown. How do you evaluate whether the increase is justified, and how do you negotiate?

---

[← Module 16: Cross-Platform Publishing](16-cross-platform.md) | [Next: Module 18 — Events, Merchandising & IP Collaboration →](18-events-merch-ip.md) | [Main Guide](../README.md)
