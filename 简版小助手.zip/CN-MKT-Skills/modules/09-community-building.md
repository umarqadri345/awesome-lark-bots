# Module 09: Community Building & Fan Ecosystem

> Sky's community isn't just an audience — it's the game's living, breathing heart. Nurture it like a garden, not a factory.

---

## 15.1 Why Community Is Sky's Greatest Asset

| Asset | Why It Matters |
|-------|---------------|
| **Organic marketing engine** | Fan-created content reaches audiences no ad budget can |
| **Retention driver** | Players stay for friendships, not just features |
| **Early warning system** | Community sentiment predicts problems before metrics do |
| **Content source** | Fan art, videos, music, and stories enrich the brand |
| **Brand defense** | Loyal fans defend Sky against unfair criticism |
| **Innovation input** | Community feedback shapes better game and marketing decisions |

### Sky's Community Flywheel
```
Beautiful game      Players create        Content attracts       New players
experience      →   & share content   →   new audiences      →   join community
     ▲                                                               │
     └───────────────── Community grows stronger ◄───────────────────┘
```

Your job is to **keep this flywheel spinning**.

---

## 15.2 Community Architecture

### Where CN Sky Community Lives

| Platform | Community Role | Size (relative) | Management Priority |
|----------|---------------|-----------------|---------------------|
| **Bilibili** | Fan creation hub; video/art ecosystem | Large | ★★★★★ |
| **Xiaohongshu** | Visual sharing; lifestyle community | Large | ★★★★★ |
| **WeChat Groups** | Core fan private communities | Medium | ★★★★☆ |
| **QQ Groups** | Youth community; real-time chat | Medium | ★★★★☆ |
| **Douyin** | Casual fan content; viral sharing | Large (broad) | ★★★★☆ |
| **Weibo 超话** | Official community space; discussions | Medium | ★★★☆☆ |
| **TapTap** | Game reviews and feedback | Small-Medium | ★★★☆☆ |
| **Lofter** | Fan art and fiction community | Small (dedicated) | ★★★☆☆ |
| **NetEase Community** | In-game and app-based community | Medium | ★★★☆☆ |

### Community Tiers

| Tier | Description | % of Players | Engagement Level |
|------|-------------|-------------|-----------------|
| **Inner Circle (核心圈)** | Fan creators, community leaders, beta testers | ~2% | Daily; create content, moderate, evangelize |
| **Active Community (活跃圈)** | Regular participants; comment, share, discuss | ~10% | Weekly; consume and engage with content |
| **Casual Fans (普通玩家)** | Play regularly but low community participation | ~40% | Occasional; lurk, like, sometimes share |
| **Peripheral (边缘玩家)** | Play occasionally; minimal community interaction | ~48% | Rare; may return for major events |

### Strategy by Tier
| Tier | Goal | Tactics |
|------|------|---------|
| **Inner Circle** | Retain, empower, recognize | Creator program, early access, direct relationships, co-creation |
| **Active Community** | Deepen engagement, nurture upward | Events, challenges, spotlight content, community features |
| **Casual Fans** | Increase participation frequency | Beautiful content they want to share; easy engagement formats |
| **Peripheral** | Re-engage during key moments | Major event awareness; nostalgia content; low-barrier re-entry |

---

## 15.3 Fan Creator Ecosystem (二创生态)

### Why Fan Creation Is Sacred for Sky

Fan-created content isn't a nice-to-have — it's the **lifeblood** of Sky's marketing in China. The CN gaming community values 二创 culture deeply, and Sky has one of the most prolific fan creation communities in mobile gaming.

### Types of Fan Content

| Type | Platforms | Volume | Impact |
|------|----------|--------|--------|
| **Fan art (同人画)** | Bilibili, Xiaohongshu, Lofter, Weibo | Very high | Brand enrichment; emotional resonance |
| **Fan videos (二创视频)** | Bilibili, Douyin | High | Reach; storytelling; UA |
| **Music covers (翻唱/演奏)** | Bilibili, Douyin, NetEase Music | Medium | Sky's musical identity; emotional depth |
| **Cosplay** | Xiaohongshu, Weibo, Bilibili | Medium | Visual impact; event content |
| **Fan fiction (同人文)** | Lofter, WeChat | Lower | Deep community engagement |
| **Game guides (攻略)** | Bilibili, Xiaohongshu, TapTap | High | Utility; new player onboarding |
| **Screenshots (截图)** | Xiaohongshu, Weibo, Douyin | Very high | Lowest barrier; highest volume |

### Fan Creator Program Structure

#### Tier 1: Sky Seedlings (光遇新芽)
- **Criteria**: Any player creating Sky content
- **Benefits**: Official repost consideration; community recognition
- **Engagement**: Like and comment on their content; include in community roundups

#### Tier 2: Sky Stars (光遇之星)
- **Criteria**: 5K+ followers; regular Sky content (2+ pieces/month); consistent quality
- **Benefits**: Creator group access; early season previews; official asset pack; priority reposting
- **Engagement**: Monthly creator newsletter; feedback channels; invitations to create for events

#### Tier 3: Sky Partners (光遇伙伴)
- **Criteria**: 30K+ followers; high-quality output; strong community influence
- **Benefits**: Exclusive cosmetic previews; co-creation opportunities; creator merchandise; event invitations; small stipend for dedicated content
- **Engagement**: Quarterly calls with marketing team; collaborative content planning; beta access

#### Tier 4: Sky Ambassadors (光遇大使)
- **Criteria**: 100K+ followers; significant cross-platform influence; brand-aligned values
- **Benefits**: Full partnership including compensation; voice in product feedback; official ambassador title; annual creator summit invitation
- **Engagement**: Monthly strategy calls; co-development of major campaign content

### Creator Relationship Best Practices

| Do | Don't |
|----|-------|
| Credit creators properly every time you repost | Use fan content without permission or credit |
| Let creators maintain their unique voice | Demand they follow a rigid script |
| Provide assets and information to help them create | Send so many guidelines that it feels like homework |
| Celebrate their growth and milestones | Only contact them when you need something |
| Give honest feedback when asked | Ignore their content or ghost them |
| Respect their other partnerships/content | Demand exclusivity without fair compensation |

---

## 15.4 Community Events & Activations

### Event Types

| Event Type | Description | Frequency | Example |
|-----------|-------------|-----------|---------|
| **Art contests (绘画大赛)** | Fan art competition with themes | Seasonal | "画出你心中的光遇春天" |
| **Video challenges (视频挑战)** | Create videos with specific theme/format | Monthly or per campaign | "30秒光遇最美瞬间挑战" |
| **Music events (音乐活动)** | In-game concerts, cover competitions | Per season or special | "光遇音乐会——用音乐传递光" |
| **Screenshot contests (截图大赛)** | Best screenshot competitions | Monthly | "本月最美截图" |
| **Community Q&A (社区问答)** | Developer or team Q&A sessions | Quarterly | "制作人信箱" |
| **Meetups (线下聚会)** | In-person community gatherings | Quarterly in major cities | "光遇茶话会——上海站" |
| **Anniversary celebrations** | Community-wide celebrations | Annual | "周年庆典——共同的光" |
| **Collaborative creation** | Community co-creates something together | Per special event | "千人共绘光遇长卷" |

### Community Event Planning Checklist

- [ ] **Clear theme** connected to Sky's brand or current season
- [ ] **Simple rules** — low barrier to participation
- [ ] **Attractive rewards** — don't have to be expensive; recognition often matters more than prizes
- [ ] **Generous timeline** — give people enough time to create quality work
- [ ] **Fair judging** — transparent criteria; consider community voting + panel
- [ ] **Promotion plan** — how will people discover the event?
- [ ] **Showcase plan** — how will you celebrate the entries and winners?
- [ ] **Follow-up** — thank participants; share highlights; apply learnings

---

## 15.5 Community Health Monitoring

### Daily Health Check

| Signal | Healthy | Warning | Crisis |
|--------|---------|---------|--------|
| **Sentiment ratio** | >80% positive/neutral | 60–80% positive | <60% positive |
| **Fan creation volume** | Steady or growing | Declining trend | Sharp drop |
| **Community engagement** | Active comments, discussions | Declining interaction | Hostile tone |
| **Bug/complaint reports** | Occasional, constructive | Increasing volume | Flooding channels |
| **Community leader tone** | Enthusiastic, creative | Cautious, questioning | Critical, warning others |

### Sentiment Tracking Framework

```
Score daily across key platforms:

😊 Positive: Excitement, love, gratitude, creative energy
😐 Neutral: Questions, basic information sharing, casual chat
😟 Negative: Complaints, frustration, disappointment
🔥 Critical: Organized backlash, trending complaints, influencer criticism

Track the ratio over time. A healthy community is 70%+ positive/neutral.
```

### Early Warning System
| Signal | What It Means | Action |
|--------|--------------|--------|
| KOLs/creators go quiet about Sky | May be losing interest or sensing negativity | Reach out privately; understand what's happening |
| "I'm quitting" posts increase | Retention risk; something is frustrating core players | Gather specific complaints; escalate to product team |
| Competitor praise increases in Sky spaces | Players comparing unfavorably | Address legitimate complaints; reinforce Sky's unique strengths |
| Screenshot/art sharing drops | Creative inspiration declining | Inject new inspiration; run creation events; release exciting cosmetics |
| WeChat group activity drops | Private community losing energy | Inject new discussions, exclusive content, or events |

---

## 15.6 Community Governance

### Community Rules & Guidelines

Establish clear, Sky-appropriate community guidelines:

1. **Be kind** — Treat others as you would a friend you met in the clouds
2. **Be creative** — Share your art, videos, music, and stories
3. **Be respectful** — Disagreement is OK; personal attacks are not
4. **Be honest** — Don't spread misinformation or unverified leaks
5. **Be safe** — Don't share personal information; protect yourself and others
6. **Credit creators** — Always credit fan content you share

### Handling Difficult Community Members

| Behavior | Response |
|----------|----------|
| **Passionate but critical** | Engage respectfully; acknowledge their feelings; they often become the strongest advocates once heard |
| **Spreading misinformation** | Correct gently and factually; provide official source |
| **Toxic/attacking others** | One warning privately; escalate to moderation if continued |
| **Spam/self-promotion** | Remove and message privately explaining guidelines |
| **Leaking unreleased content** | Remove content; message privately; enforce NDA if applicable |

### Volunteer Moderator Program
For large WeChat/QQ groups, recruit trusted community members:
- Select for maturity, fairness, and love of Sky (not just popularity)
- Provide clear guidelines and escalation paths
- Recognize and reward their contribution
- Regular check-ins to prevent moderator burnout
- Empower but don't abandon — always be available for backup

---

## 15.7 Community Feedback Loop

### Turning Community Input into Action

```
Community voices    Gather &         Analyze &         Communicate        Act &
feedback       →    organize     →   prioritize    →   to relevant    →  close the
                                                       teams              loop
```

### The "Close the Loop" Principle
The most damaging thing for community trust is asking for feedback and then going silent. Always close the loop:

| Stage | What to Communicate |
|-------|-------------------|
| **Received** | "We hear you. We've shared your feedback with the team." |
| **In progress** | "Your feedback led to [specific change being worked on]." |
| **Resolved** | "Based on your input, we've [specific action taken]. Thank you." |
| **Not possible** | "We understand your request. Here's why we can't do this right now, and what we're doing instead." |

---

## Knowledge Check

1. A beloved fan creator (50K followers on Bilibili) is frustrated that their work was reposted without credit by a partner account. How do you handle this?
2. Design a community event for the launch of a new season. Include theme, rules, timeline, platforms, and reward structure.
3. Community sentiment has dropped to 55% positive after a controversial game change. Outline a 7-day recovery plan.
4. You want to launch a volunteer moderator program for Sky's WeChat communities. What's your selection process and support structure?
5. A player posts a long, emotional "goodbye letter" that goes viral on Bilibili. It's genuine, not hostile. How does the marketing team respond?

---

[← Module 08: Creative Production & Platform Formats](08-creative-production.md) | [Next: Module 10 — Campaign Planning & Project Management →](10-campaign-planning-pm.md) | [Main Guide](../README.md)
