# Module 07: Content Localization & CN Copywriting

> Translation converts words. Localization converts meaning. Great CN copywriting creates feeling that never existed in the source language.

---

## 14.1 Localization vs. Translation

| Approach | Definition | Sky Example |
|----------|-----------|-------------|
| **Translation** | Convert words from one language to another | "Season of Revival" → "复兴季" |
| **Localization** | Adapt meaning, tone, and cultural context | "Season of Revival" → "归来季" (Season of Return) — evokes homecoming emotion |
| **Transcreation** | Recreate the message entirely for the target culture | Global tagline "Spread your wings" → "张开翅膀，拥抱天空" (Spread your wings, embrace the sky) — expands the metaphor for CN poetic sensibility |

### The Localization Spectrum
```
Literal          Faithful         Adaptive          Transcreated        Original CN
Translation      Localization     Localization      Content             Content
───────────────────────────────────────────────────────────────────────────────────►
Lowest effort                                                          Highest effort
Lowest resonance                                                       Highest resonance
```

**Sky should operate primarily in the Adaptive-to-Original range.** Literal translation is almost never appropriate for marketing content.

---

## 14.2 CN Copywriting Principles for Sky

### Principle 1: 意境 (Yìjìng) — Atmosphere and Mood

Chinese literary tradition values *yìjìng* — the creation of an immersive emotional atmosphere through words. Sky's marketing should evoke feeling, not just convey information.

| Informational (avoid) | Evocative (aim for) |
|----------------------|---------------------|
| 新季节已上线，包含新地图和新装扮 | 云海之上，一片被遗忘的土地重新苏醒——你准备好回家了吗？ |
| (New season is live with new map and cosmetics) | (Above the sea of clouds, a forgotten land reawakens — are you ready to come home?) |

### Principle 2: 留白 (Liúbái) — The Beauty of What's Left Unsaid

In Chinese art and writing, what you *don't* say is as powerful as what you say. Leave space for the reader's imagination.

| Over-explained (avoid) | 留白 (aim for) |
|------------------------|----------------|
| 在光遇中你可以和朋友牵手一起飞翔穿过美丽的云层体验温暖的友谊 | 牵着手，穿过云。 |
| (In Sky you can hold hands with friends and fly together through beautiful clouds to experience warm friendship) | (Hand in hand, through the clouds.) |

### Principle 3: 节奏感 (Jiézòu Gǎn) — Rhythmic Flow

Chinese text has natural rhythm. Great copy reads almost like poetry — balanced phrases, parallel structure, and pleasing cadence.

| Flat rhythm | Musical rhythm |
|-------------|---------------|
| 这个季节有很多新的东西等你来发现 | 新的旅程，新的故事，新的光芒 |
| (This season has many new things for you to discover) | (New journeys, new stories, new light) — three parallel phrases with matching structure |

### Principle 4: 共情 (Gòngqíng) — Empathetic Connection

Speak *with* the player, not *at* them. Use "we" language. Reference shared emotional experiences.

| Brand-centric | Player-centric |
|--------------|----------------|
| 我们推出了全新季节 (We've launched a new season) | 又到了重逢的时刻 (It's time for reunion again) |
| 光遇最新更新 (Sky's latest update) | 有人在等你回来 (Someone is waiting for you to return) |

### Principle 5: 网感 (Wǎng Gǎn) — Internet-Native Fluency

CN internet culture has its own language, humor, and references. Being "网感" means writing in a way that feels native to the platform, not corporate.

- Know current 网络用语 (internet slang) — but use selectively and authentically
- Reference memes and trends when they genuinely fit Sky's tone
- Avoid trying too hard to be "hip" — forced slang is worse than none
- Each platform has different 网感 standards (Bilibili is playful; WeChat is mature; Xiaohongshu is aspirational)

---

## 14.3 Platform-Specific Copywriting

### Bilibili Copy Style
| Element | Guidelines |
|---------|-----------|
| **Video titles** | Curiosity-driven; can be playful; use【】brackets for category tags |
| **Description** | Include timestamps, relevant links, hashtags |
| **Tone** | Friendly, community-oriented, can use bilibili-specific humor (整活, 下次一定) |
| **Example title** | 【光遇】当你第一次到达伊甸...（全程泪目）|

### Douyin Copy Style
| Element | Guidelines |
|---------|-----------|
| **Caption** | Front-load hook (first 30 characters visible before "展开"); short and punchy |
| **Hook formulas** | Question: "你见过___吗？" / Statement: "这可能是最美的___" / Challenge: "不信你看完不想下载" |
| **Hashtags** | Mix branded + trending + category; 3–6 hashtags |
| **Tone** | Casual, direct, emotionally compelling |
| **Example** | 有一个游戏，让我相信世界上还有温柔的陌生人。#光遇 #治愈系游戏 #手游推荐 |

### Xiaohongshu Copy Style
| Element | Guidelines |
|---------|-----------|
| **Title** | Search-optimized; include key terms; use emoji sparingly as visual breaks |
| **Body** | 300–800 characters; personal, conversational tone; paragraph breaks every 2–3 sentences |
| **Structure** | Hook → Personal experience/feeling → Details → Soft recommendation |
| **Tone** | Like a friend sharing a discovery; authentic, not promotional |
| **Example opening** | 最近发现了一个让我每天都想打开的游戏，不是因为任务，是因为想念那里的天空☁️ |

### WeChat 公众号 Style
| Element | Guidelines |
|---------|-----------|
| **Headline** | Emotional hook or intrigue; 15–25 characters optimal |
| **Opening line** | Must hook the reader — they decide in 3 seconds whether to keep reading |
| **Body** | Short paragraphs (2–3 sentences max); heavy use of images; emotional pacing |
| **Length** | 800–1500 characters for regular updates; up to 2500 for special features |
| **Tone** | More polished and literary than other platforms; poetic for Sky |
| **Example headline** | 那些在云海中遇见的人，后来怎样了？ |

### Weibo Copy Style
| Element | Guidelines |
|---------|-----------|
| **Post length** | 50–200 characters (sweet spot before truncation) |
| **Hashtags** | #话题# format; 1–2 per post |
| **Interactive elements** | Polls, questions, "转发抽奖" mechanics |
| **Tone** | Official but warm; timely and responsive |
| **Example** | #光遇新季节# 云海之上，一个沉睡的世界正在醒来。准备好了吗？明天见 ☁️✨ |

---

## 14.4 The Localization Workflow

### For Global-to-CN Content

```
Receive EN        Understand        Draft CN           Internal          Final
source content →  intent &      →   version        →   review       →   output
                  context           (not translation)   (brand + cultural)
```

### Step-by-Step Process

1. **Read the full source material** — Understand the complete message, not just individual sentences
2. **Identify the emotional core** — What should the reader FEEL after reading this?
3. **Note cultural translation needs** — What references, metaphors, or concepts need adaptation?
4. **Draft in Chinese as original writing** — Write as if creating CN-original content with the same intent
5. **Review for brand voice** — Does it sound like Sky? Does it match the platform?
6. **Cultural sensitivity check** — Anything that could be misinterpreted or offensive?
7. **Back-translate key phrases** — If HQ needs to approve, provide back-translations so they understand what the CN copy actually says

### Common Localization Pitfalls

| Pitfall | Example | Solution |
|---------|---------|----------|
| **Literal idiom translation** | "It's raining cats and dogs" → translated literally | Find a CN equivalent or express the meaning differently |
| **Cultural reference mismatch** | Thanksgiving-themed content | Replace with contextually appropriate CN reference |
| **Tone mismatch** | Casual American humor → sounds weird in CN | Adapt the humor style to CN sensibility |
| **Length mismatch** | EN copy is concise; CN version is too long | CN and EN have different natural lengths — adjust to fit platform requirements |
| **False friends** | Words that look similar but mean different things | Always verify meaning in context |
| **Formality mismatch** | Too casual for WeChat; too formal for Douyin | Adjust register per platform |

---

## 14.5 Copywriting Templates & Formulas

### The "3-Act" Social Post

**Act 1 — Hook (情感钩子)**: 1 sentence that stops the scroll
**Act 2 — Body (内容主体)**: 2–4 sentences of substance
**Act 3 — Close (温柔收尾)**: Invitation or emotional resonance

**Example (Xiaohongshu)**:
> **Hook**: 有没有一个游戏，让你觉得世界还是温柔的？
> **Body**: 光遇就是这样一个地方。没有竞争，没有排名，只有云海、音乐和陌生人递过来的一支蜡烛。昨天我在雨林里迷路，一个不认识的人牵着我走了很久。下线之后还在想，那个人现在在做什么呢？
> **Close**: 如果你也需要一个安静的角落，来这里看看吧 ☁️

### Seasonal Announcement Formula

```
[Atmosphere setting] + [Season theme] + [What players can expect] + [Emotional invitation]
```

**Example**:
> 当最后一片秋叶落下，一束新的光芒从云层中透出。「归来季」将于12月15日开启——六位先祖正等着与你分享被遗忘的记忆。准备好回到那个让你心安的地方了吗？

### Event Announcement Formula

```
[Event name] + [Dates] + [What's special] + [Emotional hook] + [How to participate]
```

### UGC/Fan Content Repost Formula

```
[Appreciation] + [What makes this special] + [Credit] + [Community invitation]
```

**Example**:
> 这幅画让我们看了很久很久。每一笔都是对光遇世界的温柔理解 ✨ 感谢 @[creator] 用画笔传递的光。你们的创作，是光遇最美的风景。#光遇二创

---

## 14.6 Terminology & Style Guide

### Sky-Specific CN Terminology

For the complete terminology reference, see [Appendix A: Terminology Glossary](../appendix-glossary.md). Key terms every copywriter must know:

| Term | Chinese | Notes |
|------|---------|-------|
| Sky: Children of the Light | 光·遇 (光遇) | Official CN name; use 光·遇 for formal, 光遇 for casual |
| Jenova Chen | 陈星汉 | Use Chinese name for CN audiences |
| Children of the Light | 光之子 | Community self-reference |
| Adventure Pass | 季卡 | CN terminology for season pass |
| Candle / Heart | 蜡烛 / 爱心 | In-game currency / social currency |
| Spirit | 先祖 | Collectible NPCs |
| Eye of Eden | 伊甸 / 暴风眼 | End-game area; 伊甸 is more common |
| Moth (new player) | 萌新 / 小黑 | Community nickname for beginners |
| Candle run | 跑烛 | Daily activity (community term) |

### Style Rules
- **Numbers**: Use Arabic numerals in casual content (3个季节), Chinese numerals for poetic/formal (三季光阴)
- **Punctuation**: Use CN punctuation marks (，。！？) not EN ones in CN copy
- **Emoji**: Use sparingly and intentionally; ☁️✨🕯️ align with Sky's aesthetic; avoid overuse
- **Line breaks**: Use generously on mobile-first platforms — walls of text kill engagement
- **Hashtags**: Platform-appropriate format (#话题# on Weibo; #话题 on Douyin/XHS)

---

## 14.7 Quality Assurance Checklist

Before publishing any CN copy:

- [ ] **Emotional resonance**: Does it make you feel something? (Read it out loud)
- [ ] **Brand voice match**: Does it sound like Sky — warm, poetic, inviting?
- [ ] **Platform appropriateness**: Is the tone and length right for this specific platform?
- [ ] **Terminology consistency**: Are Sky-specific terms using the approved CN translations?
- [ ] **Cultural sensitivity**: Any potential misinterpretations, double meanings, or taboos?
- [ ] **Grammar and typos**: Proofread twice; have a second person review
- [ ] **Rhythm and flow**: Does it read smoothly? Are parallel structures balanced?
- [ ] **Accurate information**: Dates, feature names, and details all correct?
- [ ] **Hashtags**: Correct format and relevant tags included?
- [ ] **CTA (if any)**: Gentle, on-brand, and clear?

---

## Knowledge Check

1. Translate this global tagline for CN marketing: "Light awaits." Provide three options ranging from faithful to transcreated, and explain your reasoning.
2. Write a Douyin caption (under 100 characters) for a video showing two players flying through the sunset together.
3. The same season launch needs copy for Bilibili (video title + description), Xiaohongshu (post), and Weibo (announcement). Write all three.
4. A global campaign uses the concept "Pay it forward." This doesn't translate directly to Chinese. How would you adapt the concept?
5. Review this draft copy and improve it: "光遇新季节来了！快来下载体验全新内容吧！新地图、新先祖、新装扮等你来收集！"

---

[← Module 06: Data Analytics & Performance](06-data-analytics.md) | [Next: Module 08 — Creative Production & Platform Formats →](08-creative-production.md) | [Main Guide](../README.md)
