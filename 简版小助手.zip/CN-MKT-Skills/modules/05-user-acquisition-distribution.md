# Module 05: User Acquisition & App Store Distribution

> Sky grows through warmth, not noise. Every new player should feel invited — and every app store should make it easy to say yes.

---

## 5.1 UA Philosophy for Sky

Sky's acquisition strategy must reflect its brand values. Unlike competitive games that use aggressive performance marketing, Sky's growth should feel like **a friend sharing something beautiful**.

### Core UA Principles
1. **Beauty as the hook** — Sky's visuals are the most powerful UA asset
2. **Emotion over features** — Show how the game *feels*, not what it *does*
3. **Community as amplifier** — Word-of-mouth and fan creation drive organic growth
4. **Accessibility as message** — "Anyone can play" removes barriers to trial
5. **Long-term value over short-term installs** — Optimize for retention, not just downloads

---

## 5.2 Organic Growth Channels

### Word-of-Mouth (口碑传播)

The single most powerful UA channel for Sky in China.

| Tactic | Execution | Expected Impact |
|--------|-----------|-----------------|
| **In-game invite mechanics** | Encourage sharing invite links; reward both sides | High — personal recommendation converts best |
| **Shareable moments** | Create screenshot/video-worthy in-game moments | High — drives organic social sharing |
| **Friendship mechanics** | Hand-holding, gifting, music — inherently social | Medium-High — players bring friends naturally |
| **Community events** | Events that reward multi-player participation | Medium — creates reasons to invite |

### Fan Creation (二创) Ecosystem

**Strategy: Nurture, Don't Control**
- Celebrate creators: Feature fan art, videos on official channels (with credit)
- Provide assets: High-res screenshots, music files, permission guidelines
- Run creation events: Art contests, video challenges, music cover competitions
- Establish a formal "Sky Creator" program with tiers:

| Tier | Criteria | Benefits |
|------|----------|----------|
| **Sky Star (光遇之星)** | 10K+ followers, regular content | Early access to season content, official repost |
| **Sky Partner (光遇伙伴)** | 50K+ followers, high quality | Creator kit, exclusive cosmetics, direct contact |
| **Sky Ambassador (光遇大使)** | 100K+, significant influence | Co-creation opportunities, events, stipend |

### Search & Platform SEO
- **Baidu**: Optimize 百度百科 page, Tieba presence
- **Zhihu**: Answer questions about "relaxing games," "beautiful mobile games"
- **Xiaohongshu search**: Target keywords (see Module 04)
- **Bilibili search**: Optimize video titles and tags for discovery

---

## 5.3 KOL/KOC Partnership Strategy

### KOL vs. KOC

| Type | Definition | Sky Use Case |
|------|-----------|-------------|
| **KOL (Key Opinion Leader)** | Large following (100K+) | Awareness campaigns, season launches |
| **KOC (Key Opinion Consumer)** | Smaller following (1K–50K) | Authentic seeding, Xiaohongshu |
| **Fan Creators (二创作者)** | Community members who create | Ongoing organic amplification |

### KOL Selection Criteria

| Criterion | Weight | Why |
|-----------|--------|-----|
| **Brand alignment** | ★★★★★ | Must match Sky's warmth — no edgy creators |
| **Audience overlap** | ★★★★☆ | 18–28, female-skewing, aesthetic content consumers |
| **Content quality** | ★★★★☆ | Must match Sky's visual standard |
| **Engagement rate** | ★★★★☆ | Engagement over raw follower count |
| **Authenticity** | ★★★★★ | Should genuinely enjoy Sky |

### KOL Category Targets
| Category | Examples of Content |
|----------|-------------------|
| **Gaming (游戏)** | Gameplay, season reviews, guides |
| **Art/Illustration (绘画)** | Fan art, art process videos |
| **Music (音乐)** | OST covers, in-game performances |
| **Lifestyle/Aesthetic (生活)** | "A beautiful game for your evening" |
| **Couples (情侣)** | Playing together, romantic moments |
| **Relaxation (治愈)** | Ambient gameplay, ASMR-style content |

---

## 5.4 Paid User Acquisition

### Paid Media Channels

| Channel | Strength | Sky Fit |
|---------|----------|---------|
| **巨量引擎 (Ocean Engine / Douyin Ads)** | Massive reach, algorithm targeting | ★★★★★ |
| **腾讯广告 (Tencent Ads)** | WeChat ecosystem, precise targeting | ★★★★☆ |
| **Bilibili Ads** | ACG audience, brand-safe | ★★★★☆ |
| **Xiaohongshu Ads** | High-intent aesthetic audience | ★★★★☆ |
| **Apple Search Ads** | High intent, direct download | ★★★★☆ |
| **Weibo Ads** | Broad reach, trending capability | ★★★☆☆ |

### Creative Best Practices for Paid Ads

**What works**:
- Lead with 3 seconds of breathtaking visual (flight, sunset, clouds)
- Show human connection moments (hand-holding, group flight)
- Use Sky's OST or emotional music — sound-on matters
- Soft CTA: "来这个世界看看" not "立即下载"
- UGC-style content outperforms polished ads on Douyin

### Creative Testing Framework
| Variable | Test Options |
|----------|-------------|
| **Hook** | Scenic beauty vs. friendship moment vs. curiosity |
| **Length** | 15s vs. 30s vs. 60s |
| **Style** | Cinematic vs. gameplay vs. player testimonial |
| **Music** | OST vs. trending audio vs. ambient |
| **CTA** | Soft invitation vs. no CTA vs. direct download |

### Performance Metrics

| Metric | Definition |
|--------|-----------|
| **CPI** | Cost per install — varies by channel |
| **CPR** | Cost per registration — track tutorial completion |
| **Day 1/7/30 Retention** | % returning — quality indicator |
| **ROAS** | Return on ad spend — track season pass conversions |
| **IPM** | Installs per 1000 impressions — creative quality indicator |

---

## 5.5 The CN App Distribution Landscape

### Why CN Distribution Is Unique

| Global Market | CN Market |
|--------------|-----------|
| Google Play + Apple App Store ≈ 95% | No Google Play; Apple + 10+ Android stores |
| Two stores to optimize | 10+ stores to manage |
| Unified Android experience | Fragmented ecosystem |
| Single submission | Multiple submissions |
| Standard 30% commission | Commission varies: 30–50% |

### The Full Channel Map

```
                        ┌── Apple App Store (iOS)
                        ├── 华为 AppGallery
                        ├── OPPO 软件商店
                        ├── vivo 应用商店
       Game Update ─────┤── 小米应用商店
                        ├── 应用宝 (Tencent)
                        ├── TapTap
                        ├── 360手机助手
                        ├── 百度手机助手
                        └── Other channels
```

---

## 5.6 App Store Optimization (ASO) — Deep Dive

### ASO for Apple App Store (CN)

| Element | Best Practice | Sky-Specific Tips |
|---------|--------------|-------------------|
| **App name** | 光·遇 — keep consistent | Subtitle for keywords: "社交冒险·治愈之旅" |
| **Subtitle** | 30 chars max; keyword-rich | Rotate seasonally with season names |
| **Keywords** | 100 chars; hidden from users | 治愈游戏, 社交游戏, 冒险游戏, 多人手游, 音乐游戏, 飞翔, 好看 |
| **Screenshots** | Up to 10; first 3 visible | Lead with stunning visuals; show multiplayer |
| **Preview video** | Up to 3; 30s each | Flight → friendship → music; Sky OST audio |
| **Description** | First 3 lines visible | Emotional hook: "在云海之上，遇见温暖的陌生人..." |
| **Promotional text** | 170 chars; update without build | Use for season launches |
| **Ratings** | 4.5+ target | Respond to reviews; encourage ratings |

### ASO for Android Stores

| Store | Key Optimization Areas |
|-------|----------------------|
| **华为 AppGallery** | Listing, Huawei Ads integration, featured requests |
| **OPPO** | Listing, OPPO Ads, editor relationships for featuring |
| **vivo** | Listing, vivo Ads, featured placement |
| **小米** | Mi Store listing, Xiaomi Ads, promotions |
| **应用宝** | Tencent ecosystem, QQ/WeChat cross-promotion |
| **TapTap** | Community engagement, review management, editorial |

### Keyword Research Process
1. **Seed**: 光遇, 治愈游戏, 社交游戏, 冒险手游
2. **Expand**: Use 七麦数据 (Qimai) or App Annie
3. **Analyze competitors**: What keywords do competitors rank for?
4. **Check volume**: Prioritize high volume, reasonable competition
5. **Track rankings**: Monitor weekly; adjust underperformers
6. **Seasonal updates**: Add season names during launches

---

## 5.7 App Store Featuring

### Types of Features

| Type | Impact |
|------|--------|
| **Banner / hero** | Highest — massive homepage visibility |
| **Today/editorial** | High — quality traffic; brand-building |
| **Category feature** | Targeted relevant audience |
| **Seasonal collection** | Contextual discovery |
| **New updates** | Drives re-engagement |

### How to Secure Featuring

| Step | Action |
|------|--------|
| **Build relationships** | Regular contact with store editorial teams (via NetEase) |
| **Plan ahead** | Feature requests need 4–8 weeks lead time |
| **Tell a story** | "Why feature Sky NOW?" — cultural moment, new content, awards |
| **Provide assets** | Custom artwork in exact specs |
| **Time with updates** | Stores prefer featuring fresh content |
| **Show momentum** | Share engagement data and growth signals |

### Feature Request Template
```
═══════════════════════════════════════
  FEATURING REQUEST — [Store Name]
═══════════════════════════════════════
Game: 光·遇 (Sky: Children of the Light)
Publisher: NetEase
Requested Date: [Date range]

WHY NOW: [1–2 paragraphs — new content,
cultural moment, awards, milestones]

WHAT'S NEW: • [Feature 1] • [Feature 2]

ASSETS PROVIDED:
□ Custom banner artwork ([dimensions])
□ Updated screenshots
□ App preview video
□ Editorial copy

PERFORMANCE: Rating [X.X] stars, DAU [trend]
═══════════════════════════════════════
```

---

## 5.8 Review & Ratings Management

### Review Response SOP

| Review Type | Response Time | Approach |
|------------|-------------|---------|
| **5-star praise** | Within 24h | Warm thank you |
| **4-star with feedback** | Within 24h | Thank + address point |
| **3-star constructive** | Within 12h | Empathy + improvements |
| **2-star complaint** | Within 6h | Apologize, ask specifics, direct to support |
| **1-star frustration** | Within 4h | Deep empathy, offer help, escalate if needed |

### Proactive Rating Improvement

| Strategy | Implementation |
|----------|---------------|
| **In-game prompt** | Ask after positive moments (NOT negative ones) |
| **Community encouragement** | Gently ask satisfied players to review |
| **Fix top complaints** | Analyze patterns in negative reviews |
| **Engaging update notes** | Show improvement based on feedback |
| **Consistent response** | Players notice developer engagement |

---

## 5.9 Multi-Store Attribution

### Tracking Installs Across 10+ Stores

| Method | Accuracy |
|--------|----------|
| **Store-level reporting** | High (NetEase aggregates) |
| **OAID tracking** | Medium (CN Android identifier) |
| **Campaign UTMs** | High for paid campaigns |
| **Referral codes** | High for tracked channels |
| **Post-install survey** | Low-Medium |

### Metrics Per Store
Track installs, DAU/MAU, retention, revenue, CPI, and rating for each store to identify which deliver the highest-quality users.

---

## 5.10 Cross-Promotion & Partnerships

| Category | Examples | Value to Sky |
|----------|---------|-------------|
| **Cultural institutions** | Museums, art galleries, orchestras | Brand elevation, new audiences |
| **Consumer brands** | Lifestyle brands aligned with Sky | Reach, co-branded content |
| **Music artists** | Independent musicians, classical performers | Emotional resonance |
| **Platform partnerships** | Bilibili, Xiaohongshu featured content | Distribution, visibility |

### Growth Experimentation Framework
```
IDEATE → TEST → ANALYZE → SCALE (or kill)
```

| Field | Description |
|-------|-------------|
| **Hypothesis** | "If we [action], then [metric] will [change] because [reason]" |
| **Budget** | Test allocation |
| **Duration** | Run time before evaluating |
| **Success metric** | Primary KPI and target |
| **Result** | What happened? |
| **Decision** | Scale / Iterate / Kill |

---

## Knowledge Check

1. Why is word-of-mouth Sky's most important UA channel, and how can marketing amplify it?
2. You're selecting a KOL for a Bilibili season launch. Walk through your selection process.
3. A paid Douyin ad has high views but low installs. Diagnose three reasons and propose fixes.
4. Why can't you focus on just Apple App Store for CN distribution? Explain the multi-store business case.
5. Write an ASO-optimized App Store description (first 3 lines) that maximizes conversion.

---

## Related Modules
- [Module 04: CN Social Media Platforms](04-social-media-platforms.md) — Platform strategies
- [Module 06: Data Analytics](06-data-analytics.md) — Performance measurement
- [Module 08: Creative Production](08-creative-production.md) — Ad creative formats and specs
- [Module 17: Agency & Partner Collaboration](17-agency-partner-collab.md) — KOL campaign management

---

[← Module 04: Social Media Platforms](04-social-media-platforms.md) | [Next: Module 06 — Data Analytics →](06-data-analytics.md) | [Main Guide](../README.md)
