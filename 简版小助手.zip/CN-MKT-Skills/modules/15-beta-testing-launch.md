# Module 15: Beta Testing & New Game Launch

> A game launch is a one-time event — you can't un-launch. Every decision in the beta and pre-launch phase shapes the game's trajectory for years. Marketing's role starts long before Day One.

---

## 26.1 The Launch Journey

### Overview: From Concept to Live Game

```
CONCEPT → PROTOTYPE → CLOSED BETA → OPEN BETA → SOFT LAUNCH → FULL LAUNCH → LIVE OPS
                        (封闭测试)     (公开测试)     (试运营)       (正式上线)
   │          │            │              │             │              │           │
Internal   Friends &    Selected       Broader      Limited        Mass       Ongoing
only       family       testers        public       market         release    management
```

### CN-Specific Launch Considerations

| Factor | CN Uniqueness | Impact |
|--------|-------------|--------|
| **版号 requirement** | Must have government approval before commercial launch | Can delay launch by months |
| **Publisher dependency** | NetEase manages regulatory, operations, and distribution | Coordination is critical |
| **Multi-store distribution** | 10+ Android app stores to manage simultaneously | Complex logistics |
| **Cultural adaptation** | Content, visuals, and messaging must resonate locally | Localization = more than translation |
| **Competitive timing** | Dense market; launching against competitors' events can hurt | Strategic timing matters |
| **Community pre-building** | CN players expect established community presence at launch | Start community work early |

---

## 26.2 Beta Testing Phases

### 26.2.1 Closed Beta (封闭测试 / 封测)

**Purpose**: Test core gameplay with a small, controlled group

| Aspect | Details |
|--------|---------|
| **Scale** | 1,000–10,000 players |
| **Duration** | 2–4 weeks |
| **Selection** | Invited players; sign-up + selection; NDA required |
| **Focus** | Core gameplay, bugs, performance, initial feedback |
| **Data wiped?** | Usually yes — progress resets before next phase |

**Marketing Role in Closed Beta**:

| Task | Details |
|------|---------|
| **Tester recruitment** | Design sign-up flow; promote on targeted channels |
| **Expectation setting** | Clear communication: "This is a test, not the final game" |
| **NDA management** | Ensure testers understand confidentiality requirements |
| **Feedback collection** | Design surveys; monitor tester community discussions |
| **Sentiment monitoring** | Track early reactions; flag critical issues to dev team |
| **Content preparation** | Use approved beta footage for future marketing (with clearance) |

**Tester Recruitment Strategy**:

| Channel | Approach |
|---------|----------|
| **TapTap** | Pre-registration + beta signup; TapTap's core gaming audience is ideal |
| **Bilibili** | Announcement video; community sign-up link |
| **WeChat/QQ groups** | Recruit from existing tgc fan communities |
| **Gaming forums** | NGA, Baidu Tieba gaming boards |
| **Targeted ads** | Small paid campaign targeting likely early adopters |

**Recruitment Messaging**:
> 我们正在寻找第一批光之子——参与【游戏名称】封闭测试，见证这个世界的诞生。名额有限，等你来探索。

### 26.2.2 Open Beta (公开测试 / 公测)

**Purpose**: Stress test at scale; validate monetization; build community

| Aspect | Details |
|--------|---------|
| **Scale** | 10,000–500,000+ players |
| **Duration** | 2–8 weeks |
| **Selection** | Open registration; may have capacity limits |
| **Focus** | Server stability, monetization testing, content completeness, broad feedback |
| **Data wiped?** | May or may not be wiped; communicate clearly |

**Marketing Role in Open Beta**:

| Task | Details |
|------|---------|
| **Launch-scale campaign** | Open beta is often the first major public touchpoint |
| **KOL activation** | Brief KOLs to create "first look" content |
| **Community building** | Establish official community channels; begin daily engagement |
| **Feedback loop** | Aggregate community feedback; report to dev team weekly |
| **Content creation** | Capture footage for launch marketing materials |
| **App store preparation** | Begin ASO optimization; upload beta screenshots |
| **Press/media outreach** | Gaming media previews and hands-on coverage |

**Open Beta Marketing Campaign Structure**:

```
T-2 weeks:  Announcement campaign — "Open beta is coming"
T-1 week:   Pre-registration push — "Sign up now"
T-Day:      Launch day campaign — "The doors are open"
T+1 week:   "First week highlights" content
T+2 weeks:  Community spotlight — "What players are saying"
T+End:      "Thank you" + "What's next" communication
```

### 26.2.3 Technical Beta / Stress Test (压力测试)

| Purpose | Marketing Role |
|---------|---------------|
| Short-duration test focused on server capacity and performance | Recruit testers; manage expectations ("This is a technical test, expect issues") |
| May run for hours or 1–2 days | Quick turnaround content showing the scale and excitement |

---

## 26.3 Pre-Launch Marketing Strategy

### The Pre-Launch Funnel

```
AWARENESS           ANTICIPATION          COMMITMENT           LAUNCH DAY
"What is this?"  →  "I want to try" →    "I've signed up" →   "I'm playing!"
                                                                    │
Content reveals     Pre-registration      Community              Install &
Teaser trailers     KOL previews         engagement              onboarding
Media coverage      App store listing     Countdown              UA activation
                    Community building    content
```

### Pre-Launch Timeline (Full Launch)

| Timing | Phase | Key Activities |
|--------|-------|---------------|
| **T-6 months** | Foundation | Brand identity finalized; social accounts created; initial audience building |
| **T-4 months** | Seeding | First teaser content; gaming media outreach; community nucleus building |
| **T-3 months** | Beta marketing | Closed/open beta campaigns; KOL seeding; feedback collection |
| **T-2 months** | Build-up | Pre-registration campaigns; content reveals; app store listings prepared |
| **T-1 month** | Acceleration | Major trailer release; KOL campaign activation; paid media testing |
| **T-2 weeks** | Final push | Daily countdown content; community hype; all content staged |
| **T-1 week** | Ready | Final QA on all marketing materials; war room prepared; contingency plans set |
| **T-Day** | Launch | Full campaign activation across all channels |

### Pre-Registration Campaign

**Goal**: Build a Day 1 install base

| Element | Details |
|---------|---------|
| **Milestone rewards** | Tiered rewards at registration milestones (100K, 500K, 1M pre-regs) |
| **Social sharing** | "Share to unlock bonus rewards for everyone" |
| **Platform distribution** | TapTap primary; all app stores; social media sign-up |
| **KOL amplification** | Creators promote pre-registration to their audiences |
| **Content reveals** | Tied to milestones: "At 500K pre-regs, we'll reveal the launch trailer" |

**Pre-Registration Milestone Example**:
```
100,000 pre-regs  →  Exclusive launch avatar frame
300,000 pre-regs  →  In-game currency pack
500,000 pre-regs  →  Exclusive cosmetic item
1,000,000 pre-regs → Exclusive launch title + bonus bundle
```

---

## 26.4 Launch Day Execution

### Launch Day War Room

**Who's in the room** (virtual or physical):
- CN Marketing Lead
- Community Manager
- Content Team
- UA/Paid Media Manager
- NetEase Operations Contact
- HQ Contact (on-call)

**War Room Schedule (Launch Day)**:

| Time (CST) | Activity | Owner |
|-----------|----------|-------|
| 8:00 AM | Final pre-launch check: all content staged, all links verified | All |
| 9:00 AM | Publish launch announcements (Weibo, WeChat) | Content |
| 9:30 AM | Verify game is live on all stores | NetEase |
| 10:00 AM | Activate paid media campaigns | UA Manager |
| 10:00–12:00 | Monitor community reaction; respond to questions | Community |
| 12:00 PM | Publish Douyin launch video | Content |
| 12:00 PM | Midday performance check: installs, store status, server health | Lead |
| 2:00 PM | Publish Xiaohongshu launch content | Content |
| 3:00 PM | Afternoon performance check | Lead |
| 5:00 PM | Bilibili video launch | Content |
| 6:00 PM | Evening performance check; HQ update | Lead |
| 7:00–10:00 PM | Prime time monitoring (peak player activity) | Community + Lead |
| 10:00 PM | End-of-day report; overnight monitoring plan | Lead |

### Launch Day Contingency Plans

| Issue | Response Plan |
|-------|-------------|
| **Servers crash** | Pre-drafted "high demand" message; coordinate with NetEase for ETA; publish updates every 30 min |
| **App store rejection** | Work with NetEase to resolve; delay announcement if not resolved |
| **Major bug discovered** | Assess severity; if game-breaking, consider delaying marketing push |
| **Lower-than-expected installs** | Accelerate paid media; activate backup KOL content; additional social posts |
| **Higher-than-expected installs** | Celebrate! Amplify positive buzz; ensure server capacity |
| **Negative press/reviews** | Draft rapid response; address legitimate concerns; escalate if needed |
| **Competitor counter-launch** | Ignore competitor; stay focused on Sky's own narrative |

---

## 26.5 Post-Launch Critical Period (Days 1–30)

### The First 30 Days Framework

| Period | Focus | Marketing Priority |
|--------|-------|-------------------|
| **Day 1–3** | Acquisition spike; bug fixing; initial feedback | Maximize install volume; manage first impressions |
| **Day 4–7** | Retention signal; community formation | Shift focus to onboarding content; encourage social sharing |
| **Week 2** | Engagement patterns emerging | Guide content; community events; address common confusion |
| **Week 3** | First monetization window | Introduce IAP value gently; cosmetic showcases |
| **Week 4** | Retention plateau | Re-engagement content; community deepening; first mini-event |

### Daily Post-Launch Report (Days 1–14)

```
═══════════════════════════════════════
  DAILY LAUNCH REPORT — Day [X]
═══════════════════════════════════════

INSTALLS
  Today: [Number]  │  Cumulative: [Number]
  By source: Organic [X%] / Paid [X%] / Store feature [X%]

RETENTION
  Day 1: [X%]  │  Day 3: [X%]  │  Day 7: [X%]

ENGAGEMENT
  DAU: [Number]  │  Avg session: [X min]  │  Tutorial completion: [X%]

REVENUE
  Today: ¥[Amount]  │  ARPU: ¥[Amount]  │  Paying conversion: [X%]

COMMUNITY
  Sentiment: [Positive/Mixed/Negative]
  Top issues: [List]
  Fan content volume: [Count]

PLATFORM PERFORMANCE
  [Per-platform install and rating breakdown]

ACTION ITEMS
  • [Issue 1]: [Action + owner]
  • [Issue 2]: [Action + owner]
═══════════════════════════════════════
```

---

## 26.6 Beta Feedback Integration

### Collecting Beta Feedback

| Method | When | What to Capture |
|--------|------|----------------|
| **In-game surveys** | During and after beta | Satisfaction, confusion points, feature requests |
| **Community monitoring** | Throughout beta | Organic feedback, sentiment, feature discussions |
| **Structured surveys** | End of each beta phase | Detailed feedback on specific features |
| **Focus groups** | Post-beta | Deep qualitative insights from engaged testers |
| **Analytics data** | Throughout | Behavioral data: where do players get stuck, drop off, engage most? |
| **Support tickets** | Throughout | Bug reports, confusion indicators |

### Feedback Categories

| Category | Examples | Routing |
|----------|---------|---------|
| **Bugs** | Crashes, visual glitches, audio issues | → Dev team (immediate) |
| **UX confusion** | Players can't find features, tutorial gaps | → Design team |
| **Content feedback** | "This area is boring" / "I love this spirit" | → Content team |
| **Social features** | "I can't find my friend" / "Chat is too limited" | → Design team |
| **Performance** | Lag, battery drain, loading times | → Engineering team |
| **Monetization** | "This is too expensive" / "What do I get?" | → Product team |
| **Localization** | Translation errors, cultural issues | → Localization team |

### From Feedback to Marketing Insight

| Beta Feedback | Marketing Learning |
|--------------|-------------------|
| "I didn't understand what to do at first" | → Invest heavily in onboarding guides at launch |
| "The flying is SO beautiful" | → Lead all marketing with flight footage |
| "I love playing with my friend" | → Social/multiplayer is the key marketing hook |
| "The music made me emotional" | → Music should be prominent in all video content |
| "I was confused about the season pass" | → Create clear value explanation content |
| "I wish I could customize more" | → Cosmetic showcase content will resonate |

---

## 26.7 Soft Launch Strategy

### What Is a Soft Launch?

A limited release in select markets before the full CN launch. Used to:
- Test monetization with real spending
- Validate retention curves
- Optimize onboarding flow
- Stress test infrastructure at scale
- Build marketing learnings before spending heavily

### Soft Launch Markets for CN Games

| Market | Why | Notes |
|--------|-----|-------|
| **Hong Kong / Macau** | Chinese-speaking; similar culture; iOS and Google Play | Closest proxy for CN mainland |
| **Taiwan** | Chinese-speaking; similar gaming culture | Strong gaming market; good test bed |
| **Southeast Asia** | Growing market; diverse but accessible | Singapore, Malaysia for Chinese-speaking audiences |

### Soft Launch → Full Launch Transition

| Soft Launch Phase | Duration | Decision Gates |
|-------------------|----------|---------------|
| **Phase 1: Core test** | 2–4 weeks | Day 1/7 retention meets target? |
| **Phase 2: Monetization test** | 2–4 weeks | ARPU and conversion rate acceptable? |
| **Phase 3: Scale test** | 2–4 weeks | Can infrastructure handle CN scale? |
| **Full launch decision** | — | All gates passed → green light for CN launch |

### What to Learn During Soft Launch

| Metric | Target | Action if Below Target |
|--------|--------|----------------------|
| **Day 1 retention** | > 40% | Investigate onboarding friction |
| **Day 7 retention** | > 20% | Analyze content engagement drop-off |
| **Day 30 retention** | > 10% | Evaluate social feature and content depth |
| **Paying conversion** | > 3% | Review monetization clarity and value perception |
| **ARPU** | Competitive benchmark | Adjust pricing, bundles, or IAP structure |
| **Session length** | > 15 min avg | Assess engagement loop |
| **Crash rate** | < 1% | Fix stability issues before scaling |

---

## 26.8 New Game Launch vs. Major Expansion Launch

If tgc launches a new game or Sky has a major platform expansion:

### New Game Launch Checklist

| Phase | Marketing Tasks |
|-------|----------------|
| **Brand building** | Establish game identity, visual language, key messaging |
| **Community seeding** | Build community from scratch across platforms |
| **Audience education** | Explain what the game is and why people should care |
| **Pre-registration** | Multi-store pre-reg campaign with milestone rewards |
| **KOL strategy** | Identify and brief creators for launch content |
| **Media strategy** | Press kit, media previews, review copies |
| **Launch campaign** | Full cross-platform campaign with paid media |
| **Post-launch support** | 30-day intensive monitoring and optimization |

### Major Expansion Launch (e.g., New Platform) Checklist

| Phase | Marketing Tasks |
|-------|----------------|
| **Audience identification** | Who on this new platform would play Sky? |
| **Platform adaptation** | Marketing content optimized for new platform's audience |
| **Cross-promotion** | Encourage existing players to try the new platform; invite new platform players |
| **Platform partnerships** | Feature requests, promotional partnerships with platform owner |
| **Guide content** | How to play Sky on [new platform]; cross-save instructions |
| **Community expansion** | New community spaces for platform-specific discussions |

---

## Knowledge Check

1. Design a closed beta recruitment campaign for a new tgc game targeting 10,000 CN testers. Include channels, messaging, and selection criteria.
2. It's open beta launch day and the game's tutorial completion rate is only 45%. What do you do in the next 48 hours?
3. During soft launch in Hong Kong, Day 7 retention is 12% (below the 20% target). List five hypotheses and how you'd test each.
4. Create a pre-registration campaign with 4 milestone tiers. Design the rewards, messaging, and timeline.
5. The full CN launch is in 30 days. Write the launch day war room schedule and contingency plan for the top 3 risks.

---

[← Module 14: Live Ops, Seasons & Monetization](14-live-ops-monetization.md) | [Next: Module 16 — Cross-Platform Publishing →](16-cross-platform.md) | [Main Guide](../README.md)
