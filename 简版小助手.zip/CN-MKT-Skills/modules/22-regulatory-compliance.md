# Module 22: CN Gaming Regulatory & Compliance

> China has the world's most complex gaming regulatory environment. Understanding the rules isn't optional — it's essential to protecting both the game and the players.

---

## 17.1 Why Regulatory Knowledge Matters for Marketing

As a marketer, you're NOT a lawyer — but you need to understand regulations because:
- **Marketing content is regulated** — what you say, show, and promise has legal implications
- **Platform policies enforce government regulations** — violating them can get content removed or accounts suspended
- **Mistakes are expensive** — regulatory violations can result in fines, game shutdowns, or PR crises
- **Proactive compliance builds trust** — with regulators, platforms, partners, and players

### Golden Rule
> When in doubt, consult the legal team. This module provides awareness, not legal advice.

---

## 17.2 Key Regulatory Bodies

| Body | Abbreviation | Role |
|------|-------------|------|
| **国家新闻出版署** (National Press and Publication Administration) | NPPA | Game approvals (版号), content review, minor protection |
| **国家广播电视总局** (National Radio and Television Administration) | NRTA | Live streaming, video content regulation |
| **市场监管总局** (State Administration for Market Regulation) | SAMR | Advertising law, consumer protection |
| **中央网信办** (Cyberspace Administration of China) | CAC | Internet content governance, data security |
| **文化和旅游部** (Ministry of Culture and Tourism) | MCT | Cultural content standards |

---

## 17.3 Game Publishing Regulations

### 版号 (ISBN / Game License)
- All games released in China require a **版号** (game publication number)
- Sky's CN version operates under NetEase's publishing license
- Marketing implications:
  - Only promote the **approved version** of the game
  - Content that appears in the global version but NOT the CN version cannot be marketed to CN players
  - Any major game updates may need separate regulatory review

### Content Restrictions Affecting Marketing

| Category | Regulation | Marketing Impact |
|----------|-----------|-----------------|
| **Gambling/gacha** | Gacha probability must be publicly disclosed | If Sky introduces any random-reward mechanic, odds must be visible |
| **Violence** | Excessive violence restricted | Sky is low-risk, but be careful with promotional content showing Eden's more intense moments |
| **Religious content** | Religious symbols and themes require careful treatment | Sky's spiritual themes should avoid explicit religious references in CN marketing |
| **Political sensitivity** | Content must not threaten national unity or social stability | Avoid any political references in marketing; review international content for CN sensitivity |
| **Historical/cultural** | Historical and cultural references must be respectful | Sky's cultural collaborations need careful vetting |
| **Foreign content** | Foreign games face additional scrutiny | As a US-developed game, Sky's marketing must be particularly careful about cultural framing |

---

## 17.4 Minor Protection Regulations (未成年人保护)

### The Regulations
China has strict rules protecting minors in gaming:
- **Playtime limits**: Minors limited to specific hours (typically 1 hour on Fri/Sat/Sun and holidays)
- **Real-name registration**: All players must register with real identity information
- **Spending limits**: Minors have monthly spending caps on in-game purchases
- **Parental oversight**: Systems must support parental monitoring

### Marketing Implications

| Rule | What This Means for Marketing |
|------|------------------------------|
| **Never target minors with IAP messaging** | No ads encouraging children to spend money |
| **Age-appropriate content** | While Sky is family-friendly, marketing must comply with minor-targeted content rules |
| **No addiction-promoting language** | Avoid messaging that implies "you can't stop playing" or "you must complete the collection" |
| **Playtime awareness** | Never encourage excessive play; some platforms require health reminders |
| **KOL content** | If a KOL's audience is primarily minors, additional restrictions apply |
| **School-hours marketing** | Be mindful of content timing during school hours |

### Best Practice Statement
Include in relevant materials:
> 光遇倡导健康游戏。适度游戏益脑，沉迷游戏伤身。合理安排时间，享受健康生活。
> (Sky advocates healthy gaming. Moderate gaming benefits the mind; addiction harms the body. Manage your time wisely and enjoy a healthy life.)

---

## 17.5 Advertising Law (广告法)

### Key Advertising Rules Affecting Marketing

| Rule | Requirement | Example |
|------|------------|---------|
| **Truthful advertising** | All claims must be verifiable and accurate | Don't exaggerate game features or player numbers |
| **No absolute claims** | Cannot use "最" (most), "第一" (first/best), etc. without evidence | Don't say "最好玩的游戏" (most fun game) |
| **No false urgency** | Cannot create artificial scarcity or false deadlines | Be accurate about limited-time events |
| **Clear identification** | Ads must be identifiable as ads | KOL sponsored content must be labeled as advertising |
| **Price transparency** | IAP prices must be clear and accurate | Season pass price must match what's in-store |
| **Comparison advertising** | Cannot unfairly disparage competitors | Never negatively compare Sky to other games |
| **Celebrity/KOL endorsement** | Endorsers bear responsibility for claims | Brief KOLs carefully on what they can/can't claim |

### Common Marketing Copy Violations (Avoid These)

| Violation | Example | Correction |
|-----------|---------|-----------|
| Absolute superlative | "最美的游戏世界" (Most beautiful game world) | "美不胜收的游戏世界" (A breathtakingly beautiful game world) |
| Unverifiable claim | "全球3亿玩家的选择" (without verification) | Use verified, sourced statistics only |
| Misleading free claim | "完全免费" if IAP exists | "免费下载，内含可选付费内容" (Free download, optional paid content) |
| Hidden conditions | Not disclosing that a reward requires purchase | Always disclose all conditions for promotions |

---

## 17.6 Data Privacy & User Data

### Key Regulations
- **个人信息保护法 (PIPL)** — China's Personal Information Protection Law
- **数据安全法** — Data Security Law
- **网络安全法** — Cybersecurity Law

### Marketing Implications

| Area | Requirement |
|------|------------|
| **Data collection** | Clearly disclose what data you collect and why; obtain consent |
| **User targeting** | Paid advertising targeting must comply with data regulations |
| **Community data** | Player information from community channels is protected data |
| **Cross-border transfer** | Player data cannot be freely transferred outside China |
| **Analytics tools** | Ensure third-party tools comply with CN data laws |
| **Marketing databases** | KOL contacts, partner lists, and user surveys must be handled properly |

### Practical Guidelines for Marketers
1. **Never collect more data than needed** for marketing purposes
2. **Never share player data** externally without proper consent and legal basis
3. **Never export player information** to non-CN tools without legal review
4. **Survey data** requires proper consent and privacy notices
5. **When in doubt**, consult with legal and the NetEase data compliance team

---

## 17.7 Content Platform Regulations

### Platform-Specific Compliance

| Platform | Key Regulations | Marketing Impact |
|----------|----------------|-----------------|
| **Douyin** | Real-name verification; AI content labeling; advertising disclosure | Label sponsored content; disclose AI-generated content |
| **Bilibili** | Content review system; danmaku regulation; minor protection | Content may be delayed by review; plan buffer time |
| **Xiaohongshu** | Advertising disclosure; false marketing crackdown; medical/beauty claims | Never make health claims about gaming; label partnerships |
| **WeChat** | Data privacy; advertising rules; account operation rules | Comply with WeChat advertising format requirements |
| **Weibo** | Information disclosure; trending topic rules; advertising law | Paid trending topics must be labeled; follow disclosure rules |

### Content Review Considerations
- Most platforms conduct **pre-publication or post-publication review** of content
- Content may be **delayed, flagged, or removed** if it triggers review systems
- **Sensitive keywords** change frequently — maintain an updated list
- **Appeal processes** exist but take time — prevention is better than cure
- During **sensitive periods** (political events, anniversaries), platform scrutiny increases — be extra cautious with timing and content

---

## 17.8 Live Streaming Regulations

If Sky conducts live streams (直播) on Bilibili, Douyin, or other platforms:

| Requirement | Details |
|-------------|---------|
| **Streamer qualification** | Streamers may need real-name registration with the platform |
| **Content standards** | Same content restrictions as pre-recorded content |
| **Gift/tip regulations** | Platforms regulate virtual gifting; minor spending restrictions apply |
| **Recording requirement** | Live streams should be recorded and archived |
| **Real-time monitoring** | Platform monitors live content in real-time; violations can trigger immediate takedown |

---

## 17.9 IP & Copyright for Marketing

### Protecting Sky's IP
| Asset | Protection Level | Notes |
|-------|-----------------|-------|
| **"光·遇" brand name** | Trademark registered | Monitor for unauthorized use |
| **Game characters and cosmetics** | Copyright | Fan art is generally encouraged under fair use, but commercial use requires permission |
| **Music/OST** | Copyright | License properly for marketing; brief KOLs on music usage |
| **Screenshots and video** | Copyright | Fan captures are a gray area — Sky's policy should be generous but clear |

### Using Third-Party Content in Marketing
| Content Type | Requirement |
|-------------|------------|
| **Music in videos** | Must be licensed or from royalty-free library; verify Douyin/Bilibili music library licenses |
| **Fan-created content** | Get explicit permission before using in official channels; always credit |
| **Stock images/video** | Use properly licensed content only |
| **KOL content** | Usage rights should be specified in the partnership contract |
| **Brand partner logos** | Get written approval for logo usage; follow their brand guidelines |

---

## 17.10 Compliance Checklist for Marketing Content

Before publishing any marketing content, verify:

- [ ] **Truthful**: All claims are accurate and verifiable
- [ ] **No prohibited superlatives**: No "最好," "第一," etc. without evidence
- [ ] **IAP transparency**: Any paid content is clearly disclosed
- [ ] **Minor-appropriate**: Content doesn't encourage excessive spending or play
- [ ] **Advertising disclosure**: Sponsored content is properly labeled
- [ ] **AI disclosure**: AI-generated content is labeled per current regulations
- [ ] **Data compliant**: No unauthorized use of personal data
- [ ] **IP cleared**: All third-party content is properly licensed/permitted
- [ ] **Culturally sensitive**: No political, religious, or culturally inappropriate content
- [ ] **Platform compliant**: Follows specific platform's content guidelines
- [ ] **Health reminder**: Included where required (game download pages, extended content)
- [ ] **Legal review**: Major campaigns reviewed by legal team

---

## 17.11 Staying Current

Regulations evolve frequently. Stay informed through:

| Source | Type | Frequency |
|--------|------|-----------|
| **Legal team updates** | Internal briefings | As regulations change |
| **GameLook (游戏葡萄)** | Industry news | Daily monitoring |
| **NPPA announcements** | Official government notices | As published |
| **Platform policy updates** | Bilibili, Douyin, etc. creator policy pages | Monthly review |
| **Industry associations** | China Audio-Video and Digital Publishing Association | Periodic updates |
| **NetEase legal team** | Partner compliance updates | Regular check-ins |

---

## Knowledge Check

1. A KOL wants to say "光遇是最好的治愈游戏" in their sponsored video. Is this allowed? What would you suggest instead?
2. You're planning a campaign targeting university students. What minor protection rules should you still be aware of?
3. A global campaign video includes a scene with religious imagery. What do you do before publishing it in CN?
4. You want to use player survey data to create targeted ads on Douyin. What compliance steps are needed?
5. A new regulation on AI-generated content is announced. What's your action plan for the marketing team?

---

[← Module 21: AI Applications in Marketing](21-ai-applications.md) | [Appendix: Terminology Glossary →](../appendix-glossary.md) | [Main Guide](../README.md)
