# Module 08: Creative Production & Platform Formats

> In Sky's marketing, every pixel and every frame carries the game's emotional DNA. Master the craft of creating content that honors the game's beauty across every platform.

---

## 8.1 Sky's Creative Philosophy

### The Creative North Star

Sky's creative assets should always reflect:

| Principle | Application |
|-----------|-------------|
| **Beauty over spectacle** | Serene flight > flashy combat; sunset > explosion |
| **Emotion over information** | Make viewers *feel*, then *learn* |
| **Connection over isolation** | Show players together, not alone |
| **Invitation over promotion** | "Come see this world" not "Download now" |
| **Authenticity over polish** | A genuine gameplay moment > an over-produced ad |

---

## 8.2 Creative Types & When to Use Them

| Creative Type | Best For | Platforms | Production Level |
|--------------|---------|-----------|-----------------|
| **Beauty reels** | Awareness, brand building | Douyin, XHS | Tier 2–3 |
| **Gameplay showcases** | Consideration, onboarding | Bilibili, Douyin | Tier 1–2 |
| **Emotional moment clips** | Engagement, retention | All | Tier 2–3 |
| **Season trailers** | Season launch | All | Tier 3–4 (HQ-provided) |
| **Guide/tutorial content** | Onboarding, engagement | Bilibili, XHS | Tier 1–2 |
| **Community spotlights** | Advocacy, community | All | Tier 1 |
| **Behind-the-scenes** | Deepening connection | Bilibili, WeChat | Tier 2 |
| **KOL collaborations** | Awareness, acquisition | Per KOL platform | Varies |
| **Paid ad creatives** | UA, retargeting | Douyin Ads, Bilibili Ads | Tier 2–3 |
| **Static images / posters** | Announcements, social | All | Tier 2–3 |

### Production Tiers

| Tier | Description | Time | Tools |
|------|-------------|------|-------|
| **Tier 1** | Quick capture + light edit | 1–2 hours | Phone + 剪映 |
| **Tier 2** | Planned capture + solid edit | 4–8 hours | Phone/PC + 剪映/Premiere |
| **Tier 3** | Storyboarded + professional edit | 2–5 days | Professional tools + team |
| **Tier 4** | Full production (brand film) | 1–4 weeks | Agency/production house |

---

## 8.3 In-Game Capture Techniques

### Camera Techniques for Sky

| Technique | How | Best For |
|-----------|-----|----------|
| **Slow pan** | Smoothly rotate camera across a vista | Establishing realm beauty |
| **Follow flight** | Track a character in flight | Dynamic movement content |
| **Close-up emote** | Zoom in on character expression/emote | Emotional moments |
| **Overhead scenic** | Position camera above, looking down at clouds | Wallpaper-quality shots |
| **Multiplayer moment** | Capture hand-holding, group activities | Social gameplay content |

### Best Realms for Content

| Realm | Visual Strength | Content Type |
|-------|----------------|-------------|
| **Isle of Dawn** | Golden sunrise, open space | New player content, beauty |
| **Daylight Prairie** | Butterflies, meadows, flight | Peaceful/healing content |
| **Hidden Forest** | Rain, mystery, dark atmosphere | Cinematic, emotional |
| **Valley of Triumph** | Arena, ice rink, activity | Social gameplay, fun |
| **Golden Wasteland** | Dramatic skies, ruins | Epic/emotional storytelling |
| **Vault of Knowledge** | Stars, constellations | Lore, contemplative |
| **Eye of Eden** | Intense, emotional climax | Advanced player, emotional |

---

## 8.4 Video Content Formulas

### Formula 1: Beauty Reel
```
Hook (0–3s): Most breathtaking visual moment
Body (3–20s): 3–5 scenic shots with smooth transitions
Close (20–30s): Character silhouette against sky / subtle branding
Audio: Sky OST or trending ambient track
```

### Formula 2: Emotional Moment
```
Hook (0–3s): Close-up of character interaction
Build (3–15s): Story of the moment (meeting a stranger, helping a friend)
Climax (15–25s): The emotional peak (hand-holding, shared music, gift)
Close (25–30s): Lingering shot; text overlay if needed
Audio: Sky OST — emotional track
```

### Formula 3: Guide/Tutorial
```
Hook (0–5s): "你知道这个隐藏的地方吗?" (Did you know about this hidden spot?)
Steps (5–45s): Clear walkthrough with text overlays
Result (45–60s): The payoff / reward / beautiful destination
Audio: Voiceover or text + background music
```

### Formula 4: Community Spotlight
```
Intro (0–5s): "来看看这位光遇玩家的创作" (Check out this player's creation)
Feature (5–40s): Showcase the fan content / story
Shoutout (40–50s): Credit the creator; encourage community
Audio: Fan-created music or Sky OST
```

### Formula 5: Behind the Scenes
```
Hook (0–5s): "你好奇这个场景是怎么做的吗?" (Curious how this realm was made?)
Content (5–120s): Dev insights, design process, team stories
Close: Invitation to experience it in-game
Audio: Conversational; Sky OST under
```

---

## 8.5 Editing Tools & Workflows

### Tool Recommendations

| Tool | Best For | Platform |
|------|---------|----------|
| **剪映 / CapCut** | Quick social edits, Douyin-optimized | Mobile + desktop |
| **Premiere Pro** | Professional long-form editing | Desktop |
| **Final Cut Pro** | Professional editing (Mac) | Desktop |
| **After Effects** | Motion graphics, effects | Desktop |
| **Figma / Photoshop** | Static design, thumbnails | Desktop |
| **Canva** | Quick social graphics | Web + mobile |

### Editing Workflow (Tier 2)
```
Capture → Select best clips → Rough cut → Add music →
Fine-tune pacing → Add text/overlays → Color correct →
Export per platform specs → QA review → Publish
```

### Platform-Specific Editing Rhythm

| Platform | Pacing | Style |
|----------|--------|-------|
| **Douyin** | Fast cuts (1–3s per shot); hook in first frame | Trendy, dynamic, sound-on designed |
| **Bilibili** | Slower (3–8s per shot); room to breathe | Cinematic, voiceover-friendly |
| **Xiaohongshu** | Aesthetic-first; beautiful compositions | Lifestyle tone, warm color grading |
| **WeChat** | Story-driven; beginning/middle/end | Article-companion; informative |

---

## 8.6 Complete Creative Specs Reference

### Video Specifications

| Platform | Aspect Ratio | Recommended Length | File Format | Max Size |
|----------|-------------|-------------------|-------------|----------|
| **Douyin** | 9:16 | 15–60s (sweet spot: 30s) | MP4 (H.264) | 4GB |
| **Bilibili** | 16:9 | 3–10 min (can be longer) | MP4 (H.264) | 8GB |
| **Xiaohongshu** | 3:4 or 9:16 | 1–5 min | MP4 | 5GB |
| **WeChat 视频号** | 9:16 or 16:9 | 1–5 min | MP4 | 5GB |
| **Weibo** | 16:9 or 9:16 | 1–5 min | MP4 | 5GB |

### Static Image Specifications

| Platform | Format | Dimensions (px) | Aspect Ratio | Max Size | Notes |
|----------|--------|-----------------|-------------|----------|-------|
| **Douyin** | Feed cover | 1080×1920 | 9:16 | — | Auto from video or custom |
| **Bilibili** | Video cover | 1146×717 | 16:10 | 2MB | Custom upload; add text |
| **Xiaohongshu** | Note cover | 1080×1440 | 3:4 | 20MB | First image is critical |
| **Xiaohongshu** | Note image | 1080×1440 | 3:4 | 20MB | Up to 18 images |
| **WeChat 公众号** | Article cover (single) | 900×383 | 2.35:1 | 2MB | Shown in subscription list |
| **WeChat 公众号** | Article cover (multi) | 500×500 | 1:1 | 2MB | Thumbnail in list view |
| **WeChat 公众号** | In-article image | 1080 wide | — | 2MB | Auto-scaled to fit |
| **Weibo** | Feed image | 1080×1080 | 1:1 | 5MB | Square is safest; up to 9 images |
| **Weibo** | Long image | 1080×(variable) | 1:2+ | 10MB | For infographics |

### Paid Ad Specifications

| Platform | Format | Dimensions | Duration | Notes |
|----------|--------|-----------|----------|-------|
| **Douyin 信息流** | In-feed video | 720×1280 or 1080×1920 | 5–60s | First 3s critical; sound-on |
| **Douyin 开屏** | Splash screen | 1080×1920 | 3–5s | Premium; high impact |
| **Bilibili 信息流** | In-feed | 1280×720 (16:9) | 15–60s | Native feel preferred |
| **XHS 信息流** | In-feed | 1080×1440 | 5–60s | Authentic style outperforms |
| **WeChat 朋友圈** | Moments ad | 750×(variable) | Up to 30s video | Looks like friend's post |
| **Apple Search Ads** | Text + screenshots | Store assets | — | Uses existing store listing |

### Copy Length Guidelines

| Platform | Ideal Length | Notes |
|----------|-------------|-------|
| **Douyin caption** | 50–150 chars | Front-load before truncation |
| **Bilibili description** | 100–300 chars | Include timestamps for long videos |
| **Xiaohongshu note** | 300–800 chars | Authentic, conversational |
| **WeChat article** | 800–2000 chars | Short paragraphs, heavy visuals |
| **Weibo post** | 50–200 chars | Concise; include hashtags |

---

## 8.7 Thumbnail & Cover Design

### Principles

| Principle | Details |
|-----------|---------|
| **Readable at small size** | Test at mobile thumbnail scale |
| **One clear focal point** | Don't cram multiple elements |
| **Text contrast** | White/light text on dark backgrounds (or vice versa) |
| **Consistent style** | Build recognizable visual identity across covers |
| **Emotion in the image** | Character expressions, dramatic lighting, beautiful vistas |

### Audio & Music Best Practices

| Principle | Application |
|-----------|-------------|
| **Sky OST is your best asset** | Instantly recognizable; emotionally resonant |
| **Sound-on design** | Douyin/Bilibili users often have sound on — design for it |
| **Sound-off safety** | Always add text overlays for key information |
| **Music licensing** | Use Sky OST (cleared) or royalty-free; never unlicensed tracks |
| **Audio mixing** | Music at 60–70% when voiceover present; 100% for ambient |

---

## 8.8 Creative Testing Framework

### A/B Testing for Creative Assets

| Variable | What to Test | How to Measure |
|----------|-------------|---------------|
| **Hook (first 3s)** | Beauty vs. curiosity vs. social moment | View completion rate |
| **Length** | 15s vs. 30s vs. 60s | Engagement rate, shares |
| **Aspect ratio** | 9:16 vs. 3:4 vs. 16:9 on same platform | CTR |
| **Copy tone** | Poetic vs. direct vs. question-based | Engagement rate |
| **CTA** | Soft invite vs. no CTA vs. direct | Install rate, CTR |
| **Thumbnail** | Character-focused vs. landscape vs. text-heavy | Click-through rate |

### Performance Benchmarks (CN Social Platforms)

| Metric | Douyin | Bilibili | XHS |
|--------|--------|----------|-----|
| **Avg. view duration** | > 7s good | > 30s good | > 10s good |
| **Engagement rate** | > 3% strong | > 5% strong | > 4% strong |
| **Share rate** | > 0.5% good | > 1% good | > 0.3% good |
| **Save rate** | > 1% good | — | > 2% good |

---

## 8.9 Asset Management

### File Organization
```
Campaign-Name/
├── Briefs/
├── Source-Footage/
├── Edits/
│   ├── Douyin/
│   ├── Bilibili/
│   ├── XHS/
│   └── WeChat/
├── Thumbnails/
├── Approved-Finals/
└── Reports/
```

### Naming Convention
```
[Date]_[Campaign]_[Type]_[Platform]_[Version]
20260215_CNY_Video-30s_Douyin_v2.mp4
20260301_SeasonLaunch_Poster_XHS_v1-final.png
```

### Creative Fatigue Management

| Signal | Action |
|--------|--------|
| Engagement dropping on a running creative | Refresh with new hook or visual variation |
| 2+ weeks on same ad creative | Rotate in new variants |
| Community commenting "又是这个" (this again) | Retire that creative immediately |
| Strong performer | Extract learnings; create variants in same style |

---

## Knowledge Check

1. Choose one of the 5 video formulas and plan a complete video for the next season launch — script, shots, music, and platform.
2. A Douyin video has high view count but low completion rate. Diagnose and propose an edit-level fix.
3. Export the same piece of content for Douyin, Bilibili, and Xiaohongshu. What changes for each version?
4. Your creative team has 8 hours to produce content for a surprise in-game event. Using the tier system, what quality level do you target and what's your workflow?
5. Design an A/B test for Sky's paid Douyin ad creative — hypothesis, variables, metrics, and decision criteria.

---

## Related Modules
- [Module 04: CN Social Media Platforms](04-social-media-platforms.md) — Platform strategies
- [Module 07: Content Localization & Copywriting](07-content-localization.md) — Copy for each platform
- [Module 10: Campaign Planning & PM](10-campaign-planning-pm.md) — Creative brief and approval flow

---

[← Module 07: Content Localization](07-content-localization.md) | [Next: Module 09 — Community Building →](09-community-building.md) | [Main Guide](../README.md)
