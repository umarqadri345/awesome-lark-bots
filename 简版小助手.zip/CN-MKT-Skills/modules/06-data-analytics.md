# Module 06: Data Analytics & Performance Measurement

> If you can't measure it, you can't improve it. But data without context is just noise — your job is to turn numbers into stories and stories into decisions.

---

## 13.1 The Analytics Mindset

### Data-Informed, Not Data-Obsessed
- **Data tells you WHAT happened** — your brain tells you WHY
- Numbers without CN market context are misleading
- A "bad" metric in one context can be a "good" metric in another
- Always ask: "So what? What does this mean for what we do next?"

### The Three Levels of Analytics Maturity

| Level | Description | Example |
|-------|-------------|---------|
| **Reporting** | "What happened?" | "We got 500K views on Douyin this week" |
| **Analysis** | "Why did it happen?" | "Views spiked because we used a trending audio that reached non-gamer audiences" |
| **Insight** | "What should we do about it?" | "We should create a recurring 'trending audio + Sky beauty shots' format — it's our best UA creative type" |

Always push to Level 3.

---

## 13.2 Key Metrics Framework

### The Marketing Funnel for Sky CN

```
AWARENESS ──► INTEREST ──► DOWNLOAD ──► ACTIVATION ──► RETENTION ──► REVENUE ──► ADVOCACY
  │              │            │             │              │            │            │
 Impressions   Clicks      Installs    Tutorial       Day 7/30     Season      Fan content
 Reach         Saves       CPI        completion     retention     pass rate    creation
 Views         Follows     ASO rank   First session  DAU/MAU      ARPU         Referrals
```

### Metric Definitions & Benchmarks

#### Awareness Metrics
| Metric | Definition | What Good Looks Like | Platform |
|--------|-----------|---------------------|----------|
| **Impressions** | Times content was displayed | Varies by spend/organic reach | All |
| **Reach** | Unique users who saw content | Higher = broader awareness | All |
| **Video views** | Times video was played (definitions vary by platform) | Completion rate > 15% on Douyin | Douyin, Bilibili |
| **Share of voice** | Sky mentions vs. competitor mentions | Growing trend quarter over quarter | Cross-platform |

#### Engagement Metrics
| Metric | Definition | What Good Looks Like | Platform |
|--------|-----------|---------------------|----------|
| **Engagement rate** | (Likes + Comments + Shares) / Impressions | 3–5% organic on Xiaohongshu | All |
| **三连 rate** | Like + Coin + Collect on Bilibili | > 5% for official content | Bilibili |
| **Save rate (收藏)** | Saves / Impressions | > 5% on Xiaohongshu = strong | Xiaohongshu |
| **Comment quality** | Ratio of meaningful vs. spam comments | Subjective but track sentiment | All |
| **Share rate** | Shares / Impressions | > 1% = viral potential | All |
| **Danmaku density** | Bullet comments per minute on Bilibili | Higher = more engaged viewers | Bilibili |

#### Acquisition Metrics
| Metric | Definition | What Good Looks Like | Notes |
|--------|-----------|---------------------|-------|
| **CPI (Cost Per Install)** | Ad spend / installs | Depends on channel; track trends | Lower = more efficient |
| **CPR (Cost Per Registration)** | Ad spend / registered users | Should be < 1.5x CPI | Filters out accidental installs |
| **Organic install ratio** | Organic installs / total installs | Higher = healthy brand | Track over time |
| **ASO ranking** | Position in app store search results | Top 5 for key terms | 七麦数据 tracking |
| **Install-to-registration rate** | Registrations / installs | > 70% is healthy | Drop-off indicates onboarding friction |

#### Retention & Revenue Metrics
| Metric | Definition | What Good Looks Like | Notes |
|--------|-----------|---------------------|-------|
| **Day 1 retention** | % of new users returning day after install | > 35% for casual games | Critical early signal |
| **Day 7 retention** | % returning after 7 days | > 15% | Shows sustained interest |
| **Day 30 retention** | % returning after 30 days | > 8% | Long-term engagement |
| **DAU / MAU ratio** | Daily active / Monthly active | > 20% = sticky game | Sky's social nature should help |
| **Season pass conversion** | Pass purchases / active players | Track vs. previous seasons | Key revenue indicator |
| **ARPU** | Revenue / active users | Track trend over time | Compare to genre benchmarks |
| **ARPPU** | Revenue / paying users | Higher = strong value perception | Important for IAP strategy |

---

## 13.3 Platform-Specific Analytics

### Bilibili Analytics Dashboard
| Metric | Where to Find | What to Watch |
|--------|--------------|---------------|
| Play volume (播放量) | Video analytics | Absolute views + trend |
| 三连 data | Video analytics | Like/coin/collect ratio |
| Danmaku count | Video analytics | Engagement intensity |
| Fan growth | Channel analytics | Net new followers per period |
| Traffic sources | Video analytics | Search vs. recommendation vs. existing fans |
| Audience demographics | Channel analytics | Age, gender, geography match to target |
| Revenue (if applicable) | 充电/sponsorship data | Creator economy metrics |

### Douyin Analytics Dashboard
| Metric | Where to Find | What to Watch |
|--------|--------------|---------------|
| Play count | Video analytics | Total views |
| Completion rate | Video analytics | % who watched to end — most important Douyin metric |
| Interaction rate | Video analytics | Likes, comments, shares combined |
| Follower conversion | Video analytics | New followers from each video |
| Traffic sources | Video analytics | "For You" page % (= algorithm boost) |
| Audience portrait | Account analytics | Demographics of viewers |
| DOU+ performance | Ad analytics | Paid boost efficiency |

### Xiaohongshu Analytics Dashboard
| Metric | Where to Find | What to Watch |
|--------|--------------|---------------|
| Note impressions | Note analytics | Reach of each post |
| Click-through rate | Note analytics | Cover image effectiveness |
| Save rate (收藏率) | Note analytics | Most important XHS metric — signals high-value content |
| Comment volume | Note analytics | Community engagement |
| Search impression share | Professional dashboard | How well you rank for target keywords |
| Follower growth | Account analytics | Net new per period |

### WeChat Analytics
| Metric | Where to Find | What to Watch |
|--------|--------------|---------------|
| Article read count | 公众号 backend | Total reads per article |
| Open rate | 公众号 backend | Reads / followers — headline effectiveness |
| Share rate | 公众号 backend | Shares / reads — content resonance |
| Read completion | 公众号 backend | How far people scroll |
| 视频号 metrics | 视频号 backend | Views, likes, shares for video content |
| Mini-program DAU | Mini-program backend | Utility tool engagement |

---

## 13.4 Analytics Tools for CN Market

### Free / Platform-Native Tools
| Tool | Coverage | Best For |
|------|----------|---------|
| **Bilibili Creator Center** | Bilibili | Channel and video analytics |
| **Douyin Creator Center** | Douyin | Video performance, audience data |
| **Xiaohongshu Professional Dashboard** | Xiaohongshu | Note analytics, search data |
| **WeChat 公众号 Backend** | WeChat | Article and follower analytics |
| **Weibo Data Center** | Weibo | Post performance, trending data |

### Third-Party Analytics Tools
| Tool | Coverage | Best For | Cost |
|------|----------|---------|------|
| **新榜 (Newrank)** | Cross-platform | Content performance benchmarking | Paid |
| **蝉妈妈 (Chanmama)** | Douyin, Kuaishou | KOL analytics, trending content | Paid |
| **千瓜 (Qiangua)** | Xiaohongshu | Note analytics, KOL discovery | Paid |
| **飞瓜 (Feigua)** | Douyin, Kuaishou, Bilibili | Video analytics, trending | Paid |
| **七麦数据 (Qimai)** | App Store, Android stores | ASO, app rankings, download estimates | Freemium |
| **Sensor Tower** | Global app stores | Competitive intelligence, market sizing | Paid |
| **火烧云 (Huoshaoyun)** | Bilibili | UP主 analytics, content trends | Paid |

---

## 13.5 Building Dashboards & Reports

### Dashboard Design Principles
1. **Answer a question** — Every dashboard section should answer a specific question
2. **Hierarchy matters** — Most important metrics at top; details below
3. **Context is everything** — Show metrics with comparisons (vs. last period, vs. target, vs. benchmark)
4. **Visual clarity** — Use charts for trends, tables for comparisons, big numbers for headlines
5. **Actionable** — If a metric is red, what should someone DO about it?

### Weekly Dashboard Template

```
══════════════════════════════════════════
  SKY CN — WEEKLY ANALYTICS DASHBOARD
  Week: [Date Range]
══════════════════════════════════════════

📊 HEADLINE METRICS (vs. last week)
┌─────────────┬──────────┬──────────┬─────────┐
│ Metric      │ This Week│ Last Week│ Change  │
├─────────────┼──────────┼──────────┼─────────┤
│ Total Reach │          │          │   %     │
│ Engagement  │          │          │   %     │
│ New Follows │          │          │   %     │
│ Installs    │          │          │   %     │
└─────────────┴──────────┴──────────┴─────────┘

📱 PLATFORM BREAKDOWN
[Table with per-platform key metrics]

🏆 TOP 3 CONTENT THIS WEEK
1. [Platform] [Title] — [Key metric]
2. [Platform] [Title] — [Key metric]
3. [Platform] [Title] — [Key metric]

⚠️ METRICS BELOW TARGET
- [Metric]: [Current] vs. [Target] — [Reason + action]

💡 KEY INSIGHT
[One paragraph: What does this week's data tell us?
What should we do differently next week?]
══════════════════════════════════════════
```

---

## 13.6 Campaign Measurement Framework

### Pre-Campaign: Setting KPIs

For every campaign, define:
| Element | Description | Example |
|---------|-------------|---------|
| **Primary KPI** | The ONE metric that defines success | Installs: 50,000 |
| **Secondary KPIs** | Supporting metrics (2–3) | Engagement rate: >4%; KOL content views: 2M |
| **Tracking plan** | How will you measure each KPI? | App store attribution; platform analytics; UTM links |
| **Targets** | Specific, time-bound numbers | Achieve within 2-week campaign window |
| **Benchmark** | What to compare against | Last season launch; industry average |

### During Campaign: Real-Time Monitoring

| Day | Check | Action |
|-----|-------|--------|
| **Day 1** | All tracking working? Content live? Initial signals? | Fix any tracking issues immediately |
| **Day 2–3** | Early performance vs. projections | Adjust paid media allocation if needed |
| **Day 5** | Mid-campaign check | Scale winners, pause underperformers |
| **Day 7** | Trend analysis | Report to stakeholders; adjust strategy for final push |
| **Day 10–14** | Final push / wind-down | Capture final data; begin reporting |

### Post-Campaign: 复盘 Analytics

| Section | Content |
|---------|---------|
| **Executive summary** | 3–5 sentences: Did we hit our goals? What's the headline? |
| **KPI performance** | Table showing target vs. actual for every KPI |
| **Channel performance** | Which platforms/channels performed best and worst? |
| **Content performance** | Top and bottom performing content pieces with analysis |
| **Audience insights** | Who did we reach? Any surprising segments? |
| **Budget efficiency** | Spend vs. plan; CPI/CPE by channel |
| **Key learnings** | 3–5 actionable insights for future campaigns |
| **Recommendations** | What should we do differently next time? |

---

## 13.7 Attribution & Tracking

### The Attribution Challenge
In CN's fragmented platform ecosystem, tracking a user's journey from awareness to install to purchase is complex:

```
User sees Douyin video → Searches on Xiaohongshu → Reads a review →
Downloads from App Store → Plays for 2 weeks → Buys season pass

Which touchpoint gets credit?
```

### Practical Attribution Approaches
| Method | How It Works | Limitations |
|--------|-------------|-------------|
| **UTM parameters** | Add tracking tags to all links | Not all platforms support external links well |
| **Platform attribution** | Use each platform's built-in conversion tracking | Siloed; can't track cross-platform journeys |
| **Promo codes** | Unique codes per channel/KOL | Relies on user entering code; friction |
| **Post-install surveys** | Ask new users "How did you hear about Sky?" | Self-reported; biased toward recent touchpoint |
| **Correlation analysis** | Compare campaign timing with install spikes | Directional, not precise |
| **KOL-specific tracking links** | Unique links per creator | Good for KOL ROI measurement |

### Best Practice
Use **multiple methods** together — no single attribution method is perfect. Triangulate:
1. Platform analytics (what each platform reports)
2. App store data (install trends correlated with campaigns)
3. Player surveys (qualitative signal)
4. UTM/promo code data (where available)

---

## 13.8 A/B Testing for Marketing

### What to A/B Test
| Element | Platform | Example |
|---------|----------|---------|
| **Thumbnails/covers** | Douyin, Bilibili, Xiaohongshu | Scenic shot vs. character close-up |
| **Headlines/captions** | All | Emotional hook vs. curiosity hook |
| **Posting time** | All | Morning vs. evening |
| **Video length** | Douyin | 15s vs. 30s vs. 60s |
| **CTA type** | Paid ads | Soft invitation vs. direct download |
| **Hashtag sets** | Douyin, Xiaohongshu | Branded vs. trending vs. category |
| **KOL categories** | Cross-platform | Gaming KOL vs. lifestyle KOL |

### A/B Test Discipline
1. **Test one variable at a time** — Otherwise you can't isolate what caused the difference
2. **Sufficient sample size** — Don't call a winner after 100 impressions
3. **Document everything** — Log hypothesis, test setup, results, and decision
4. **Act on results** — Testing without implementing learnings is waste

---

## Knowledge Check

1. Your Douyin video got 1M views but only 500 likes. What does this tell you, and what would you investigate?
2. Build a KPI framework for a Mid-Autumn Festival campaign with primary and secondary metrics.
3. A KOL partnership drove 50K views but only 200 installs. Is this good or bad? What context would you need?
4. Design a weekly dashboard for your manager that fits on one screen. What metrics do you include and exclude?
5. You notice Day 1 retention dropped 5% this month. List three hypotheses and how you'd investigate each.

---

[← Module 05: User Acquisition & App Store Distribution](05-user-acquisition-distribution.md) | [Next: Module 07 — Content Localization & CN Copywriting →](07-content-localization.md) | [Main Guide](../README.md)
