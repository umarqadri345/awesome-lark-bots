# Module 14: Live Ops, Seasons & Monetization

> Sky is a living world. Understanding how seasons, events, and monetization work together lets marketing keep the experience fresh and the community thriving.

---

## 14.1 What Is Live Ops?

Live ops is the continuous management of a game's content, events, and economy after launch. For Sky, this means marketing is never "done" — every season, event, and update is a new campaign opportunity.

### Live Ops Components & Marketing Impact

| Development Decision | Marketing Impact |
|---------------------|-----------------|
| New season launches | Major campaign moment; content cascade across all platforms |
| In-game event begins | Event-specific content; community engagement push |
| New cosmetics released | Showcase content; value communication |
| Game update / patch | Update communications; manage expectations |
| Economy changes (pricing) | Sensitive communication; community management |
| Bug fixes | Reputation management; trust-building through transparency |

---

## 14.2 The Seasonal Content Cycle

### Season Lifecycle

```
ANNOUNCEMENT → PRE-SEASON → LAUNCH → MID-SEASON → FINAL PUSH → SEASON END
  (T-2 weeks)  (T-1 week)  (T-Day)  (Weeks 2-6)  (Last 2w)   (Wrap-up)
```

### Marketing Activities by Phase

| Phase | Content Focus | Key Channels | Goal |
|-------|--------------|-------------|------|
| **Announcement** | Teaser art, trailer, mystery hints | All platforms | Build anticipation |
| **Pre-Season** | Countdown content, KOL previews, guides | Bilibili, Douyin | Convert awareness to intent |
| **Launch** | Season trailer, launch posts, how-to-start guides | All + paid media | Maximize first-week engagement |
| **Mid-Season** | Deep dives, community content, event highlights | Bilibili, XHS, WeChat | Sustain engagement; drive pass sales |
| **Final Push** | "Last chance" content, season recap, collection showcase | All platforms | FOMO conversion; prevent early drop-off |
| **Season End** | Thank you posts, community highlights, next-season tease | WeChat, Weibo | Emotional closure; bridge to next |

---

## 14.3 Event Operations

### Event Categories

| Event Type | Example | Duration | Marketing Scale |
|-----------|---------|----------|----------------|
| **Seasonal event** | Days of Fortune (CNY) | 10–14 days | Major |
| **Themed event** | Days of Love, Days of Nature | 7–10 days | Medium-Large |
| **Anniversary** | Sky anniversary celebration | 2–4 weeks | Major |
| **Collaboration** | Brand/cultural partnership event | 1–3 weeks | Medium |
| **Traveling Spirits** | Returning past spirits | 3–4 days | Small |
| **Community event** | Fan creation contests | 1–3 weeks | Small-Medium |
| **Double currency** | Bonus candle/heart periods | 3–7 days | Small |

### Event Marketing Playbook

For each event, prepare:

```
EVENT BRIEF
├── Event name and dates
├── What's new (content, mechanics, cosmetics)
├── Target audience (new, active, or lapsed players)
├── Key visual assets needed
└── Success metrics

CONTENT PLAN
├── Announcement post (T-3 days)
├── How-to-participate guide (T-day)
├── Daily/ongoing event content
├── Community spotlight content
└── Wrap-up / thank you post

PLATFORM PLAN
├── Bilibili: event walkthrough video
├── Douyin: short highlights, daily clips
├── XHS: visual moments, photo guides
├── WeChat: deep-dive article
└── Weibo: daily updates, hashtag engagement

COMMUNITY PLAN
├── QQ/WeChat group announcements
├── UGC prompts and challenges
├── Fan creation amplification
└── FAQ preparation for common questions
```

---

## 14.4 Content Pipeline Management

### Development-to-Marketing Timeline

| When | Dev Team Provides | Marketing Does |
|------|------------------|----------------|
| **T-6 weeks** | Season concept briefing | Begin campaign strategy |
| **T-4 weeks** | Preview build, key art, trailer draft | Creative brief, KOL outreach |
| **T-2 weeks** | Final assets, confirmed date | Content production, scheduling |
| **T-1 week** | Last-minute changes, patch notes | Adapt content, final QA |
| **T-Day** | Go-live confirmation | Publish, monitor, optimize |

### Embargo Management

| Rule | Details |
|------|---------|
| **Respect dates strictly** | Never leak content before agreed date — trust with dev team depends on it |
| **Brief KOLs under NDA** | If giving early access, require signed NDA |
| **Prepare, don't publish** | Have everything ready; schedule for exact release time |
| **Coordinate with NetEase** | Align on who publishes what, when |

---

## 14.5 Monetization Philosophy

### Sky's Approach to Monetization

Sky is one of the most generous free-to-play games in the market. This is a core brand value, not just a business strategy.

| Principle | Implementation | Marketing Implication |
|-----------|---------------|---------------------|
| **Free core experience** | All realms, spirits, social features are free | Lead with "free to play, no paywall" |
| **Cosmetics only** | No gameplay advantages for paying players | Emphasize beauty and self-expression, not power |
| **Season pass model** | Adventure Pass as primary revenue driver | Position as "the full seasonal experience" |
| **No predatory mechanics** | No gacha, no loot boxes, no energy systems | Differentiate from exploitative competitors |
| **Gift economy** | Players can gift items to others | Market around generosity, not consumption |
| **Respectful pricing** | Fair CN pricing (adjusted from global) | Communicate value; never create FOMO pressure |

### Competitive Positioning
```
MORE AGGRESSIVE                                        MORE GENEROUS
(gacha, energy, P2W)                              (cosmetic-only, gift economy)
    │                                                        │
    ▼                                                        ▼
[Competitors] ──────────────────────────────── [SKY] ◄── Sweet spot
```

---

## 14.6 Revenue Streams

| Stream | Description | % of Revenue (est.) | Marketing Role |
|--------|------------|-------------------|----------------|
| **Adventure Pass (季节通行证)** | Season-long premium content | ~50–60% | Primary marketing focus each season |
| **Candle packs (蜡烛)** | Premium currency purchase | ~20–25% | Subtle value messaging |
| **IAP cosmetics** | Individual premium items | ~10–15% | Showcase and FOMO management |
| **Gift packs** | Special bundles during events | ~5–10% | Event-tied promotion |
| **Merchandise** | Physical products | Small | Brand extension (see Module 18) |
| **Collaborations** | Partner revenue share | Variable | Co-marketing campaigns |

### Season Pass Value Communication

**Don't** list items like a receipt:
> "包含15个新动作、8个新斗篷、3个新发型" (Includes 15 emotes, 8 capes, 3 hairstyles)

**Do** tell a story:
> "这个季节，你将踏上一段关于记忆与重逢的旅程。在云海深处，有人在等着你。" (This season, you'll embark on a journey of memory and reunion. Deep in the clouds, someone is waiting for you.)

---

## 14.7 Pricing Strategy for CN Market

### Price Points

| Item | Global (USD) | CN (¥) | Notes |
|------|-------------|--------|-------|
| **Adventure Pass** | $9.99 | ¥68 | Seasonal; primary monetization |
| **Small candle pack** | $4.99 | ¥30 | Entry-level IAP |
| **Medium candle pack** | $9.99 | ¥68 | Most popular |
| **Large candle pack** | $19.99 | ¥128 | Whales and gift-givers |
| **Special IAP items** | Varies | ¥30–168 | Limited-time cosmetics |

### CN-Specific Pricing Considerations

| Factor | Implication |
|--------|------------|
| **Income levels** | CN prices should feel fair relative to purchasing power |
| **Price sensitivity** | Core audience (students, young professionals) is budget-conscious |
| **Comparison shopping** | Players compare to other games — Sky must feel generous |
| **Gift culture** | Candle gifting is social; bundle pricing should encourage gift purchases |
| **Value perception** | CN players evaluate meticulously — bundles must feel genuinely generous |

### Handling "太贵了" (Too Expensive) Sentiment

| Situation | Response Approach |
|-----------|------------------|
| Community complaints about new pricing | Acknowledge concern; emphasize free content; explain value |
| Comparison to cheaper competitors | Don't compete on price — compete on experience and ethics |
| Backlash after price increase | Transparent communication; grandfather existing purchases if possible |
| Players demanding discounts | Offer value through bundles, not discounts (protects price integrity) |

---

## 14.8 Marketing Monetization Without Compromising Brand

### Cardinal Rules

1. **Never make free players feel excluded** — marketing should celebrate the free experience
2. **Never create artificial urgency** — "limited time" is fine; "BUY NOW BEFORE IT'S GONE" is not
3. **Showcase beauty, not transaction** — show cosmetics in context, not in a shop interface
4. **Let players sell to each other** — UGC showing purchased cosmetics is more effective than ads

### Monetization Messaging Spectrum

| Too Aggressive | Balanced (Target) | Too Passive |
|---------------|-------------------|-------------|
| "限时抢购！最后3天！" | "这个季节的斗篷，在风中真的很美" | Never mentioning paid content exists |
| Countdown timers in every post | Season showcase with cosmetics featured naturally | Only posting free content |
| "错过就没有了！" (Miss it, lose it!) | "你最喜欢这个季节的哪个造型？" | Avoiding all monetization discussion |

### Ethical Monetization Checklist

Before any monetization-related marketing:
- [ ] Does this celebrate the experience, not just the transaction?
- [ ] Would a free player feel welcomed, not excluded?
- [ ] Is the urgency real, or are we manufacturing FOMO?
- [ ] Would tgc's founders be proud of this message?
- [ ] Are we being transparent about what costs money?
- [ ] Does this respect the player's intelligence and budget?
- [ ] Would this pass community scrutiny without backlash?

---

## 14.9 Live Ops Data & Decision Making

### Key Metrics to Monitor

| Metric | Frequency | Action Threshold |
|--------|-----------|-----------------|
| **DAU** | Daily | ±10% vs. expected triggers investigation |
| **Season pass conversion** | Weekly | <X% triggers marketing push |
| **Event participation rate** | Per event | Below benchmark triggers content adjustment |
| **Revenue per day** | Daily | Track trends against season lifecycle |
| **Community sentiment** | Daily | Negative spike triggers response plan |
| **Content engagement** | Per post | Below average triggers creative review |

### Data Signals → Campaign Adjustments

| Signal | Interpretation | Action |
|--------|---------------|--------|
| DAU flat mid-season | Content fatigue or awareness gap | Boost content variety; KOL activation |
| Pass conversion below target | Value not communicated well | Cosmetic showcase content; emotional storytelling |
| Event participation low | Players don't know about it or don't care | Increase visibility; improve incentive communication |
| High engagement, low revenue | Players love it but aren't buying | Check pricing perception; test value messaging |

---

## 14.10 Traveling Spirits & Returning Content

### Marketing Opportunity

When past-season spirits return as Traveling Spirits:

| Marketing Action | Details |
|-----------------|---------|
| **Nostalgia content** | "Remember this spirit? They're back for a limited visit" |
| **New player education** | "If you missed Season X, here's your chance" |
| **Community discussion** | "Which spirit are you most excited to see return?" |
| **Collection encouragement** | Help collectors track what they still need |

---

## 14.11 Monthly Live Ops Calendar Template

```
═══════════════════════════════════════════
  MONTHLY LIVE OPS CALENDAR — [Month]
═══════════════════════════════════════════
Week 1: [Content focus, events, key dates]
  Mon: [Platform posts]
  Wed: [Video content]
  Fri: [Community content]

Week 2: [Content focus, events, key dates]
  ...

Events this month:
  • [Event name] — [Dates] — [Scale]
  • [Event name] — [Dates] — [Scale]

Key dates:
  • Season launch: [Date]
  • Traveling Spirit: [Date]
  • Maintenance: [Date]
═══════════════════════════════════════════
```

---

## Knowledge Check

1. A new season launches in 3 weeks. Build the complete marketing timeline from now through T+2 weeks, including content types, channels, and owners.
2. Mid-season DAU is dropping and season pass conversion is 15% below target. Diagnose and propose three marketing interventions.
3. The community is upset about a ¥128 cosmetic bundle, calling it "太贵了." Using the frameworks in this module, draft your response strategy.
4. Design the event marketing playbook for the next Days of Fortune (CNY) event.
5. A competitor launches aggressive gacha monetization and their revenue spikes. HQ asks if Sky should adopt similar tactics. Make your case.

---

## Related Modules
- [Module 02: Target Audience & Player Lifecycle](02-target-audience-lifecycle.md) — Player journey and retention
- [Module 10: Campaign Planning & PM](10-campaign-planning-pm.md) — Campaign execution
- [Module 12: Budget Management](12-budget-management.md) — ROI analysis
- [Module 15: Beta Testing & Launch](15-beta-testing-launch.md) — New game launch ops

---

[← Module 13: Game Publishing](13-game-publishing.md) | [Next: Module 15 — Beta Testing & Launch →](15-beta-testing-launch.md) | [Main Guide](../README.md)
