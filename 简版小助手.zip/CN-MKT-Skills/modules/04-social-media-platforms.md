# Module 04: CN Social Media Platforms & Content Strategy

> Each platform is a different stage with a different audience. Master the nuances — don't copy-paste across platforms.

---

## 4.1 Platform Landscape Overview

| Platform | MAU (approx.) | Sky Relevance | Primary Use |
|----------|---------------|---------------|-------------|
| **Bilibili (B站)** | 340M+ | ★★★★★ | Long-form video, community, fan culture |
| **Douyin (抖音)** | 750M+ | ★★★★★ | Short-form video, viral reach, UA |
| **Xiaohongshu (小红书)** | 300M+ | ★★★★★ | Visual discovery, lifestyle, aesthetic content |
| **WeChat (微信)** | 1.3B+ | ★★★★☆ | Private community, articles, mini-programs |
| **Weibo (微博)** | 580M+ | ★★★☆☆ | News, announcements, trending topics, PR |
| **QQ** | 550M+ | ★★★☆☆ | Youth community, group chat, fandom |
| **TapTap** | 50M+ | ★★★★☆ | Game discovery, reviews, community |
| **Kuaishou (快手)** | 370M+ | ★★☆☆☆ | Short video (Tier 3–5 cities), growth opportunity |

---

## 4.2 Bilibili (B站) — The Community Heart

### Why Bilibili Matters for Sky
- Sky's core audience (18–24, aesthetic-oriented, ACG-adjacent) is Bilibili's core audience
- Fan creation (二创) culture thrives here — Sky has one of the most active fan creator communities
- Long-form content allows for emotional storytelling that matches Sky's brand

### Content Strategy

| Content Type | Format | Frequency | Goal |
|-------------|--------|-----------|------|
| **Season trailers/PVs** | Official video (1–3 min) | Per season launch | Awareness, hype |
| **Behind-the-scenes** | Documentary-style (5–15 min) | Monthly | Deepen emotional connection |
| **Community spotlights** | Compilations, repost with credit | Weekly | Reward creators, build loyalty |
| **Gameplay guides** | Tutorial videos (3–8 min) | Per season/event | Retention, accessibility |
| **Live streams** | Interactive streams (1–2 hrs) | Bi-weekly to monthly | Community engagement |
| **Music content** | OST releases, piano covers, collabs | Ongoing | Leverage Sky's musical identity |

### Bilibili-Specific Tactics
- **弹幕 (Danmaku/Bullet comments)**: Design content that invites viewer commentary — ask questions, create "danmaku-worthy" moments
- **动态 (Moments/Posts)**: Use for daily community interaction — screenshots, polls, casual updates
- **专栏 (Articles)**: Long-form lore analysis, dev diaries
- **充电 (Tipping)**: Support fan creators through official engagement and cross-promotion
- **合作 (Collaborations)**: Partner with Bilibili UP主 (creators) across gaming, art, and music categories

### Key Metrics
- Video views, 三连 (like + coin + collect), danmaku density, follower growth, fan creator output volume

---

## 4.3 Douyin (抖音) — The Reach Engine

### Why Douyin Matters for Sky
- Largest short-video platform in China — unmatched reach potential
- Algorithm-driven discovery means Sky content can reach non-gamers
- Visual beauty of Sky translates perfectly to short-form video

### Content Strategy

| Content Type | Format | Frequency | Goal |
|-------------|--------|-----------|------|
| **Beauty shots** | 15–30s scenic gameplay clips | 3–5x/week | Awareness, aesthetic appeal |
| **Emotional moments** | 30–60s player stories, friendship moments | 2–3x/week | Emotional connection |
| **Trending audio** | Sky footage synced to trending music/sounds | As trends emerge | Viral reach |
| **Quick tips** | 15–30s gameplay tips | 2–3x/week | Utility, accessibility |
| **KOL content** | Sponsored/gifted creator videos | Per campaign | Reach, credibility |
| **Challenge/hashtag campaigns** | User participation format | Per major event | Virality, UGC |

### Douyin-Specific Tactics
- **Hook in first 1–3 seconds**: Open with visually stunning shot or emotional question — "你见过最美的日落吗？" (Have you seen the most beautiful sunset?)
- **Trending audio/BGM**: Monitor 抖音热歌 and adapt Sky content to trending sounds
- **Hashtag strategy**: Use mix of branded (#光遇 #sky光遇), category (#治愈系游戏 #手游推荐), and trending tags
- **Comment engagement**: Reply to comments, pin emotional comments, create "comment bait"
- **Douyin search optimization**: Optimize titles and hashtags for search intent (e.g., "好看的手游推荐")
- **DOU+ (paid boost)**: Use to amplify top-performing organic content, not as primary distribution

### Key Metrics
- Views, completion rate, shares, comments, follower conversion, hashtag challenge participation

---

## 4.4 Xiaohongshu (小红书) — The Aesthetic Magnet

### Why Xiaohongshu Matters for Sky
- Platform DNA is aesthetic discovery — perfectly aligned with Sky's visual identity
- Female-skewed audience (70%+) matches Sky's demographic
- "Lifestyle recommendation" format is ideal for game discovery by non-gamers
- High intent: users actively search for recommendations

### Content Strategy

| Content Type | Format | Frequency | Goal |
|-------------|--------|-----------|------|
| **Screenshot collections** | Image carousel (6–9 images) + text | 3–5x/week | Aesthetic appeal, discovery |
| **"Healing game recommendation"** | Lifestyle post format | 1–2x/week | New player acquisition |
| **Outfit/cosmetic showcases** | Styled character images | Per new cosmetics | Drive seasonal interest |
| **Couple/friendship content** | Shared moments, matching outfits | Weekly | Social appeal |
| **ASMR/ambiance clips** | Short video with natural sounds | 1–2x/week | Relaxation positioning |
| **Tutorial/guide notes** | Step-by-step image guides | Per event/season | Utility, search SEO |

### Xiaohongshu-Specific Tactics
- **SEO is critical**: Xiaohongshu is a search-driven platform — research keywords:
  - "治愈系游戏推荐" (healing game recommendation)
  - "好看的手游" (beautiful mobile game)
  - "情侣游戏" (couple game)
  - "光遇攻略" (Sky guide)
- **Cover image is everything**: First image must be visually stunning — use 3:4 aspect ratio
- **Note length**: 300–800 characters is the sweet spot — authentic, personal tone
- **Tag strategy**: Include location tags, category tags, and Sky-specific tags
- **Collection boards**: Create curated collections (e.g., "Sky's Most Beautiful Moments")
- **KOC (Key Opinion Consumer)**: Xiaohongshu favors authentic user voices over polished brand content — seed product to real players

### Key Metrics
- Note impressions, saves (收藏), shares, comments, search ranking for target keywords, follower growth

---

## 4.5 WeChat (微信) — The Private Core

### Why WeChat Matters for Sky
- Universal reach — nearly every CN player uses WeChat
- Private traffic (私域流量) allows direct relationship with community
- Articles (公众号) for long-form storytelling
- Mini-programs for utility and engagement
- Moments (朋友圈) for peer-to-peer sharing

### Content Strategy

| Content Type | Format | Frequency | Goal |
|-------------|--------|-----------|------|
| **公众号 articles** | Long-form (800–2000 words) | 2–4x/month | Deep storytelling, announcements |
| **Season announcements** | Rich-media article | Per season | Core information delivery |
| **Community group management** | WeChat groups | Ongoing | Loyalty, feedback, word-of-mouth |
| **Mini-program** | Interactive tools (guides, events) | Per campaign | Engagement, utility |
| **视频号 (Channels)** | Short video (overlaps with Douyin strategy) | 2–3x/week | Reach, ecosystem integration |

### WeChat-Specific Tactics
- **公众号 article design**: Use strong visuals, short paragraphs, emotional pacing — CN readers skim
- **Private traffic strategy**: Build and maintain WeChat groups for core fans, beta testers, creators
- **H5 campaigns**: Interactive web experiences for major events (shareable via WeChat)
- **Template messages**: For event reminders and seasonal launches (requires mini-program integration)
- **视频号直播**: Use for Q&A, behind-the-scenes, and community events

### Key Metrics
- Article read count, open rate, share rate, WoW growth, group activity level, mini-program DAU

---

## 4.6 Weibo (微博) — The Public Square

### Why Weibo Matters for Sky
- Best platform for **trending topics** (热搜) and public visibility
- Essential for official announcements, PR, and crisis communication
- Fan interaction through 超话 (super topics) and community features

### Content Strategy

| Content Type | Format | Frequency | Goal |
|-------------|--------|-----------|------|
| **Official announcements** | Text + image/video | As needed | Information delivery |
| **Trending topic campaigns** | Hashtag + activity | Per major event | Broad awareness |
| **Interactive posts** | Polls, retweet draws, Q&A | 2–3x/week | Engagement |
| **Real-time reactions** | Event coverage, live updates | During events | Timeliness |
| **Fan repost & engagement** | Repost fan content with credit | Daily | Community goodwill |

### Weibo-Specific Tactics
- **热搜 (Hot Search) strategy**: Plan campaigns that can trend — requires volume of engagement in short timeframe
- **超话 (Super Topic)**: Maintain active Sky 超话 community; encourage daily check-ins
- **抽奖 (Lucky draw)**: Effective for driving retweets and engagement spikes
- **KOL seeding**: Weibo KOLs for broad reach announcements
- **Crisis monitoring**: Weibo is where backlash goes public first — monitor constantly

### Key Metrics
- Post impressions, repost count, comment count, trending topic ranking, 超话 activity level

---

## 4.7 TapTap — The Gamer Hub

### Why TapTap Matters for Sky
- Dedicated gaming platform — high-intent audience
- Reviews directly impact game perception and downloads
- Community features allow direct player feedback
- No app store commission model attracts engaged users

### Strategy
- Maintain active official forum presence
- Respond to player reviews (especially negative ones — show empathy)
- Post development updates and patch notes
- Run TapTap-exclusive events or rewards
- Monitor ratings and address common complaints

---

## 4.8 Cross-Platform Content Calendar Framework

### Weekly Content Rhythm

| Day | Bilibili | Douyin | Xiaohongshu | WeChat | Weibo |
|-----|----------|--------|-------------|--------|-------|
| **Mon** | 动态: Weekly mood | Beauty shot | Screenshot carousel | — | Community repost |
| **Tue** | — | Quick tip video | Guide note | — | Interactive post |
| **Wed** | Video upload | Trending audio | Couple/friend content | 公众号 article | Announcement |
| **Thu** | 动态: Community spotlight | Emotional moment clip | Cosmetic showcase | — | Fan repost |
| **Fri** | — | Beauty shot | Healing recommendation | — | Interactive post |
| **Sat** | Live stream or premiere | Challenge/trend | Screenshot carousel | — | Event coverage |
| **Sun** | — | Weekend special | ASMR/ambiance clip | — | Casual engagement |

### Content Repurposing Matrix
| Source Content | → Bilibili | → Douyin | → Xiaohongshu | → WeChat | → Weibo |
|---------------|-----------|---------|--------------|---------|--------|
| **Season trailer** | Full video | 15–30s cut | Key frames + text | Article embed | Announcement + link |
| **Behind-the-scenes** | Full documentary | Highlights cut | BTS photos | Article | Teaser clip |
| **Fan art showcase** | Compilation video | Quick slideshow | Image carousel | Article feature | Image + credit |
| **Gameplay guide** | Full tutorial | Quick tips series | Step-by-step images | Mini-program | Quick tips text |

---

## 4.9 Platform Account Management Best Practices

### Unified but Platform-Native
- **Same brand identity** across all platforms (avatar, cover, bio tone)
- **Different content execution** — never post identical content across platforms
- **Platform-specific CTAs** — "三连" on Bilibili, "收藏" on Xiaohongshu, "转发抽奖" on Weibo

### Response & Engagement SOP
1. **Monitor** all platforms daily (assign platform owners)
2. **Respond** to top comments within 2 hours during business hours
3. **Escalate** negative sentiment that gains traction
4. **Archive** standout fan content for reposting/featuring
5. **Report** weekly platform performance metrics to team

---

## Knowledge Check

1. You have a beautiful 2-minute season trailer. How would you adapt it for Bilibili, Douyin, Xiaohongshu, and Weibo?
2. What makes Xiaohongshu SEO different from traditional search engine SEO?
3. Your Douyin video gets 50K views but only 200 likes. What might be wrong?
4. Describe a WeChat private traffic strategy for Sky's most loyal CN fans.
5. A negative review is trending on TapTap. What's your response playbook?

---

[← Module 03: Competitor Analysis](03-competitor-analysis.md) | [Next: Module 05 — User Acquisition & App Store Distribution →](05-user-acquisition-distribution.md) | [Main Guide](../README.md)
