# Module 18: Events, Merchandising & IP Collaboration

> Taking Sky beyond the screen — through events that build community and products that let players carry the magic into their daily lives.

---

## 18.1 Event Types for Sky

| Event Type | Examples | Scale | Frequency |
|-----------|---------|-------|-----------|
| **Online livestream** | Season preview, developer Q&A, anniversary | Medium-Large | Monthly or per season |
| **Social media event** | Hashtag challenge, fan art contest | Small-Medium | Monthly |
| **Community creation** | Music cover contest, screenshot competition | Small | Bi-monthly |
| **Offline meetup** | Player gathering, Sky café, fan meetup | Medium | Quarterly |
| **Exhibition** | ChinaJoy booth, art gallery installation | Large | 1–2x per year |
| **Partnership event** | Brand collab activation, museum tie-in | Medium-Large | Quarterly |
| **Hybrid** | Offline event with online stream/participation | Large | 2–4x per year |

---

## 18.2 Online Event Planning

### Livestream Types

| Format | Duration | Platform | Best For |
|--------|----------|----------|----------|
| **Season preview** | 30–60 min | Bilibili, Douyin | Building anticipation |
| **Developer Q&A** | 45–60 min | Bilibili | Deepening trust |
| **Community showcase** | 30 min | Bilibili | Celebrating creators |
| **Anniversary celebration** | 60–90 min | Bilibili + Douyin | Major milestone |
| **Live gameplay** | 30–60 min | Bilibili, Douyin | Engagement, fun |

### Livestream Production Checklist
- [ ] Script/run-of-show finalized and rehearsed
- [ ] Technical test completed (audio, video, internet backup)
- [ ] Chat moderators briefed and ready
- [ ] Backup plan if technical issues arise
- [ ] Post-stream content plan (highlights, clips)
- [ ] Real-time metrics monitoring setup
- [ ] Community FAQ prepared for chat

### Hashtag Challenge Framework

```
CONCEPT → RULES → LAUNCH → AMPLIFY → JUDGE → REWARD
   │         │        │        │         │        │
  Theme   Clear,   Official  Repost    Fair    Prizes +
  tied    easy     launch    best      judging  official
  to Sky  entry    post     entries   process  recognition
```

| Element | Details |
|---------|---------|
| **Theme** | Tied to Sky's values or current season |
| **Entry barrier** | Low — anyone can participate (screenshot, short video, drawing) |
| **Hashtag** | Memorable, unique: #光遇[主题] |
| **Duration** | 7–14 days |
| **Prizes** | In-game items, merch, official features; NOT cash-heavy |
| **Amplification** | Official account reposts best entries daily |

---

## 18.3 Offline Event Planning

### Player Meetup Framework

| Element | Details |
|---------|---------|
| **Venue** | Café, park, gallery — aesthetic-aligned; 30–80 people |
| **Activities** | Sky music performances, art exchange, cosplay, friendship ceremonies |
| **Exclusives** | Limited merch, in-game codes, photo opportunities |
| **Documentation** | Professional photographer; live social coverage |
| **Safety** | Venue insurance, crowd management, medical kit |

### Meetup Activity Ideas

| Activity | Duration | Purpose |
|----------|----------|---------|
| **Sky music ensemble** | 20 min | Players perform Sky songs together |
| **Art wall** | Ongoing | Community art display and live drawing |
| **Screenshot gallery** | Ongoing | Best in-game photography printed large |
| **Candle lighting ceremony** | 10 min | Symbolic moment mirroring in-game |
| **Friendship bracelet exchange** | 15 min | Physical version of in-game connection |
| **Developer video message** | 5 min | Special message from tgc team |
| **Cosplay showcase** | 15 min | Players dressed as Sky characters |
| **Lucky draw** | 10 min | Prizes: merch, in-game items |
| **Group photo** | 5 min | Everyone together — the "family photo" |

### Meetup Planning Timeline

| When | Tasks |
|------|-------|
| **T-6 weeks** | Venue selection, budget approval, concept |
| **T-4 weeks** | Registration opens, marketing begins, vendor contracts |
| **T-2 weeks** | Materials production, activity finalization, staff briefing |
| **T-1 week** | Venue walkthrough, tech check, final confirmations |
| **T-day** | Setup, event execution, documentation |
| **T+1 week** | Recap content, thank-you posts, 复盘 |

### Exhibition Concepts

| Concept | Description |
|---------|-------------|
| **Cloud Gallery** | Large-format prints of Sky's most beautiful scenes |
| **Sky Music Room** | Interactive space where visitors play Sky instruments |
| **Realm Walk** | Walk-through experience of different Sky realms |
| **Letters of Light** | Wall where visitors write messages (like in-game) |
| **Memory Candle** | Physical candle-lighting installation |

---

## 18.4 Event Budget Framework

| Category | Meetup (%) | Exhibition (%) | Online (%) |
|----------|-----------|---------------|------------|
| **Venue** | 25% | 30% | 5% (platform fees) |
| **Production** | 20% | 30% | 30% |
| **Materials / merch** | 15% | 15% | 10% (prizes) |
| **Marketing** | 15% | 10% | 25% |
| **Staff / talent** | 10% | 10% | 20% |
| **Contingency** | 15% | 5% | 10% |

---

## 18.5 Event Risk Management

| Risk | Probability | Impact | Mitigation |
|------|-----------|--------|-----------|
| **Low attendance** | Medium | Medium | Pre-registration; social proof; incentives |
| **Technical failure** (livestream) | Medium | High | Backup equipment; rehearsal; fallback plan |
| **Weather** (outdoor) | Medium | High | Indoor backup venue; rain date |
| **Crowd safety** | Low | Very High | Capacity limits; security; medical prep |
| **Negative sentiment** | Low | High | Community team prepared; response templates |
| **Venue cancellation** | Low | Very High | Contract terms; backup venue identified |

---

## 18.6 Event Measurement

### KPIs by Event Type

| Event Type | Primary KPI | Secondary KPIs |
|-----------|------------|---------------|
| **Livestream** | Peak concurrent viewers | Total views, chat engagement, clip shares |
| **Hashtag challenge** | Total entries | Hashtag impressions, new followers, UGC quality |
| **Meetup** | Attendance vs. registration | NPS score, social content generated, sentiment |
| **Exhibition** | Foot traffic | Media coverage, social mentions, dwell time |

### Post-Event Report Template
```
═════════════════════════════════
  EVENT REPORT — [Name]
  Date: [Date]  Location: [Venue]
═════════════════════════════════
OVERVIEW: [1 paragraph summary]

ATTENDANCE: [Target] vs. [Actual]

KPIs:
  [Metric 1]: [Target] → [Actual]
  [Metric 2]: [Target] → [Actual]

CONTENT OUTPUT:
  Photos: [Count]
  Videos: [Count]
  Social posts generated: [Count]

TOP 3 WINS: [What worked]
TOP 3 LEARNINGS: [What to improve]

ACTION ITEMS:
  □ [Action] — [Owner] — [Due]
═════════════════════════════════
```

---

## 18.7 Why Merchandising Matters

Sky has natural merchandising appeal — its characters, cosmetics, and visual identity are beloved and recognizable.

| Value | How Merch Delivers |
|-------|-------------------|
| **Brand extension** | Players carry Sky into daily life |
| **Revenue diversification** | Beyond in-game IAP |
| **Community bonding** | Merch as identity signal among fans |
| **Marketing tool** | Products generate UGC (unboxing, photos) |
| **Cultural reach** | Reaches non-players through beautiful products |
| **Event enhancement** | Exclusive merch drives event attendance |

---

## 18.8 Product Categories

| Category | Examples | Price Range (¥) | Primary Audience |
|----------|---------|----------------|-----------------|
| **Plushies** | Character plushies, spirit companions | ¥59–199 | Core fans, gift buyers |
| **Apparel** | T-shirts, hoodies, scarves | ¥99–399 | Active players, fashion-conscious |
| **Accessories** | Phone cases, keychains, bags | ¥29–149 | Broad audience |
| **Stationery** | Notebooks, pens, stickers | ¥19–89 | Students |
| **Home goods** | Candles, mugs, blankets | ¥49–299 | Lifestyle audience |
| **Blind boxes** | Collectible figurines, random character | ¥49–79 each | Collectors (blind box is huge in CN) |
| **Art prints** | Official artwork, fan art collabs | ¥79–299 | Art lovers |
| **Music** | OST vinyl, music boxes | ¥149–499 | Music lovers, collectors |
| **Collaboration products** | Co-branded items with partner brands | Varies | Extended audiences |

### CN Merchandising Culture

| Insight | Implication |
|---------|------------|
| **Blind box culture (盲盒)** | CN loves collectible blind boxes — ideal for Sky's many characters/spirits |
| **Pre-order model** | CN consumers are comfortable pre-ordering; use to gauge demand |
| **Unboxing content** | Product unboxing drives XHS/Bilibili content — design for shareability |
| **Quality expectations** | CN consumers share quality issues virally — invest in QC |
| **Gift-giving** | Design packaging for gift occasions (holidays, birthdays) |

---

## 18.9 IP Collaboration Framework

### Collaboration Types

| Type | Description | Example |
|------|-------------|---------|
| **Co-branded product** | Joint product with partner brand | Sky × café: themed drinks and desserts |
| **Themed space** | Physical space with Sky aesthetic | Sky pop-up lounge in a shopping mall |
| **Content collaboration** | Joint content creation | Sky × orchestra: concert of Sky music |
| **Cross-game** | Collaboration with another game | Sky × Journey: shared aesthetic celebration |
| **Cultural institution** | Museum, gallery, or cultural org | Sky × art museum: interactive exhibition |
| **Artist collaboration** | Creator partnership | Sky × illustrator: limited art series |

### Partner Evaluation Matrix

| Criterion | Weight | Question to Ask |
|-----------|--------|----------------|
| **Brand alignment** | ★★★★★ | Does this partner share Sky's values of beauty and connection? |
| **Audience overlap** | ★★★★☆ | Will their audience find genuine value in Sky? |
| **Creative potential** | ★★★★☆ | Can we create something together that neither could alone? |
| **Execution capability** | ★★★☆☆ | Can they deliver on time and at quality? |
| **CN market presence** | ★★★☆☆ | Do they have meaningful reach in China? |
| **Budget fit** | ★★★☆☆ | Is the investment proportional to expected return? |
| **Long-term potential** | ★★☆☆☆ | Could this become an ongoing partnership? |

### Ideal Partner Categories

| Category | Why It Fits Sky | Example Concept |
|----------|----------------|----------------|
| **Art museums** | Shared appreciation of beauty | Sky × museum: "Virtual Realm" exhibition |
| **Orchestras** | Sky's musical identity | Sky concert with live orchestra |
| **Tea/café brands** | Peaceful, aesthetic experience | Sky-themed café with realm-inspired drinks |
| **Stationery brands** | Student audience overlap | Sky notebook collection |
| **Fashion/accessories** | Self-expression alignment | Sky-inspired capsule collection |
| **Travel platforms** | "Virtual travel" narrative | "Travel Through Sky's Realms" campaign |

---

## 18.10 Collaboration Planning Process

### 5-Phase Workflow

| Phase | Key Steps | Owner |
|-------|----------|-------|
| **1. Identification** | Research, outreach, initial pitch | Marketing Lead |
| **2. Negotiation** | Scope, budget, revenue share, timeline, contract | Marketing Lead + Legal |
| **3. Production** | Product/content development, QA, approval rounds | Both parties |
| **4. Launch** | Marketing campaign, distribution, community activation | Marketing |
| **5. Review** | Sales data, engagement, 复盘, relationship assessment | Marketing Lead |

### Product Development Principles

| Principle | Application |
|-----------|-------------|
| **True to Sky's aesthetic** | Colors, shapes, and feeling match the game |
| **Quality over quantity** | Fewer, higher-quality items beat a flood of mediocre ones |
| **Functional beauty** | Products should be useful AND beautiful |
| **Collectibility** | Design series that encourage collecting over time |
| **Shareability** | Packaging and design that photograph well for social content |
| **Accessibility** | Offer items at multiple price points |

---

## 18.11 Merch Marketing Strategy

### Content Types for Product Launches

| Content Type | Platform | Timing |
|-------------|----------|--------|
| **Teaser / silhouette** | All | T-7 days |
| **Product reveal** | All | T-3 days |
| **KOL unboxing** | Bilibili, XHS | T-day to T+3 |
| **Behind-the-design** | Bilibili, WeChat | T+1 week |
| **Community showcase** (fan photos) | XHS, Weibo | T+2 weeks |
| **Post-purchase UGC** | All | Ongoing |

### Where to Sell in CN

| Channel | Commission | Best For |
|---------|-----------|---------|
| **Taobao/Tmall** | 2–5% + platform fees | Largest reach |
| **JD.com** | 3–8% | Trusted for quality |
| **Xiaohongshu** | 5% + fees | Aesthetic/lifestyle products |
| **WeChat mini-program** | Low (owned) | Direct fan relationship |
| **Bilibili merch zone** | Varies | Targeted fan community |
| **Physical events** | None | Exclusivity, experience |

---

## 18.12 Measuring Success

### Event Metrics

| Metric | Target |
|--------|--------|
| **Attendance** | ≥80% of registration |
| **NPS** | ≥70 |
| **Social content generated** | 100+ posts per event |
| **Media coverage** | 3+ outlets per major event |

### Merch Metrics

| Metric | Definition | Target |
|--------|-----------|--------|
| **Sales volume** | Units sold per product | Sell-out within campaign period |
| **Sell-through rate** | Units sold / units produced | >70% |
| **Social buzz** | Mentions, UGC, hashtag volume | Trending within 24h |
| **Customer satisfaction** | Post-purchase survey | ≥4.5/5 |
| **Partnership ROI** | Revenue + brand value / investment | >2x |

---

## Knowledge Check

1. Design a complete hybrid event for Sky's next anniversary — online livestream + offline meetup. Include concept, timeline, activities, and budget allocation.
2. A blind box series of Sky spirits is launching. Plan the marketing campaign from teaser to post-purchase UGC.
3. A famous tea brand approaches Sky for a collaboration. Using the evaluation matrix, assess the fit and propose a concept.
4. Your offline meetup gets 200 registrations but only 80 attend. What went wrong, and how do you fix it for next time?
5. Design a merchandise line for a new Sky season — 5 products, pricing, target audience, and sales channels.

---

## Related Modules
- [Module 09: Community Building](09-community-building.md) — Fan engagement and creator ecosystem
- [Module 14: Live Ops & Monetization](14-live-ops-monetization.md) — Seasonal event operations
- [Module 17: Agency & Partner Collaboration](17-agency-partner-collab.md) — Working with production partners

---

[← Module 17: Agency & Partner Collaboration](17-agency-partner-collab.md) | [Next: Module 19 — Cross-Border Teamwork →](19-cross-border-teamwork.md) | [Main Guide](../README.md)
