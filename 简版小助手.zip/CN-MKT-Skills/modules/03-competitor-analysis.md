# Module 03: Competitor Analysis

> Know the landscape. Sky doesn't compete on features — it competes on feeling. But understanding competitors helps us position and differentiate.

---

## 3.1 Competitive Landscape Overview

Sky occupies a **unique niche** in the CN gaming market: a non-violent, socially-driven, aesthetically rich mobile game. Its competitors fall into several categories:

```
                        High Social Focus
                              ▲
                              │
              Sky ★           │        Genshin Impact
           Eggy Party         │        Harry Potter: Magic Awakened
         Party Animals        │        Honor of Kings (social mode)
                              │
  Simple ◄────────────────────┼────────────────────► Complex
  Gameplay                    │                      Gameplay
                              │
          Monument Valley     │        Arknights
          Alto's Odyssey      │        Punishing: Gray Raven
          Stardew Valley      │        Wuthering Waves
                              │
                              ▼
                        Low Social Focus
```

---

## 3.2 Direct Competitors

### 3.2.1 Genshin Impact (原神) — miHoYo/HoYoverse

| Dimension | Genshin Impact | Sky | Implication |
|-----------|---------------|-----|-------------|
| **Genre** | Open-world action RPG | Social adventure | Sky is non-combat; different emotional offer |
| **Art style** | Anime-influenced, detailed | Painterly, silhouette-based | Sky's art is more abstract and poetic |
| **Audience overlap** | Significant — young, aesthetic-focused | Similar demographics | Compete for time/attention, not directly for genre |
| **Monetization** | Gacha (aggressive) | Cosmetic-only (gentle) | Sky can position as the ethical alternative |
| **Community** | Massive, content-heavy, some toxicity | Smaller, warm, creative | Sky's community is a differentiator |
| **Content cadence** | Major updates every 6 weeks | Seasons every ~10 weeks | Genshin sets high content expectations |

**Key Lessons from Genshin**:
- Masterful at social media content strategy across Bilibili and Douyin
- KOL ecosystem is deep and well-incentivized
- Their community events (art contests, cosplay, etc.) drive massive engagement
- However: their gacha model generates backlash — Sky can differentiate on fairness

### 3.2.2 Eggy Party (蛋仔派对) — NetEase

| Dimension | Eggy Party | Sky | Implication |
|-----------|-----------|-----|-------------|
| **Genre** | Social party/mini-games | Social adventure | Both are social-first, but very different tone |
| **Audience** | Young, casual, mass-market | Young, aesthetic, emotional | Eggy is broader; Sky is deeper |
| **Monetization** | Cosmetics + UGC economy | Cosmetics | Eggy's UGC model drives engagement loops |
| **Virality** | Extremely high (meme-driven) | Moderate (beauty-driven) | Sky can learn from Eggy's viral mechanics |

**Key Lessons from Eggy Party**:
- Demonstrates that social/casual can dominate CN market
- UGC (user-generated content) maps are a powerful retention tool
- Meme-ability and shareable moments drive Douyin virality
- Sky's emotional depth is the counter-position to Eggy's playfulness

### 3.2.3 Harry Potter: Magic Awakened (哈利波特：魔法觉醒) — NetEase

| Dimension | HP: Magic Awakened | Sky | Implication |
|-----------|-------------------|-----|-------------|
| **IP Power** | Global mega-IP | Original IP | Sky relies on game quality and community, not franchise |
| **Social features** | Strong (school life simulation) | Strong (organic exploration) | Both succeed through social bonding |
| **CN Performance** | Strong launch, retention challenges | Steady long-term engagement | Sky's organic retention is a strength |

---

## 3.3 Indirect Competitors (Attention Competitors)

These don't compete on gameplay but fight for the same audience's **time and emotional energy**:

### 3.3.1 Xiaohongshu / Douyin Content Ecosystem
- The biggest competitor for Sky's audience isn't another game — it's **scrolling content feeds**
- Young women in Tier 1–2 cities spend 2+ hours daily on Xiaohongshu/Douyin
- Sky must **be part of** these feeds rather than competing against them
- Strategy: Make Sky content native to these platforms (aesthetic screenshots, healing videos, ASMR gameplay)

### 3.3.2 Other "Healing" (治愈系) Experiences
- **Meditation apps** (潮汐 Tide, 小睡眠)
- **Lo-fi/ambient content** on Bilibili
- **Cozy games** (Stardew Valley, Animal Crossing, A Short Hike)
- Positioning: Sky is the **interactive healing experience** — more engaging than passive content, more peaceful than other games

### 3.3.3 Anime/ACG Content
- Sky's audience overlaps significantly with ACG (Anime, Comic, Game) fandom
- Bilibili is a shared platform — Sky competes for attention alongside anime, Vtubers, and fan communities
- Strategy: Collaborate with ACG creators; position Sky as "playable art"

---

## 3.4 Competitive Positioning Framework

### Sky's Unique Position: "The Third Place"

Sky occupies a rare position as a **"third place"** — neither purely a game nor purely social media, but a **shared emotional space**:

| Competitive Axis | Sky's Position |
|------------------|----------------|
| **Competition vs. Cooperation** | Fully cooperative — no PvP, no rankings |
| **Complexity vs. Accessibility** | Radically accessible — anyone can play |
| **Transaction vs. Generosity** | Generosity-first monetization |
| **Content consumption vs. creation** | Players are active creators of their experience |
| **Noise vs. Calm** | A quiet, intentional space in a noisy digital world |

### Positioning Statement (Internal)
> For young Chinese people seeking meaningful connection and beautiful experiences in a digital world, Sky: Children of the Light is the social adventure game that offers genuine emotional warmth and artistic wonder — unlike competitive games that stress, or social media that isolates, Sky brings people together through shared exploration, music, and light.

---

## 3.5 Competitive Intelligence Framework

### What to Monitor

| Intelligence Type | Sources | Frequency |
|-------------------|---------|-----------|
| **Feature launches** | App stores, official accounts, gaming media (触乐, 游研社, GameLook) | Weekly |
| **Marketing campaigns** | Competitor social accounts, ad libraries (巨量引擎) | Weekly |
| **Community sentiment** | Bilibili, NGA, TapTap reviews | Daily |
| **Download/revenue rankings** | Sensor Tower, 七麦数据 (Qimai) | Weekly |
| **KOL partnerships** | Bilibili, Douyin, Xiaohongshu | Weekly |
| **Pricing/monetization changes** | App stores, community reports | As they happen |

### Competitive Response Matrix
| Competitor Action | Sky Response |
|-------------------|-------------|
| Major content update drives conversation | Amplify Sky's unique angle — don't react, differentiate |
| Competitor runs aggressive discount campaign | Emphasize Sky's generous base model — don't match discounts |
| Competitor faces community backlash | Never pile on; focus on Sky's own positive narrative |
| Competitor launches similar social feature | Highlight that Sky pioneered social warmth in gaming |
| Competitor collaborates with a KOL Sky is targeting | Diversify KOL strategy; find unique voices |

---

## 3.6 SWOT Analysis — Sky in CN Market

### Strengths
- Unique emotional positioning — no true direct competitor in "healing social adventure"
- Jenova Chen's reputation and cultural connection to China
- Extremely loyal and creative community
- Beautiful, highly shareable visual identity
- Non-violent, brand-safe — attractive to diverse partnerships
- Long tail of organic word-of-mouth

### Weaknesses
- Smaller content volume compared to competitors like Genshin
- Monetization is conservative — slower revenue growth
- CN version relies on NetEase partnership — less direct control
- Niche appeal limits mass-market scale
- Game complexity (Eden, seasonal mechanics) can confuse new players

### Opportunities
- "Healing games" (治愈系游戏) trend is growing in CN
- Cross-platform expansion (PS, Switch, Steam) opens new audiences
- Music/art crossover collaborations (museums, orchestras, artists)
- Growing CN interest in "emotional wellness" and "mental health" content
- UGC tools could unlock community creativity
- Geographic expansion into lower-tier cities

### Threats
- Competitor games improving social features (Genshin co-op, Eggy Party social)
- Content fatigue if seasonal model becomes predictable
- Regulatory changes in CN gaming (playtime limits, content restrictions)
- Economic slowdown reducing discretionary spending on games
- Community fragmentation across too many platforms

---

## Related Modules

- [Module 04: CN Social Media Platforms](04-social-media-platforms.md) — Platform strategies to execute against competitors
- [Module 05: User Acquisition](05-user-acquisition.md) — Winning users in a competitive landscape
- [Module 13: Data Analytics](13-data-analytics.md) — Measuring competitive performance
- [Module 25: Monetization & Pricing](25-monetization.md) — Sky's ethical monetization as a competitive differentiator

---

## Knowledge Check

1. Name Sky's top three direct competitors in the CN market. For each, explain Sky's differentiation AND identify one tactic Sky could learn from them.
2. Why is Xiaohongshu/Douyin content scrolling considered an "indirect competitor" and how should Sky respond? Propose a specific content strategy.
3. Using the SWOT analysis, identify one opportunity-strength pairing that could drive a campaign idea. Outline the campaign concept in 3 sentences.
4. A competitor just launched a viral Douyin campaign. Your manager asks "should we do something similar?" Walk through your evaluation framework and recommendation.
5. Draft a one-paragraph competitive positioning statement you could share with an external partner who is unfamiliar with gaming.

---

[← Module 02: Target Audience & Player Lifecycle](02-target-audience-lifecycle.md) | [Next: Module 04 — CN Social Media Platforms →](04-social-media-platforms.md) | [Main Guide](../README.md)
