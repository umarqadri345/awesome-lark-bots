# Module 20: Pitch & Presentation Skills

> Whether you're pitching a campaign idea to HQ, a partnership to a brand, or Sky to a KOL — your ability to tell a compelling story is a career-defining skill.

---

## 12.1 Types of Pitches You'll Give

| Pitch Type | Audience | Goal | Duration |
|-----------|---------|------|----------|
| **Campaign pitch** | HQ leadership | Get approval and budget for a CN campaign idea | 10–15 min |
| **Partnership pitch** | External brands, platforms, cultural institutions | Convince them to collaborate with Sky | 15–30 min |
| **KOL pitch** | Content creators | Get them excited to create Sky content | 5–10 min |
| **Platform pitch** | Bilibili, Douyin, Xiaohongshu business teams | Secure featured placement or promotional support | 15–20 min |
| **Internal proposal** | CN team or HQ peers | Propose a process change, new tool, or strategy shift | 5–10 min |
| **Progress presentation** | HQ leadership, NetEase | Share results, learnings, and next steps | 15–20 min |

---

## 12.2 The Pitch Framework: "STAR-Ask"

Every effective pitch follows this structure:

### S — Situation (背景)
Set the scene. What's the context your audience needs to understand?
- Market conditions, audience insights, timing, or a problem to solve
- Keep it brief — 1–2 minutes maximum
- Use data to establish credibility

### T — Tension (挑战)
What challenge or opportunity creates urgency?
- Why can't we just keep doing what we're doing?
- What will we miss if we don't act?
- This creates the emotional "lean-in" moment

### A — Answer (方案)
Your proposed solution — the heart of the pitch.
- Be specific and concrete: What exactly will we do?
- Show, don't just tell: Include visuals, mockups, references
- Explain *why this approach* over alternatives

### R — Result (预期效果)
What will success look like?
- Quantify where possible: expected reach, engagement, installs, revenue
- Qualitative outcomes too: brand perception, community sentiment
- Be honest about assumptions and risks

### Ask — The Ask (请求)
What specifically do you need from this audience?
- Budget amount
- Approval to proceed
- Resources or support
- Timeline commitment
- Be clear and direct — don't make them guess

---

## 12.3 Pitch Examples

### Example 1: Campaign Pitch to HQ

**Situation**: "Mid-Autumn Festival is China's second-largest traditional holiday, falling on September 17 this year. Our CN community is already discussing whether Sky will have a special event."

**Tension**: "If we don't activate around Mid-Autumn, we miss a major cultural moment that our competitors will capitalize on. Last year, Genshin ran a 2-week Moonlight event that generated 50M+ social impressions."

**Answer**: "I'm proposing a 'Moonlight Reunion' campaign — a 10-day activation combining in-game activities with a cross-platform social campaign. The concept centers on Sky's themes of reunion and light, perfectly aligned with Mid-Autumn Festival traditions of family gathering under the full moon."

**Result**: "Based on our CNY campaign performance, I project 3M+ social impressions, 15% DAU lift during the event period, and a 20% increase in season pass conversion driven by festival-themed cosmetics."

**Ask**: "I need: (1) Approval to proceed by next Friday, (2) Festival-themed cosmetic assets from the design team by T-4 weeks, (3) A campaign budget of [amount] for KOL partnerships and paid media."

### Example 2: Partnership Pitch to a Museum

**Situation**: "Sky: Children of the Light is a globally acclaimed social adventure game with 200M+ downloads, known for its breathtaking art and emotional storytelling. In China, we have 30M+ registered players, primarily young adults aged 18–28 who are deeply passionate about art and culture."

**Tension**: "Museums are seeking new ways to engage young digital-native audiences. Traditional outreach struggles to compete with gaming and social media for Gen-Z attention."

**Answer**: "We propose a 'Sky x [Museum Name]' collaboration that brings elements of your collection into the game world as a limited-time exhibition. Players would explore a virtual gallery inspired by your exhibits, unlock special cosmetics, and be encouraged to visit the physical museum with in-game rewards."

**Result**: "Our previous cultural collaborations have generated significant media coverage and social engagement. For the museum, this reaches millions of young art-loving players. For Sky, this elevates our brand as a cultural platform, not just a game."

**Ask**: "We'd love to schedule a creative workshop with your curatorial team to explore which collections could inspire an in-game experience."

---

## 12.4 Presentation Design

### Visual Principles for Sky Presentations

| Principle | Application |
|-----------|------------|
| **On-brand** | Use Sky's color palette, visual language, and tone throughout |
| **Visual > Text** | One key message per slide; use images to convey mood |
| **Data as story** | Don't just show numbers — highlight what they mean |
| **Flow** | Build the narrative slide by slide; each one leads to the next |
| **Restraint** | Less is more — cut any slide that doesn't serve the pitch |

### Slide Structure Template (10-Slide Pitch Deck)

| Slide | Content | Time |
|-------|---------|------|
| 1. **Cover** | Campaign/project name, your name, date | 15s |
| 2. **Context** | Market situation / audience insight | 1 min |
| 3. **Opportunity** | The tension — why now? | 1 min |
| 4. **Concept** | The big idea — name it, visualize it | 2 min |
| 5. **Execution** | What we'll do — channels, content, partners | 2 min |
| 6. **Timeline** | Key milestones and phases | 1 min |
| 7. **Budget** | Investment required and allocation | 1 min |
| 8. **Expected Results** | KPIs and projected outcomes | 1 min |
| 9. **Risks & Mitigations** | What could go wrong and how we'll handle it | 1 min |
| 10. **The Ask** | Clear request + next steps | 30s |

### Slide Design Tips
- **Font size**: Never below 24pt — if you need smaller text, you have too much
- **One idea per slide**: If you catch yourself saying "and also on this slide..." — split it
- **Images**: High-quality, on-brand; never use generic stock photos
- **Charts**: Simple, clear, with a headline that states the insight (not just "Monthly Downloads" but "Downloads grew 40% after the KOL campaign")
- **Animation**: Minimal — builds are OK, flashy transitions are not

---

## 12.5 Delivery Skills

### Before the Presentation

| Preparation Step | Details |
|-----------------|---------|
| **Know your audience** | What do they care about? What will they question? |
| **Practice out loud** | At least 2 full run-throughs; time yourself |
| **Prepare for questions** | Anticipate the 5 hardest questions and draft answers |
| **Test technology** | Check screen sharing, audio, video before the call |
| **Have a backup** | PDF version of slides; key numbers memorized |

### During the Presentation

| Skill | How |
|-------|-----|
| **Opening hook** | Start with a striking data point, question, or visual — not "Today I want to talk about..." |
| **Pace** | Slower than you think; pause after key points for emphasis |
| **Eye contact** | On video: look at the camera, not the screen; in-person: sweep the room |
| **Storytelling** | Use concrete examples and player stories, not just abstract concepts |
| **Energy** | Show genuine enthusiasm — your passion is contagious |
| **Conciseness** | Respect time — finish on time or early, never late |
| **Handling questions** | Listen fully, pause, then answer. "Great question" → answer → "Does that address your concern?" |

### Presenting in English vs. Chinese

| Aspect | English (to HQ) | Chinese (to partners/media) |
|--------|-----------------|---------------------------|
| **Style** | Direct, structured, data-supported | Relationship-first, narrative-rich |
| **Opening** | Get to the point quickly | Build rapport, establish context |
| **Persuasion** | Logic and evidence | Trust, relationship, and mutual benefit |
| **Closing** | Clear, specific ask | Collaborative next step; leave room for discussion |

### Presenting Cross-Culturally on Video
- **Speak clearly** — Non-native speakers (either side) benefit from clear articulation
- **Use visuals** — When language is a barrier, strong slides compensate
- **Pause for understanding** — "Does that make sense?" is a genuine check, not a filler
- **Follow up in writing** — Send key points and decisions in text after the call
- **Be patient with language gaps** — Offer to restate in different words

---

## 12.6 Handling Objections

### Common Objections and Responses

| Objection | Response Strategy |
|-----------|------------------|
| **"The budget is too high"** | Show ROI calculation; offer a phased approach; compare to competitor spending |
| **"We've never done this before"** | Acknowledge the risk; cite analogous successes; propose a small-scale pilot |
| **"How does this align with global strategy?"** | Show direct connection to tgc's values and global brand goals |
| **"What if it doesn't work?"** | Present risk mitigation plan; define clear success/fail criteria and a kill switch |
| **"We don't have time for this"** | Show the timeline is manageable; offer to own the execution with minimal HQ input |
| **"I need to think about it"** | Respect this; offer to send a written summary; set a follow-up date |

### The "Yes, And" Technique
When facing pushback, avoid "but" — use "yes, and":

- Instead of: "But the CN market is different..."
- Try: "Yes, that global framework is strong, and in the CN market, we can adapt it by..."

This validates the other person's point while building on it, rather than contradicting it.

---

## 12.7 The One-Page Brief

Sometimes you don't need a deck — you need a **one-page brief** that sells the idea quickly:

```
═══════════════════════════════════════════
  [CAMPAIGN/PROJECT NAME]
  One-Page Brief — [Date]
═══════════════════════════════════════════

THE INSIGHT
[1–2 sentences: what audience truth drives this idea?]

THE IDEA
[2–3 sentences: what are we proposing?]

THE EXECUTION
• Channel 1: [What we'll do]
• Channel 2: [What we'll do]
• Channel 3: [What we'll do]
• KOL/Partners: [Who and how]

THE TIMELINE
[Key dates in one line: Brief T-6w → Production T-4w → Launch T-Day → Report T+2w]

THE INVESTMENT
[Total budget + top-line allocation]

THE EXPECTED RETURN
• [KPI 1]: [Target]
• [KPI 2]: [Target]
• [KPI 3]: [Target]

THE ASK
[What you need: approval / budget / resources / by when]
═══════════════════════════════════════════
```

---

## 12.8 Storytelling for Marketers

### Why Storytelling Matters
- People remember stories 22x more than facts alone
- Sky is fundamentally a storytelling game — its marketing should tell stories too
- Stories create emotional investment, which drives decisions

### Story Structures for Pitches

**The Player Story**:
"Let me tell you about a player named [name]. She was [context]. She found Sky when [trigger]. Now she [transformation]. This campaign will reach thousands more people like her."

**The Market Story**:
"Two years ago, the CN healing games market was [situation]. Today, [change]. Tomorrow, [opportunity]. Sky is uniquely positioned to [action]."

**The Data Story**:
"When we launched [campaign], we expected [target]. Instead, we saw [result]. What this tells us is [insight]. That's why I'm proposing [next step]."

### Tips for Storytelling
1. **Be specific** — "A 20-year-old art student in Hangzhou" is more powerful than "young female users"
2. **Use contrast** — Before/after, expected/actual, problem/solution
3. **Include emotion** — What did people *feel*? Quote real player comments
4. **Keep it brief** — A good story in a pitch is 30–60 seconds, not 5 minutes
5. **Practice the landing** — The last sentence of your story should connect directly to your point

---

## 12.9 Pitch Preparation Checklist

Before any pitch, run through this:

- [ ] **Objective clear**: I know exactly what I'm asking for
- [ ] **Audience understood**: I know what they care about and what they'll question
- [ ] **STAR-Ask structure**: My pitch follows Situation → Tension → Answer → Result → Ask
- [ ] **Data ready**: Key numbers are accurate and sourced
- [ ] **Visuals strong**: Slides are clean, on-brand, and support (not replace) my words
- [ ] **Practiced**: I've rehearsed at least twice and timed myself
- [ ] **Questions anticipated**: I have answers for the 5 toughest questions
- [ ] **Backup plan**: I have a fallback if my primary ask is rejected
- [ ] **Follow-up planned**: I know what I'll send after the meeting

---

## Knowledge Check

1. You have 10 minutes to pitch a Chinese New Year campaign to HQ leadership. Outline your pitch using STAR-Ask.
2. A potential brand partner says "We're not sure gaming is right for our brand image." How do you respond?
3. Design a 10-slide pitch deck for a Bilibili partnership proposal. What goes on each slide?
4. You're pitching to a KOL who has never played Sky. What's your 60-second elevator pitch?
5. Your campaign pitch gets the response: "Interesting idea, but the budget is too high." What are your next three moves?

---

[← Module 19: Cross-Border Teamwork & Professional Growth](19-cross-border-teamwork.md) | [Next: Module 21 — AI Applications in Marketing →](21-ai-applications.md) | [Main Guide](../README.md)
