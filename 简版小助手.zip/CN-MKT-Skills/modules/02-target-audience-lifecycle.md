# Module 02: Target Audience & Player Lifecycle

> Understanding who plays Sky — and guiding them from curious newcomer to lifelong advocate — is the foundation of every marketing decision.

---

## 2.1 Player Demographics Overview

### Primary Audience (Current Players)
| Dimension | Profile |
|-----------|---------|
| **Age** | 16–28 years old (core: 18–24) |
| **Gender** | ~65–70% female, ~30–35% male |
| **Location** | Tier 1–2 cities dominant, growing Tier 3 presence |
| **Education** | High school to university students, young professionals |
| **Income** | Low-to-moderate discretionary spending; selective about IAPs |
| **Device** | Primarily mobile (iOS over-indexed); growing PC/console |

### Secondary Audiences (Growth Opportunities)
| Segment | Opportunity |
|---------|-------------|
| **Non-gamers** | Sky's accessibility attracts people who don't normally play games |
| **Art/music enthusiasts** | Drawn to visual and musical beauty |
| **Couples/friends** | The co-op and hand-holding mechanics attract pairs |
| **Parents with children** | Safe, non-violent, family-friendly content |
| **Older casual players (28–40)** | Seeking peaceful, non-competitive experiences |

---

## 2.2 Psychographic Profiles

### Core Psychographic: "温柔的探索者" (The Gentle Explorer)

These players value:
- **Aesthetic beauty** — Drawn to visually stunning and artistically coherent worlds
- **Emotional experiences** — Want to feel something meaningful, not just be entertained
- **Human connection** — Value friendships (online and offline) and communal experiences
- **Self-expression** — Use cosmetics, emotes, and music to express identity
- **Peaceful escape** — Seek refuge from academic/work pressure in a gentle world
- **Creativity** — Many are artists, writers, musicians, or aspiring creators

### Motivational Drivers
```
                    High Emotional Investment
                           ▲
                           │
         Social Bonds ◄────┼────► Aesthetic Pleasure
                           │
                           ▼
                    Self-Expression
```

Unlike competitive games where status/rank drives retention, Sky players stay because of:
1. **Friendships formed in-game** — "I can't leave because my friends are here"
2. **Seasonal FOMO** — "I want to complete this season's collection"
3. **Creative expression** — "I want to take beautiful screenshots / make videos"
4. **Ritual and routine** — "Daily candle runs are my meditation"

---

## 2.3 Player Personas

### Persona 1: 小云 (Xiao Yun) — The College Student
- **Age**: 20, female, university student in Chengdu
- **Behavior**: Plays 30–60 min daily, mainly on mobile during breaks; active on Xiaohongshu posting screenshots
- **Motivation**: Emotional escape from academic stress; loves collecting cosmetics
- **Spending**: Buys Adventure Pass each season (~¥68); occasional candle packs before season end
- **Content preference**: Beautiful screenshots, season guides, lore analysis, fan art
- **Pain points**: Server lag, expensive cosmetics, time pressure to finish seasons

### Persona 2: 阿光 (A Guang) — The Devoted Fan Creator
- **Age**: 23, non-binary, freelance illustrator in Shanghai
- **Behavior**: Plays daily; creates fan art, participates in community events; active on Bilibili and Lofter
- **Motivation**: Artistic inspiration; deep emotional connection to the game's story and characters
- **Spending**: Buys all cosmetics; purchases merch
- **Content preference**: Behind-the-scenes dev content, lore, community spotlights, art challenges
- **Pain points**: Wants more creator recognition; frustrated by content leaks spoiling surprises

### Persona 3: 大鹏 & 小燕 (Da Peng & Xiao Yan) — The Couple
- **Age**: 26 & 25, working professionals in Beijing
- **Behavior**: Play together 2–3 times per week as a bonding activity
- **Motivation**: Shared experience; romantic/intimate game moments (hand-holding, music playing)
- **Spending**: Moderate; buy matching cosmetics
- **Content preference**: Couple gameplay videos, romantic moments, matching outfit showcases
- **Pain points**: Busy schedules make it hard to keep up with season content

### Persona 4: 林姐 (Lin Jie) — The Casual Non-Gamer
- **Age**: 35, female, office worker in Guangzhou
- **Behavior**: Plays occasionally, attracted by beautiful screenshots she saw on Xiaohongshu
- **Motivation**: Relaxation; doesn't consider herself a "gamer" but finds Sky peaceful
- **Spending**: Rarely spends; may buy Adventure Pass once
- **Content preference**: Simple guides, relaxing gameplay clips, "healing" (治愈) content
- **Pain points**: Gets confused by game mechanics; doesn't know how to find friends in-game

---

## 2.4 CN Player Behavioral Insights

### Content Consumption Patterns
| Time Period | Behavior |
|-------------|----------|
| **Morning (7–9 AM)** | Scroll Xiaohongshu, WeChat Moments — visual content performs well |
| **Lunch (12–1 PM)** | Watch short videos on Douyin/Bilibili — short-form content peak |
| **Evening (7–10 PM)** | Active gameplay session; community engagement on QQ/WeChat groups |
| **Late night (10 PM–12 AM)** | Emotional/reflective content resonates; long-form Bilibili videos |
| **Weekends** | Extended play sessions; event participation; fan creation time |

### Spending Behavior
- CN players are generally **price-sensitive** but willing to spend for **emotionally meaningful** items
- **Social proof matters** — if a cosmetic goes viral (e.g., "flower crown" moments), sales spike
- **Seasonal urgency** works, but overt pressure tactics backfire — frame as "don't miss this beautiful experience" rather than "BUY NOW"
- **Gift-giving economy** — players buy candles/hearts to gift to friends; marketing can lean into generosity framing
- **Bundle perception** — CN players evaluate value carefully; IAP bundles need to feel generous

### Community Behavior
- **Word-of-mouth is the primary acquisition driver** — players invite friends personally
- **Fan creation (二创) is currency** — prolific fan art/video creators are community leaders
- **Sentiment is volatile** — a single unpopular decision can spark intense Weibo/Bilibili backlash
- **Nostalgia is powerful** — referencing early game memories, past seasons, and "old Sky" resonates deeply
- **Community lingo evolves quickly** — stay current with slang and memes

---

## 2.5 The Player Lifecycle

### Sky's Player Journey

```
AWARENESS → CONSIDERATION → DOWNLOAD → ONBOARDING → ENGAGEMENT → MASTERY → ADVOCACY
                                                                              ↑
                                                                    LAPSE → REACTIVATION
```

### Lifecycle Stages

| Stage | Player State | Duration | Key Question | Marketing Goal |
|-------|-------------|----------|-------------|----------------|
| **Awareness** | Knows Sky exists | Variable | "What is this game?" | Make the right people discover Sky |
| **Consideration** | Interested; evaluating | Hours to days | "Is this game for me?" | Convert interest into download |
| **Download** | Installs the game | Moment | "Let me try it" | Reduce friction |
| **Onboarding** | First 1–7 days | Days 1–7 | "How does this work?" | Help new players fall in love |
| **Engagement** | Regular player | Weeks 2–12 | "What's there to do?" | Deepen connection |
| **Mastery** | Deep knowledge; collecting | Months 3+ | "How do I get everything?" | Reward loyalty |
| **Advocacy** | Recruits friends; creates content | Ongoing | "Everyone should try this" | Amplify and celebrate |
| **Lapse** | Stopped playing (30+ days) | Variable | "I used to play but..." | Win back |
| **Reactivation** | Returns after lapse | Re-onboarding | "What's changed?" | Smooth re-entry |

---

## 2.6 Marketing by Lifecycle Stage

### Awareness & Consideration
| Tactic | Channel | Message |
|--------|---------|---------|
| Beauty shot videos | Douyin, Xiaohongshu | "Have you seen this world?" |
| KOL/KOC content | All platforms | Authentic "discovery" content |
| Paid media (broad targeting) | Douyin Ads, Bilibili Ads | Visual hook; emotional curiosity |
| Gameplay showcases | Bilibili, Douyin | "This is what playing Sky feels like" |
| Player testimonials | Xiaohongshu, Douyin | "Real players sharing real experiences" |
| ASO / app store presence | App stores | Rank for "治愈游戏," "社交游戏" |

### Onboarding (Days 1–7)
| Tactic | Channel | Message |
|--------|---------|---------|
| Beginner guides | Bilibili, Xiaohongshu | "Your first day in Sky — what to do" |
| "What I wish I knew" content | Douyin, Xiaohongshu | Tips from experienced players |
| Welcome community posts | WeChat groups, Weibo | "Welcome, new Children of Light!" |
| Buddy/mentor programs | Community | Pair new players with experienced guides |

**Critical onboarding metrics**:
| Metric | Target | Why It Matters |
|--------|--------|---------------|
| Tutorial completion rate | > 80% | Players who don't finish rarely return |
| Day 1 retention | > 35% | First-day experience determines everything |
| First social interaction | Within Day 1–3 | Social connection is the #1 retention driver |
| Day 7 retention | > 15% | Separates committed from casual |

### Engagement & Mastery
| Tactic | Channel | Message |
|--------|---------|---------|
| Season content marketing | All | "Your next adventure awaits" |
| Community events and challenges | All | "Create, share, and be seen" |
| Creator program | All | "Your voice matters" |
| Behind-the-scenes content | Bilibili, WeChat | "See how Sky is made" |
| Beta testing access | Community | "Help shape Sky's future" |

### Advocacy
| Tactic | Channel | Message |
|--------|---------|---------|
| Official amplification of fan content | All | "Your creation inspired us" |
| Referral programs | In-game, social | "Share the light with friends" |
| Community spotlight features | All | "Meet the people who make Sky special" |

---

## 2.7 Retention Strategy

### Why Players Leave Sky

| Reason | Frequency | Addressable by Marketing? |
|--------|-----------|--------------------------|
| **Completed current season content** | Very common | Yes — sustain content between seasons |
| **Lost social connections** | Common | Yes — encourage new friendships; community events |
| **Content fatigue** | Common | Partially — highlight undiscovered content; fan creation |
| **Time constraints** | Common | Partially — show that Sky works in short sessions too |
| **Found a different game** | Common | Partially — differentiate; emphasize unique value |
| **Pricing dissatisfaction** | Occasional | Partially — emphasize free content; value messaging |

### The "Emotional Bookmark" Strategy

Sky's best retention tool is creating **emotional bookmarks** — moments so meaningful that players want to come back:

| Emotional Bookmark | How Marketing Supports It |
|-------------------|--------------------------|
| **A friendship formed in-game** | Celebrate friendship stories; encourage social sharing |
| **A breathtaking visual moment** | Create and share screenshot/video content that reminds players of beauty |
| **Completing a season together** | Season-end retrospective content; "we did it together" messaging |
| **The Eden experience** | Lore content that deepens understanding; "ready for Eden?" guidance |
| **Receiving a gift from a stranger** | Generosity-themed content; encourage candle-gifting |

### Retention Tactics by Risk Level

| Risk Signal | Identification | Intervention |
|------------|---------------|-------------|
| **Declining session frequency** | Analytics data | Push re-engagement content; highlight new activities |
| **Season pass not purchased** | Sales data | Cosmetic showcase content; value messaging |
| **Stopped participating in community** | Community metrics | Personal outreach to known community members |
| **Negative reviews/comments** | Social listening | Address concerns; demonstrate you're listening |

---

## 2.8 Re-Engagement & Win-Back

### Win-Back Timing

| Lapse Duration | Player State | Approach |
|---------------|-------------|----------|
| **7–14 days** | Soft lapse — may return naturally | Light-touch: beautiful content in feed |
| **15–30 days** | Moderate lapse — need a reason | Active: "Here's what you've missed" |
| **31–90 days** | Significant lapse — has moved on | Strong: "Things have changed — come see" |
| **90+ days** | Deep lapse — essentially new | Re-introduce with nostalgia angle |

### Win-Back Messaging Framework

| Message Type | Target | Example |
|-------------|--------|---------|
| **"What's new"** | All lapsed | "Since you've been away: new season, 12 new spirits, a beautiful new realm" |
| **Nostalgia** | Long-lapsed | "Remember your first flight through Golden Wasteland?" |
| **Social pull** | Players with active friends | "Your friends are still waiting in the clouds" |
| **Event-driven** | All lapsed | "Days of Fortune starts tomorrow — the lanterns are lit" |

### Win-Back Channels

| Channel | Tactic | Effectiveness |
|---------|--------|--------------|
| **Push notifications** | Re-engagement pushes (via NetEase) | High — direct; risk of annoyance if overused |
| **Social media** | Beautiful content in lapsed players' feeds | Medium — organic reach |
| **Paid retargeting** | Retarget lapsed installers on Douyin/Bilibili | Medium-High — precise but costs money |
| **Community word-of-mouth** | Active players encourage lapsed friends | High — most trusted source |

---

## 2.9 Cohort Analysis & Audience Research

### Cohort Analysis for Marketing Decisions

| Cohort Question | Marketing Insight |
|-----------------|------------------|
| "Do players who join during CNY retain better?" | Invest more in CNY acquisition — higher LTV |
| "Do KOL-acquired players spend more than organic?" | Adjust KOL budget based on quality, not just volume |
| "At what point do most players churn?" | Create targeted content for that moment |
| "Do players who join community groups retain better?" | Invest in community-building as a retention tool |
| "Do season-pass buyers retain longer?" | Position season pass as a commitment tool |

### Cohort Reporting Template

```
COHORT: Players who installed during [Event/Period]
SIZE: [Number] new installs

Day 1 Retention:  [X]%  ██████████████░░░░░░
Day 7 Retention:  [X]%  ████████░░░░░░░░░░░░
Day 30 Retention: [X]%  ████░░░░░░░░░░░░░░░░
Day 90 Retention: [X]%  ██░░░░░░░░░░░░░░░░░░

Season Pass Conv: [X]%
Avg Revenue/User: ¥[X]

vs. Average Cohort:
  Retention:  [Better/Worse by X%]
  Revenue:    [Better/Worse by X%]

Insight: [What does this tell us?]
```

### Ongoing Research Activities
| Method | Frequency | Tool/Platform |
|--------|-----------|---------------|
| **Social listening** | Daily | Xiaohongshu, Weibo, Bilibili comments, Douyin |
| **Community sentiment tracking** | Daily | QQ groups, WeChat groups, Bilibili 动态 |
| **Player surveys** | Quarterly | In-game or WeChat mini-program |
| **Analytics review** | Weekly | NetEase backend data, app store analytics |
| **Competitor audience comparison** | Monthly | Third-party data (QuestMobile, Sensor Tower) |

### CRM & Player Communication

| Touchpoint | Channel | Purpose | Max Frequency |
|-----------|---------|---------|---------------|
| **Welcome message** | In-game | Onboarding support | Once |
| **Season launch notification** | Push notification | Re-engagement | 2–3/week max |
| **Event announcement** | Social media + push | Drive participation | Daily on social |
| **Community newsletter** | WeChat | Deepening relationship | 2–4/month |
| **Win-back message** | Push + retargeting | Re-engagement | Per campaign |

**Golden rule**: Every communication should provide value to the player. If it doesn't inform, delight, or help them — don't send it.

### Audience Segmentation for Campaigns

| Tier | Definition | Size (est.) | Strategy |
|------|-----------|-------------|----------|
| **Core Fans** | Play daily, create content, buy every pass | ~10% | Reward loyalty, amplify content, give early access |
| **Active Players** | Play regularly, buy occasionally | ~30% | Drive seasonal engagement, encourage sharing |
| **Casual Players** | Play intermittently, rarely spend | ~40% | Re-engagement through beautiful content |
| **Lapsed Players** | Haven't played in 30+ days | ~15% | Win-back through nostalgia, new content |
| **Prospects** | Never played but fit the target | Unlimited | Awareness campaigns; leverage visual appeal |

---

## Knowledge Check

1. A player downloads Sky, plays for 3 days, then disappears. Using the lifecycle framework, what likely happened and what marketing intervention would you try?
2. Which persona would be most receptive to a "couples event" campaign? Design the campaign concept targeting them.
3. Design a 30-day onboarding content series (one piece per week) that guides new players through their first month.
4. Day 7 retention has dropped 3% over the past two seasons. What data would you analyze, and what marketing experiments would you propose?
5. Create a win-back campaign for players lapsed since last season: messaging, channels, timing, and success metrics.

---

## Related Modules
- [Module 04: CN Social Media Platforms](04-social-media-platforms.md) — Where to reach each audience segment
- [Module 06: Data Analytics](06-data-analytics.md) — Metrics and measurement frameworks
- [Module 09: Community Building](09-community-building.md) — Deepening the fan ecosystem
- [Module 14: Live Ops, Seasons & Monetization](14-live-ops-monetization.md) — Season lifecycle marketing

---

[← Module 01: Game & Brand](01-game-and-brand.md) | [Next: Module 03 — Competitor Analysis →](03-competitor-analysis.md) | [Main Guide](../README.md)
