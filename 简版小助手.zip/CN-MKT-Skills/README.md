# thatgamecompany CN Marketing Team — Skills & Training Guide

> Comprehensive training resource for CN marketing team members working on **Sky: Children of the Light (光·遇)**

---

## Purpose

This guide equips thatgamecompany's China marketing team with the knowledge, frameworks, and standard operating procedures needed to effectively market Sky: Children of the Light in the Chinese market. It covers game understanding, audience insights, competitive landscape, platform strategies, campaign execution, creative production, game publishing, agency collaboration, professional development, and project management.

**22 modules + appendix** organized into six learning tracks, each with knowledge check questions and practical frameworks.

---

## Module Directory

### Part I: Game & Market Foundations (Modules 01–04)

*Start here. Core knowledge every CN marketing team member needs.*

| # | Module | Description |
|---|--------|-------------|
| 01 | [Game & Brand Understanding](modules/01-game-and-brand.md) | Sky's design philosophy, brand values, emotional core, and seasonal content model |
| 02 | [Target Audience & Player Lifecycle](modules/02-target-audience-lifecycle.md) | CN player demographics, personas, lifecycle stages, retention strategy, win-back campaigns, cohort analysis |
| 03 | [Competitor Analysis](modules/03-competitor-analysis.md) | Competitive landscape, SWOT analysis, positioning framework, and intelligence gathering |
| 04 | [CN Social Media Platforms](modules/04-social-media-platforms.md) | Platform-specific strategies for Bilibili, Douyin, Xiaohongshu, WeChat, Weibo, and TapTap |

### Part II: Growth & Content (Modules 05–09)

*Acquiring players, creating content, and building community.*

| # | Module | Description |
|---|--------|-------------|
| 05 | [User Acquisition & App Store Distribution](modules/05-user-acquisition-distribution.md) | UA channels, KOL partnerships, ASO, paid media, multi-store Android management, featuring, review management |
| 06 | [Data Analytics & Performance Measurement](modules/06-data-analytics.md) | Metrics frameworks, platform dashboards, A/B testing, attribution, and campaign measurement |
| 07 | [Content Localization & CN Copywriting](modules/07-content-localization.md) | CN writing principles (意境, 留白, 节奏感), platform-specific copy styles, localization workflow |
| 08 | [Creative Production & Platform Formats](modules/08-creative-production.md) | Video formulas, in-game capture, editing workflows, complete specs reference, creative testing framework |
| 09 | [Community Building & Fan Ecosystem](modules/09-community-building.md) | 4-tier fan creator program, community health monitoring, UGC ecosystem, and governance |

### Part III: Campaign & Operations (Modules 10–12)

*Planning, executing, and measuring marketing operations.*

| # | Module | Description |
|---|--------|-------------|
| 10 | [Campaign Planning & Project Management](modules/10-campaign-planning-pm.md) | 7-step campaign framework, RACI matrix, sprint-based ops, 复盘 process, dependency and risk management |
| 11 | [Marketing SOPs & Workflows](modules/11-marketing-sops.md) | Daily/weekly routines, season launch SOP, crisis protocol, content QA, and asset management |
| 12 | [Budget Management & ROI Analysis](modules/12-budget-management.md) | Budget planning, 3-tier ROI framework, cost optimization, and financial reporting |

### Part IV: Game Publishing (Modules 13–16)

*Understanding the publishing ecosystem, live ops, and cross-platform strategy.*

| # | Module | Description |
|---|--------|-------------|
| 13 | [Game Publishing Fundamentals](modules/13-game-publishing.md) | CN publishing ecosystem, 版号 approvals, tgc-NetEase dynamics, distribution channels |
| 14 | [Live Ops, Seasons & Monetization](modules/14-live-ops-monetization.md) | Season lifecycle marketing, event operations, ethical monetization, pricing strategy, season pass marketing |
| 15 | [Beta Testing & New Game Launch](modules/15-beta-testing-launch.md) | Closed/open beta, pre-registration, soft launch, launch day war room, post-launch ops |
| 16 | [Cross-Platform Publishing](modules/16-cross-platform.md) | Mobile/console/PC strategy, cross-save/cross-play marketing, platform communities |

### Part V: Collaboration & Partnerships (Modules 17–18)

*Working with agencies, partners, and executing events and merchandising.*

| # | Module | Description |
|---|--------|-------------|
| 17 | [Agency, Partner & KOL Collaboration](modules/17-agency-partner-collab.md) | Creative briefs, agency selection, KOL management, production partnerships, contract essentials |
| 18 | [Events, Merchandising & IP Collaboration](modules/18-events-merch-ip.md) | Livestreams, meetups, exhibitions, blind box culture, IP collaboration framework, merch marketing |

### Part VI: Professional Development (Modules 19–22)

*Communication, leadership, AI, and regulatory skills for cross-border teams.*

| # | Module | Description |
|---|--------|-------------|
| 19 | [Cross-Border Teamwork & Professional Growth](modules/19-cross-border-teamwork.md) | Bridge translation, async communication, time zone management, conflict resolution, burnout prevention |
| 20 | [Pitch & Presentation Skills](modules/20-pitch-and-presentation.md) | STAR-Ask pitch framework, presentation design, objection handling, and storytelling |
| 21 | [AI Applications in Marketing](modules/21-ai-applications.md) | Practical AI workflows for content, analytics, localization, and reporting |
| 22 | [CN Gaming Regulatory & Compliance](modules/22-regulatory-compliance.md) | Advertising law, minor protection, data privacy, AI content rules, and compliance checklists |

### AI 创意制作 Skills 工具箱 (NEW)

*把知识变成可直接使用的工具——配合 Seedance、Nano Banana 等 AI 工具使用。*

| # | Skill | Description |
|---|-------|-------------|
| 01 | [AI 视频 Prompt 生成器](skills/01-video-prompt-generator.md) | Generate brand-consistent video/image prompts for Seedance, Nano Banana, and other AI creative tools |
| 02 | [全平台内容适配器](skills/02-platform-content-adapter.md) | Adapt one core message to 5 CN platforms (Douyin, Bilibili, XHS, WeChat, Weibo) with proper specs and tone |
| 03 | [创意 Brief 生成器](skills/03-creative-brief-generator.md) | Quickly generate standardized creative briefs for seasons, campaigns, KOL collabs, and AI production |
| 04 | [品牌调性检查器](skills/04-brand-voice-checker.md) | Check AI-generated content against Sky's brand principles (意境, 留白, 节奏感, 共情, 网感) |

→ [Skills 完整说明](skills/README.md)

### Appendix

| Resource | Description |
|----------|-------------|
| [Terminology Glossary](appendix-glossary.md) | Complete EN-CN terminology reference for game terms, marketing terms, CN holidays, and analytics tools |

---

## Learning Paths

### Path 1: New Team Member Onboarding (Weeks 1–4)

```
Week 1:  Modules 01–03 (Game, Audience & Lifecycle, Competitors)
Week 2:  Modules 04–05 (Platforms, User Acquisition & Distribution)
Week 3:  Modules 10–11 (Campaign Planning, SOPs) + Appendix Glossary
Week 4:  Module 19 (Cross-Border Teamwork & Professional Growth)
```

### Path 2: Content Creator / Copywriter

```
Priority:  Modules 01, 04, 07, 08 (Brand, Platforms, Copywriting, Creative Production)
Then:      Modules 09, 21 (Community, AI Tools)
Reference: Appendix Glossary (terminology)
```

### Path 3: Community Manager

```
Priority:  Modules 01, 02, 09, 11 (Brand, Audience, Community, SOPs)
Then:      Modules 04, 22, 18 (Platforms, Compliance, Events)
Reference: Module 07 (tone and voice guidelines)
```

### Path 4: UA / Growth Marketer

```
Priority:  Modules 05, 06, 02 (UA & Distribution, Analytics, Audience & Lifecycle)
Then:      Modules 10, 12, 14 (Campaign Planning, Budget, Live Ops & Monetization)
Reference: Module 04 (platform-specific tactics)
```

### Path 5: Publishing & Operations

```
Priority:  Modules 13, 14, 15, 16 (Publishing, Live Ops, Launch, Cross-Platform)
Then:      Modules 05, 22 (Distribution, Regulatory Compliance)
Reference: Module 12 (budget management)
```

### Path 6: Creative & Project Lead

```
Priority:  Modules 08, 10, 17 (Creative Production, Campaign PM, Agency Collab)
Then:      Modules 12, 20, 18 (Budget, Pitch Skills, Events & Merch)
Reference: Module 07 (copywriting), Module 19 (cross-border teamwork)
```

### Path 7: AI-Powered Content Creation (NEW)

```
Foundations:  Modules 01, 07, 08 (Brand, Copywriting, Creative Production)
AI Skills:   Skills 01–04 (Video Prompts, Platform Adapter, Brief Generator, Brand Checker)
Reference:   Module 21 (AI Applications), Appendix Glossary
```

---

## About Sky: Children of the Light (光·遇)

Sky is thatgamecompany's social adventure game where players explore a magical kingdom, form connections with others, and relive the memories of fallen spirits. The game emphasizes compassion, generosity, and human connection — values that are central to every marketing message we create.

| | |
|---|---|
| **Developer** | thatgamecompany (tgc) |
| **CN Publisher** | NetEase (网易) |
| **Platforms** | iOS, Android, Nintendo Switch, PlayStation, PC (Steam) |
| **CN Launch** | June 2019 (iOS), expanded platforms over subsequent years |
| **Core Values** | Compassion, connection, wonder, generosity |

---

## Guide Maintenance

- **Review cadence**: Content should be reviewed and updated quarterly
- **Platform features**: CN social media and app store features evolve rapidly — verify current availability when using platform-specific guidance
- **Regulatory updates**: CN gaming regulations change frequently — consult with legal before acting on Module 22 content
- **Terminology**: Update the [Appendix Glossary](appendix-glossary.md) as new community terms and platform features emerge
- **Feedback**: If you find outdated information or gaps, flag them for the next quarterly review

---

*Maintained by the tgc CN Marketing Team.*
